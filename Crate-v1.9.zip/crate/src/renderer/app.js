'use strict';
/* global CrateKeys */
// Crate window UI. Talks to the app only through window.crate (see preload.js).

// ---------------------------------------------------------------- helpers
const $ = (s, root = document) => root.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function el(tag, attrs = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') n.className = v; else if (k === 'style') n.style.cssText = v; else if (k === 'text') n.textContent = v; else if (k === 'html') n.innerHTML = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v); else if (k === 'dataset') Object.assign(n.dataset, v);
    else n.setAttribute(k, v === true ? '' : v);
  }
  for (const k of kids.flat()) if (k !== null && k !== undefined && k !== false) n.append(k instanceof Node ? k : document.createTextNode(String(k)));
  return n;
}
const fmtTime = (s) => { s = Math.max(0, Math.round(s || 0)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = String(s % 60).padStart(2, '0'); return h ? `${h}:${String(m).padStart(2, '0')}:${x}` : `${m}:${x}`; };
const fmtSize = (b) => b > 1e9 ? (b / 1e9).toFixed(2) + ' GB' : (b / 1e6).toFixed(1) + ' MB';
const shortPath = (p) => { const parts = String(p).split(/[\\/]/); return parts.length > 3 ? '…/' + parts.slice(-3).join('/') : p; };
const plural = (n, w) => `${n.toLocaleString()} ${w}${n === 1 ? '' : 's'}`;
const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
const store = { get(k, d) { try { const v = localStorage.getItem('crate.' + k); return v === null ? d : JSON.parse(v); } catch { return d; } }, set(k, v) { try { localStorage.setItem('crate.' + k, JSON.stringify(v)); } catch { /* ignore */ } } };

async function api(method, ...args) {
  try { return await window.crate.call(method, ...args); }
  catch (e) { const msg = String(e.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, ''); toast(msg, 'error'); throw e; }
}

function toast(message, kind = 'info', { timeout = 4500, progress = false, action = null } = {}) {
  const t = el('div', { class: `toast ${kind}`, role: kind === 'error' ? 'alert' : 'status' }, el('div', { class: 'msg', text: message }));
  if (action) t.append(el('button', { class: 'toast-action', type: 'button', text: action.label, onclick: () => { t.remove(); action.run(); } }));
  let bar = null; if (progress) { bar = el('progress', { max: 1, value: 0 }); t.append(bar); }
  $('#toasts').append(t);
  while ($('#toasts').children.length > 3) $('#toasts').firstElementChild.remove(); // keep the stack short
  if (kind === 'ok' && timeout === 4500) timeout = 3000;
  const close = () => t.remove(); if (timeout && !progress) setTimeout(close, timeout);
  return { close, set(msg, p) { if (msg) t.querySelector('.msg').textContent = msg; if (bar && p !== undefined) bar.value = p; }, done(msg, k = 'ok') { t.className = `toast ${k}`; bar && bar.remove(); this.set(msg); setTimeout(close, timeout); } };
}

// ---------------------------------------------------------------- state
const state = {
  view: { playlistId: null, special: 'all', search: '', ...store.get('sort', { sort: 'artist', dir: 'asc' }) },
  tracks: [], playlists: [], selection: new Set(), anchor: -1, focus: -1, total: 0,
  expanded: new Set(store.get('expanded', [])), notation: store.get('notation', 'camelot'),
  playingId: null, genres: [],
};
const ROW = 28;

// ---------------------------------------------------------------- columns
const stars = (n) => `<span class="stars">${'★'.repeat(n || 0)}<span class="off">${'★'.repeat(5 - (n || 0))}</span></span>`;
function keyChip(raw) {
  if (!raw) return '';
  const k = CrateKeys.parse(raw);
  if (!k) return `<span class="key unknown">${esc(raw)}</span>`;
  // colour class = position on the Camelot wheel (styles.css), so harmonic neighbours look alike
  return `<span class="key k${k.num}${k.letter === 'A' ? ' minor' : ''}">${esc(CrateKeys.format(raw, state.notation))}</span>`;
}
const COLUMNS = [
  { id: 'position', label: '#', width: '44px', num: true, playlistOnly: true, render: (t) => (t.position ?? 0) + 1 },
  { id: 'title', label: 'Title', width: 'minmax(160px, 2.2fr)', cls: 'title', fixed: true, render: (t) => esc(t.title) },
  { id: 'artist', label: 'Artist', width: 'minmax(110px, 1.5fr)', render: (t) => esc(t.artist) },
  { id: 'remixer', label: 'Remixer', width: 'minmax(70px, 0.9fr)', cls: 'muted', render: (t) => esc(t.remixer) },
  { id: 'album', label: 'Album', width: 'minmax(80px, 1fr)', cls: 'muted', optional: true, render: (t) => esc(t.album) },
  { id: 'genre', label: 'Genre', width: 'minmax(80px, 1fr)', cls: 'muted', render: (t) => esc(t.genre) },
  { id: 'bpm', label: 'BPM', width: '56px', num: true, render: (t) => t.bpm ? (Math.round(t.bpm * 10) / 10).toString() : '' },
  { id: 'key', label: 'Key', width: '64px', render: (t) => keyChip(t.key) },
  { id: 'rating', label: 'Rating', width: '92px', render: (t) => stars(t.rating) },
  { id: 'duration', label: 'Time', width: '56px', num: true, render: (t) => fmtTime(t.duration) },
  { id: 'year', label: 'Year', width: '52px', num: true, cls: 'muted', render: (t) => t.year || '' },
  { id: 'label', label: 'Label', width: 'minmax(70px, 0.9fr)', cls: 'muted', render: (t) => esc(t.label) },
  { id: 'comment', label: 'Comment', width: 'minmax(90px, 1.2fr)', cls: 'muted', optional: true, render: (t) => esc(t.comment) },
  { id: 'bitrate', label: 'Kbps', width: '52px', num: true, cls: 'muted', optional: true, render: (t) => t.bitrate || '' },
  { id: 'format', label: 'Type', width: '48px', cls: 'muted', optional: true, render: (t) => esc(({ mp4: 'm4a' })[t.format] || t.format) },
  { id: 'cues', label: 'Cues', width: '52px', num: true, cls: 'muted', optional: true, render: (t) => t.cues || '' },
  { id: 'dateAdded', label: 'Added', width: '88px', num: true, cls: 'muted', optional: true, render: (t) => esc(String(t.dateAdded).slice(0, 10)) },
];
// Column visibility (right-click the header to change). Optional columns start hidden.
const hiddenCols = new Set(store.get('hiddenCols', COLUMNS.filter(c => c.optional).map(c => c.id)));
const currentPlaylist = () => state.playlists.find(p => p.id === state.view.playlistId) || null;
const isManualPlaylist = () => currentPlaylist()?.type === 'playlist';
// Column order (drag a header to move it). Saved as a list of column ids; columns added in later
// versions keep their default place.
let colOrder = store.get('colOrder', null);
function orderedColumns() {
  if (!colOrder) return COLUMNS;
  const rank = new Map(colOrder.map((id, i) => [id, i]));
  const out = COLUMNS.filter(c => rank.has(c.id)).sort((a, b) => rank.get(a.id) - rank.get(b.id));
  COLUMNS.forEach((c, i) => { if (!rank.has(c.id)) { const prev = COLUMNS.slice(0, i).reverse().find(p => rank.has(p.id)); out.splice(prev ? out.indexOf(prev) + 1 : 0, 0, c); rank.set(c.id, -1); } });
  return out;
}
const visibleColumns = () => orderedColumns().filter(c => (!c.playlistOnly || isManualPlaylist()) && !hiddenCols.has(c.id));

// ---------------------------------------------------------------- sidebar
const ICONS = {
  all: '<svg viewBox="0 0 16 16"><path d="M3 3h10M3 8h10M3 13h10"/></svg>',
  missing: '<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6"/><path d="M8 5v3.5M8 11h.01"/></svg>',
  folder: '<svg viewBox="0 0 16 16"><path d="M1.5 4.5a1 1 0 0 1 1-1h3.5l1.5 1.5h6a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1h-11a1 1 0 0 1-1-1z"/></svg>',
  playlist: '<svg viewBox="0 0 16 16"><path d="M2 4h8M2 8h8M2 12h5"/><circle cx="12" cy="11.5" r="1.8"/><path d="M13.8 11.5V4.5l-1.5-.5"/></svg>',
  smart: '<svg viewBox="0 0 16 16"><path d="M8 1.8l1.6 4.1 4.1 1.6-4.1 1.6L8 13.2 6.4 9.1 2.3 7.5l4.1-1.6z"/></svg>',
};

function renderSidebar() {
  if (state.renaming) { state.sidebarStale = true; return; } // don't destroy an open rename field
  const lib = $('#lib-list'); lib.textContent = '';
  const missing = state.missingCount || 0;
  const items = [{ special: 'all', name: 'All tracks', icon: 'all', count: state.total }];
  if (missing) items.push({ special: 'missing', name: 'Missing files', icon: 'missing', count: missing });
  for (const it of items) {
    const active = !state.view.playlistId && state.view.special === it.special;
    lib.append(el('li', {}, el('div', { class: `node${active ? ' active' : ''}`, role: 'treeitem', tabindex: 0, onclick: () => selectView({ special: it.special }),
      html: `<span class="twist"></span>${ICONS[it.icon]}<span class="name">${esc(it.name)}</span><span class="count">${it.count.toLocaleString()}</span>` })));
  }
  const tree = $('#tree'); tree.textContent = '';
  const byParent = new Map();
  for (const p of state.playlists) { const k = p.parentId || 0; if (!byParent.has(k)) byParent.set(k, []); byParent.get(k).push(p); }
  const build = (parentId, depth, ul) => {
    for (const p of byParent.get(parentId) || []) {
      const open = state.expanded.has(p.id);
      const node = el('div', {
        class: `node ${p.type}${state.view.playlistId === p.id ? ' active' : ''}`, role: 'treeitem', tabindex: 0, 'aria-expanded': p.type === 'folder' ? String(open) : null,
        style: `padding-left:${4 + depth * 14}px`, dataset: { id: p.id },
        html: `<span class="twist">${p.type === 'folder' ? (open ? '▾' : '▸') : ''}</span>${ICONS[p.type]}<span class="name">${esc(p.name)}</span><span class="count">${p.count ?? ''}</span>`,
      });
      node.addEventListener('click', (e) => { if (e.target.classList.contains('twist') && p.type === 'folder') toggleFolder(p.id); else selectView({ playlistId: p.id }); });
      node.addEventListener('dblclick', (e) => { if (!e.target.classList.contains('twist')) startRename(node, p); });
      node.addEventListener('contextmenu', (e) => { e.preventDefault(); playlistMenu(p, e.clientX, e.clientY); });
      node.addEventListener('keydown', (e) => { if (e.key === 'Enter') startRename(node, p); });
      node.draggable = true;
      node.addEventListener('dragstart', (e) => { e.dataTransfer.setData('application/x-crate-playlist', String(p.id)); e.dataTransfer.effectAllowed = 'move'; });
      node.addEventListener('dragover', (e) => {
        const types = e.dataTransfer.types;
        if ((types.includes('application/x-crate-tracks') && p.type === 'playlist') || (types.includes('application/x-crate-playlist') && p.type === 'folder')) { e.preventDefault(); node.classList.add('drop'); }
      });
      node.addEventListener('dragleave', () => node.classList.remove('drop'));
      node.addEventListener('drop', async (e) => {
        e.preventDefault(); node.classList.remove('drop');
        const tracks = e.dataTransfer.getData('application/x-crate-tracks');
        const pl = e.dataTransfer.getData('application/x-crate-playlist');
        if (tracks && p.type === 'playlist') { const ids = JSON.parse(tracks); const n = await api('playlists.add', p.id, ids); toast(n ? `Added ${plural(n, 'track')} to ${p.name}` : `Already in ${p.name}`, n ? 'ok' : 'info'); refreshPlaylists(); }
        else if (pl && p.type === 'folder' && Number(pl) !== p.id) { await api('playlists.move', Number(pl), p.id); state.expanded.add(p.id); saveExpanded(); refreshPlaylists(); }
      });
      const li = el('li', { role: 'none' }, node); ul.append(li);
      if (p.type === 'folder' && open) { const sub = el('ul', { class: 'tree', role: 'group' }); li.append(sub); build(p.id, depth + 1, sub); }
    }
  };
  build(0, 0, tree);
  // dropping a playlist on empty sidebar space moves it to the top level
  tree.ondragover = (e) => { if (e.target === tree && e.dataTransfer.types.includes('application/x-crate-playlist')) e.preventDefault(); };
  tree.ondrop = async (e) => { const pl = e.dataTransfer.getData('application/x-crate-playlist'); if (pl && e.target === tree) { await api('playlists.move', Number(pl), null); refreshPlaylists(); } };
}
const saveExpanded = () => store.set('expanded', [...state.expanded]);
function toggleFolder(id) { state.expanded.has(id) ? state.expanded.delete(id) : state.expanded.add(id); saveExpanded(); renderSidebar(); }

function startRename(node, p) {
  const name = node.querySelector('.name'); const input = el('input', { value: p.name, 'aria-label': 'Playlist name' });
  name.replaceWith(input); input.focus(); input.select();
  let done = false; state.renaming = true;
  const finish = async (save) => {
    if (done) return; done = true; state.renaming = false;
    if (save && input.value.trim() && input.value.trim() !== p.name) { await api('playlists.update', p.id, { name: input.value.trim() }); }
    await refreshPlaylists();
    if (state.view.playlistId === p.id) $('#view-title').textContent = currentPlaylist()?.name || '';
  };
  input.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') finish(true); if (e.key === 'Escape') finish(false); });
  input.addEventListener('blur', () => finish(true));
  input.addEventListener('click', (e) => e.stopPropagation());
}

async function refreshPlaylists() {
  const [pls, total] = await Promise.all([api('playlists.list'), api('tracks.count')]);
  state.playlists = pls; state.total = total;
  if (state.view.playlistId && !currentPlaylist()) state.view.playlistId = null;
  renderSidebar();
}
async function newPlaylist(type, parentId = null) {
  if (type === 'smart') return smartEditor(null, parentId);
  const name = type === 'folder' ? 'New folder' : 'New playlist';
  const id = await api('playlists.create', { name, type, parentId });
  if (parentId) { state.expanded.add(parentId); saveExpanded(); }
  await refreshPlaylists();
  if (type === 'playlist') { state.view.playlistId = id; state.view.special = null; renderSidebar(); }
  const node = $(`#tree .node[data-id="${id}"]`); if (node) startRename(node, state.playlists.find(p => p.id === id));
  if (type === 'playlist') { state.selection.clear(); loadTracks(); renderInspector(); }
}
function folderChoices(excludeId) {
  const out = [{ id: null, name: 'Top level' }];
  const isInside = (p) => { for (let c = p; c; c = state.playlists.find(x => x.id === c.parentId)) if (c.id === excludeId) return true; return false; };
  for (const p of state.playlists) if (p.type === 'folder' && !isInside(p)) out.push({ id: p.id, name: p.name });
  return out;
}
function playlistMenu(p, x, y) {
  const items = [{ label: 'Rename', run: () => startRename($(`#tree .node[data-id="${p.id}"]`), p) }];
  if (p.type === 'smart') items.push({ label: 'Edit rules…', run: () => smartEditor(p) });
  if (p.type === 'folder') items.push({ label: 'New playlist inside', run: () => newPlaylist('playlist', p.id) }, { label: 'New smartlist inside', run: () => newPlaylist('smart', p.id) }, { label: 'New folder inside', run: () => newPlaylist('folder', p.id) });
  items.push('-');
  for (const f of folderChoices(p.id)) if (f.id !== p.parentId && f.id !== p.id) items.push({ label: `Move to ${f.name}`, run: async () => { await api('playlists.move', p.id, f.id); refreshPlaylists(); } });
  items.push('-', { label: p.type === 'folder' ? 'Delete folder and its playlists' : 'Delete', danger: true, run: async () => {
    if (!(await confirmBox(`Delete “${p.name}”?`, p.type === 'folder' ? 'Everything inside this folder is deleted too. Your music files are not touched.' : 'Your music files are not touched.', 'Delete'))) return;
    await api('playlists.delete', p.id); if (state.view.playlistId === p.id) selectView({ special: 'all' }); refreshPlaylists();
  } });
  popMenu(items, x, y);
}

// ---------------------------------------------------------------- tracks & table
async function selectView(v) {
  state.view.playlistId = v.playlistId || null; state.view.special = v.special || (v.playlistId ? null : 'all');
  state.selection.clear(); state.anchor = state.focus = -1;
  renderSidebar(); await loadTracks(); renderInspector();
}
async function loadTracks({ keepScroll = false } = {}) {
  const v = state.view;
  const query = { playlistId: v.playlistId, search: v.search, sort: v.sort, dir: v.dir };
  if (isManualPlaylist() && !v.sortedInPlaylist) { query.sort = 'position'; query.dir = 'asc'; }
  let rows = await api('tracks.list', query);
  // The missing-files count is only recomputed from the unfiltered library list.
  if (!v.playlistId && !v.search) state.missingCount = rows.filter(t => t.missing).length;
  if (v.special === 'missing') rows = rows.filter(t => t.missing);
  state.tracks = rows;
  const ids = new Set(rows.map(t => t.id)); for (const id of [...state.selection]) if (!ids.has(id)) state.selection.delete(id);
  const pl = currentPlaylist();
  $('#view-title').textContent = pl ? pl.name : v.special === 'missing' ? 'Missing files' : 'All tracks';
  const secs = rows.reduce((s, t) => s + (t.duration || 0), 0);
  $('#view-meta').textContent = `${plural(rows.length, 'track')} · ${fmtTime(secs)}${v.search ? ` matching “${v.search}”` : ''}`;
  if (!keepScroll) $('#tbody').scrollTop = 0;
  renderHeader(); renderRows(); renderSidebar();
}
// Column widths. Until a column is resized, columns share the window's width. Once one is dragged,
// every column gets a fixed width in pixels (remembered between launches), an empty filler column
// takes up any spare room, and the list scrolls sideways when the columns are wider than the window.
let colWidths = store.get('colWidths', null); // { columnId: px } or null
const MIN_COL = 36;
const defaultPx = (c) => { const m = /(\d+)px/.exec(c.width); const n = m ? +m[1] : 80; return c.width.includes('fr') ? Math.round(n * 1.3) : n; };
const colPx = (c) => Math.max(MIN_COL, Math.round(colWidths[c.id] || defaultPx(c)));
function gridTemplate() {
  if (!colWidths) return visibleColumns().map(c => c.width).join(' ');
  return visibleColumns().map(c => `${colPx(c)}px`).join(' ') + ' minmax(0, 1fr)';
}
function applyColumnWidths() {
  const table = $('#table'); table.style.setProperty('--cols', gridTemplate());
  // The rows sit beside a vertical scrollbar (when macOS shows one); the header leaves the same gap so columns line up.
  const tb = $('#tbody'); table.style.setProperty('--sbw', `${Math.max(0, tb.offsetWidth - tb.clientWidth)}px`);
  if (colWidths) {
    const w = visibleColumns().reduce((a, c) => a + colPx(c), 0) + 16;
    table.style.setProperty('--tablew', `${w}px`); table.style.setProperty('--theadw', `calc(${w}px + var(--sbw, 0px))`);
  } else { table.style.removeProperty('--tablew'); table.style.removeProperty('--theadw'); }
}
function resetColumnWidths() { colWidths = null; store.set('colWidths', null); renderHeader(); renderRows(); }
// Fits a column to the widest of its header and the rows currently drawn.
function autoFitColumn(c) {
  const k = visibleColumns().indexOf(c); if (k < 0) return;
  let w = 0;
  const th = $('#thead').children[k]; if (th) { const lbl = th.querySelector('.th-label'); w = (lbl ? lbl.scrollWidth : th.scrollWidth) + 28; }
  for (const row of $('#rows').children) { const td = row.children[k]; if (td) w = Math.max(w, td.scrollWidth + 2); }
  freezeColumnWidths(); colWidths[c.id] = Math.min(800, Math.max(MIN_COL, Math.ceil(w))); store.set('colWidths', colWidths); applyColumnWidths();
}
// Switches to fixed widths using the sizes the columns have on screen right now, so nothing jumps.
function freezeColumnWidths() {
  if (colWidths) return;
  colWidths = {}; const ths = [...$('#thead').children];
  visibleColumns().forEach((c, i) => { if (ths[i]) colWidths[c.id] = Math.round(ths[i].getBoundingClientRect().width); });
}
let suppressSortUntil = 0;
function startColumnResize(e, c, th) {
  e.preventDefault(); e.stopPropagation();
  freezeColumnWidths();
  const startX = e.clientX, startW = colWidths[c.id] || th.getBoundingClientRect().width;
  document.body.classList.add('col-resizing'); th.classList.add('resizing');
  const move = (ev) => { colWidths[c.id] = Math.max(MIN_COL, Math.round(startW + ev.clientX - startX)); applyColumnWidths(); };
  const up = () => {
    window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up, true);
    document.body.classList.remove('col-resizing'); th.classList.remove('resizing');
    suppressSortUntil = Date.now() + 250; store.set('colWidths', colWidths);
  };
  window.addEventListener('mousemove', move); window.addEventListener('mouseup', up, true);
}
function renderHeader() {
  applyColumnWidths(); const head = $('#thead'); head.textContent = '';
  const manual = isManualPlaylist() && !state.view.sortedInPlaylist;
  for (const c of visibleColumns()) {
    const sorted = manual ? c.id === 'position' : state.view.sort === c.id;
    const th = el('div', { class: `th${c.num ? ' num' : ''}${sorted ? ' sorted' : ''}${sorted && !manual && state.view.dir === 'desc' ? ' desc' : ''}`, role: 'columnheader', title: `Sort by ${c.label}` },
      el('span', { class: 'th-label', text: c.label }),
      el('span', { class: 'col-resize', title: 'Drag to resize. Double-click to fit.', 'aria-hidden': 'true',
        onmousedown: (e) => { if (e.button === 0 && e.detail < 2) startColumnResize(e, c, th); },
        onclick: (e) => e.stopPropagation(),
        ondblclick: (e) => { e.preventDefault(); e.stopPropagation(); suppressSortUntil = Date.now() + 250; autoFitColumn(c); } }));
    th.addEventListener('mousedown', (e) => { if (e.button === 0 && !e.target.closest('.col-resize')) startColumnMove(e, c, th); });
    th.addEventListener('click', () => {
      if (Date.now() < suppressSortUntil) return; // the end of a resize or move drag, not a sort
      if (c.id === 'position') { state.view.sortedInPlaylist = false; }
      else {
        if (isManualPlaylist() && !state.view.sortedInPlaylist) { state.view.sortedInPlaylist = true; state.view.sort = c.id; state.view.dir = 'asc'; }
        else if (state.view.sort === c.id) state.view.dir = state.view.dir === 'asc' ? 'desc' : 'asc'; else { state.view.sort = c.id; state.view.dir = c.num || c.id === 'rating' ? 'desc' : 'asc'; }
        store.set('sort', { sort: state.view.sort, dir: state.view.dir });
      }
      loadTracks({ keepScroll: true });
    });
    head.append(th);
  }
}
// Drag a header sideways to move the column. A press without moving is still a click (sort).
function startColumnMove(e, c, th) {
  const head = $('#thead'); const startX = e.clientX; let moving = false, target = -1;
  const marker = el('div', { class: 'col-drop-marker', 'aria-hidden': 'true' });
  const cols = visibleColumns(); const from = cols.indexOf(c);
  const move = (ev) => {
    const dx = ev.clientX - startX;
    if (!moving) { if (Math.abs(dx) < 5) return; moving = true; th.classList.add('moving'); document.body.classList.add('col-moving'); head.append(marker); }
    th.style.transform = `translateX(${dx}px)`;
    // Drop slot: the gap nearest the pointer (between header cells).
    const cells = [...head.querySelectorAll('.th')]; const hr = head.getBoundingClientRect();
    let best = 0, bestD = Infinity;
    for (let i = 0; i <= cells.length; i++) {
      const x = i < cells.length ? cells[i].getBoundingClientRect().left : cells[cells.length - 1].getBoundingClientRect().right;
      const d = Math.abs(ev.clientX - x); if (d < bestD) { bestD = d; best = i; }
    }
    target = best;
    const edge = best < cells.length ? cells[best].getBoundingClientRect().left : cells[cells.length - 1].getBoundingClientRect().right;
    marker.style.left = `${edge - hr.left - 1}px`;
    marker.hidden = best === from || best === from + 1; // dropping it where it is
  };
  const up = () => {
    window.removeEventListener('mousemove', move); window.removeEventListener('mouseup', up, true);
    if (!moving) return;
    th.classList.remove('moving'); th.style.transform = ''; document.body.classList.remove('col-moving'); marker.remove();
    suppressSortUntil = Date.now() + 250;
    if (target < 0 || target === from || target === from + 1) return;
    // Move within the full order, so hidden and playlist-only columns keep their places.
    const all = orderedColumns().map(x => x.id);
    const before = target < cols.length ? cols[target].id : null;
    all.splice(all.indexOf(c.id), 1);
    all.splice(before ? all.indexOf(before) : all.indexOf(cols[cols.length - 1].id) + 1, 0, c.id);
    colOrder = all; store.set('colOrder', colOrder); renderHeader(); renderRows();
  };
  window.addEventListener('mousemove', move); window.addEventListener('mouseup', up, true);
}
function resetColumnOrder() { colOrder = null; store.set('colOrder', null); renderHeader(); renderRows(); }

$('#thead').addEventListener('contextmenu', (e) => {
  e.preventDefault();
  popMenu([...orderedColumns().filter(c => !c.fixed && !c.playlistOnly).map(c => ({ label: `${hiddenCols.has(c.id) ? '   ' : '✓ '}${c.label}`, run: () => {
    hiddenCols.has(c.id) ? hiddenCols.delete(c.id) : hiddenCols.add(c.id); store.set('hiddenCols', [...hiddenCols]); renderHeader(); renderRows();
  } })), ...(colWidths || colOrder ? ['-'] : []), ...(colOrder ? [{ label: 'Reset column order', run: resetColumnOrder }] : []), ...(colWidths ? [{ label: 'Reset column widths', run: resetColumnWidths }] : [])], e.clientX, e.clientY);
});
let rafPending = false;
function renderRows() {
  const body = $('#tbody'); const rows = $('#rows'); const n = state.tracks.length;
  $('#spacer').style.height = `${n * ROW}px`;
  const empty = $('#empty');
  if (!n) {
    rows.textContent = ''; empty.hidden = false;
    const pl = currentPlaylist();
    empty.innerHTML = state.view.search ? `<h2>No tracks match “${esc(state.view.search)}”</h2><p>Try fewer words, or search a different part of the title or artist.</p>`
      : pl && pl.type === 'playlist' ? '<h2>This playlist is empty</h2><p>Drag tracks from All tracks onto the playlist in the sidebar.</p>'
      : pl && pl.type === 'smart' ? '<h2>No tracks match these rules</h2><p>Right-click the smartlist and choose Edit rules to widen them.</p>'
      : state.view.special === 'missing' ? '<h2>No missing files</h2><p>Every track in your library points at a file that exists.</p>'
      : '<h2>Your library is empty</h2><p>Import a folder of music to get started. You can also drag folders from Finder onto this window.</p><div class="row-inline center"><button class="btn primary" id="empty-import">Import a folder</button><button class="btn" id="empty-rb">From rekordbox</button><button class="btn" id="empty-engine">From Engine DJ</button></div>';
    $('#empty-import')?.addEventListener('click', () => doImport());
    $('#empty-rb')?.addEventListener('click', () => externalImportDialog('rekordbox'));
    $('#empty-engine')?.addEventListener('click', () => externalImportDialog('engine'));
    return;
  }
  empty.hidden = true;
  const start = Math.max(0, Math.floor(body.scrollTop / ROW) - 8);
  const end = Math.min(n, Math.ceil((body.scrollTop + body.clientHeight) / ROW) + 8);
  const cols = visibleColumns(); const parts = [];
  for (let i = start; i < end; i++) {
    const t = state.tracks[i];
    const cls = ['tr']; if (state.selection.has(t.id)) cls.push('sel'); if (i === state.focus) cls.push('focus'); if (t.id === state.playingId) cls.push('playing'); if (t.missing) cls.push('missing');
    parts.push(`<div class="${cls.join(' ')}" role="row" aria-selected="${state.selection.has(t.id)}" data-i="${i}" draggable="true">` +
      cols.map(c => `<div class="td${c.num ? ' num' : ''}${c.cls ? ' ' + c.cls : ''}" role="gridcell">${c.render(t)}</div>`).join('') + '</div>');
  }
  rows.style.transform = `translateY(${start * ROW}px)`; rows.innerHTML = parts.join('');
  const tb = $('#tbody'), sbw = `${Math.max(0, tb.offsetWidth - tb.clientWidth)}px`; if ($('#table').style.getPropertyValue('--sbw') !== sbw) $('#table').style.setProperty('--sbw', sbw);
}
$('#tbody').addEventListener('scroll', (e) => { $('#thead').style.transform = e.target.scrollLeft ? `translateX(${-e.target.scrollLeft}px)` : ''; if (!rafPending) { rafPending = true; requestAnimationFrame(() => { rafPending = false; renderRows(); }); } });
window.addEventListener('resize', debounce(renderRows, 50));

function rowIndex(e) { const r = e.target.closest('.tr'); return r ? Number(r.dataset.i) : -1; }
function selectIndex(i, { toggle = false, range = false } = {}) {
  const t = state.tracks[i]; if (!t) return;
  if (range && state.anchor >= 0) {
    if (!toggle) state.selection.clear();
    const [a, b] = [Math.min(state.anchor, i), Math.max(state.anchor, i)];
    for (let k = a; k <= b; k++) state.selection.add(state.tracks[k].id);
  } else if (toggle) { state.selection.has(t.id) ? state.selection.delete(t.id) : state.selection.add(t.id); state.anchor = i; }
  else { state.selection.clear(); state.selection.add(t.id); state.anchor = i; }
  state.focus = i; renderRows(); renderInspector();
}
function scrollToIndex(i) {
  const body = $('#tbody'); const top = i * ROW;
  if (top < body.scrollTop) body.scrollTop = top; else if (top + ROW > body.scrollTop + body.clientHeight) body.scrollTop = top + ROW - body.clientHeight;
}
const selectedIds = () => state.tracks.filter(t => state.selection.has(t.id)).map(t => t.id);

$('#rows').addEventListener('mousedown', (e) => {
  const i = rowIndex(e); if (i < 0 || e.button !== 0) return;
  const t = state.tracks[i];
  // A double-click is detected here: the first click redraws the rows, so the browser's own
  // dblclick event never reaches the row under the pointer.
  if (e.detail === 2 && !e.shiftKey && !e.metaKey && !e.ctrlKey) { state.pendingSingle = undefined; play(t); return; }
  if (state.selection.has(t.id) && !e.shiftKey && !e.metaKey && !e.ctrlKey) { state.pendingSingle = i; return; } // may start a drag of the selection
  selectIndex(i, { toggle: e.metaKey || e.ctrlKey, range: e.shiftKey });
  focusTable();
});
// Rows are re-rendered on click, which detaches the clicked node; refocus after the browser's default handling.
function focusTable() { setTimeout(() => $('#table').focus({ preventScroll: true }), 0); }
$('#rows').addEventListener('click', (e) => { const i = rowIndex(e); if (state.pendingSingle === i && i >= 0) selectIndex(i); state.pendingSingle = undefined; focusTable(); });
$('#rows').addEventListener('contextmenu', (e) => {
  e.preventDefault(); const i = rowIndex(e); if (i < 0) return;
  if (!state.selection.has(state.tracks[i].id)) selectIndex(i);
  trackMenu(e.clientX, e.clientY);
});
// drag tracks to playlists / reorder inside a playlist
$('#rows').addEventListener('dragstart', (e) => {
  const i = rowIndex(e); if (i < 0) return;
  if (!state.selection.has(state.tracks[i].id)) selectIndex(i);
  state.pendingSingle = undefined;
  const ids = selectedIds();
  e.dataTransfer.setData('application/x-crate-tracks', JSON.stringify(ids));
  e.dataTransfer.effectAllowed = 'copyMove';
  const ghost = el('div', { class: 'toast', style: 'position:fixed;top:-100px;left:0;width:auto', text: plural(ids.length, 'track') }); document.body.append(ghost);
  e.dataTransfer.setDragImage(ghost, 10, 10); setTimeout(() => ghost.remove(), 0);
});
const canReorder = () => isManualPlaylist() && !state.view.sortedInPlaylist && !state.view.search;
$('#rows').addEventListener('dragover', (e) => {
  if (!canReorder() || !e.dataTransfer.types.includes('application/x-crate-tracks')) return;
  e.preventDefault(); document.querySelectorAll('.tr.drop-above').forEach(r => r.classList.remove('drop-above'));
  e.target.closest('.tr')?.classList.add('drop-above');
});
$('#rows').addEventListener('dragleave', () => document.querySelectorAll('.tr.drop-above').forEach(r => r.classList.remove('drop-above')));
$('#rows').addEventListener('drop', async (e) => {
  if (!canReorder()) return; e.preventDefault();
  const i = rowIndex(e); if (i < 0) return;
  const moving = new Set(JSON.parse(e.dataTransfer.getData('application/x-crate-tracks') || '[]'));
  const before = state.tracks.slice(0, i).filter(t => !moving.has(t.id)).map(t => t.id);
  const after = state.tracks.slice(i).filter(t => !moving.has(t.id)).map(t => t.id);
  const order = [...before, ...state.tracks.filter(t => moving.has(t.id)).map(t => t.id), ...after];
  await api('playlists.reorder', state.view.playlistId, order); await loadTracks({ keepScroll: true });
});

// Track-list shortcuts work whenever you're not typing in a field.
async function tableKeys(e) {
  const n = state.tracks.length; if (!n) return;
  const mod = e.metaKey || e.ctrlKey;
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault(); const i = Math.max(0, Math.min(n - 1, (state.focus < 0 ? -1 : state.focus) + (e.key === 'ArrowDown' ? 1 : -1)));
    selectIndex(i, { range: e.shiftKey }); scrollToIndex(i);
  } else if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); state.tracks.forEach(t => state.selection.add(t.id)); renderRows(); renderInspector(); }
  else if (e.key === 'Enter') { const t = state.tracks[state.focus]; if (t) play(t); }
  else if (e.key === 'Backspace' || e.key === 'Delete') { e.preventDefault(); removeSelected(); }
  else if (/^[0-5]$/.test(e.key) && !mod && state.selection.size) { await api('tracks.update', selectedIds(), { rating: Number(e.key) }); await loadTracks({ keepScroll: true }); renderInspector(); }
}

async function removeSelected() {
  const ids = selectedIds(); if (!ids.length) return;
  const pl = currentPlaylist();
  if (pl && pl.type === 'playlist') { await api('playlists.remove', pl.id, ids); await loadTracks({ keepScroll: true }); refreshPlaylists(); return; }
  if (await confirmBox(`Remove ${plural(ids.length, 'track')} from your library?`, 'The files stay on your disk and in any other DJ software. You can import them again later.', 'Remove from library')) {
    await api('tracks.remove', ids); state.selection.clear(); await loadTracks({ keepScroll: true }); refreshPlaylists(); renderInspector();
  }
}

function trackMenu(x, y) {
  const ids = selectedIds(); const one = ids.length === 1 ? state.tracks.find(t => t.id === ids[0]) : null;
  const pl = currentPlaylist();
  const items = [];
  if (one) items.push({ label: 'Play preview', hint: '↵', run: () => play(one) });
  const targets = state.playlists.filter(p => p.type === 'playlist' && p.id !== pl?.id);
  if (targets.length) {
    items.push('-');
    for (const p of targets.slice(0, 14)) items.push({ label: `Add to ${p.name}`, run: async () => { const n = await api('playlists.add', p.id, ids); toast(n ? `Added ${plural(n, 'track')} to ${p.name}` : `Already in ${p.name}`, n ? 'ok' : 'info'); refreshPlaylists(); } });
  }
  items.push({ label: 'Add to new playlist…', run: async () => {
    const name = await promptBox('New playlist', 'Name', 'New playlist'); if (!name) return;
    const id = await api('playlists.create', { name, type: 'playlist' }); await api('playlists.add', id, ids); await refreshPlaylists(); toast(`Created ${name} with ${plural(ids.length, 'track')}`, 'ok');
  } });
  items.push('-', { label: ids.length > 1 ? `Write tags to ${ids.length} files` : 'Write tags to file', run: () => writeTagsToFiles(ids) });
  items.push('-', { label: 'Fix titles & artists…', run: () => fixesDialog() }, { label: 'Find & replace…', run: () => replaceDialog() });
  if (one) {
    items.push('-', { label: 'Show in Finder', run: () => api('tracks.reveal', one.id) });
    if (one.missing) items.push({ label: 'Locate file…', run: async () => { const r = await api('tracks.relocate', one.id); if (r) { toast('Track relinked', 'ok'); loadTracks({ keepScroll: true }); } } });
  }
  items.push('-');
  if (pl && pl.type === 'playlist') items.push({ label: `Remove from ${pl.name}`, hint: '⌫', run: removeSelected });
  else items.push({ label: 'Remove from library…', hint: '⌫', danger: true, run: removeSelected });
  popMenu(items, x, y);
}

// ---------------------------------------------------------------- inspector
const EDIT_FIELDS = [
  ['title', 'Title', 'wide'], ['artist', 'Artist', 'wide'], ['remixer', 'Remixer'], ['mix', 'Mix'], ['album', 'Album', 'wide'],
  ['genre', 'Genre'], ['label', 'Label'], ['bpm', 'BPM'], ['key', 'Key'], ['year', 'Year'], ['trackNumber', 'Track #'],
  ['composer', 'Composer'], ['grouping', 'Grouping'], ['comment', 'Comment', 'wide area'],
];
// ---------------------------------------------------------------- cue pane (left, above the player)
// Shows the cue points of the selected track, or of the playing track when one track isn't selected.
let cuePaneFor = null;
async function renderCuePane() {
  const pane = $('#cue-pane');
  const sel = state.tracks.filter(t => state.selection.has(t.id));
  const playing = state.playingId ? (state.tracks.find(x => x.id === state.playingId) || state.playingTrack) : null;
  const t = [sel.length === 1 ? sel[0] : null, playing].find(x => x && x.cues) || null;
  if (!t) { pane.hidden = true; pane.textContent = ''; cuePaneFor = null; return; }
  const isPlaying = t.id === state.playingId;
  const key = `${t.id}:${t.cues}:${isPlaying}`; if (cuePaneFor === key && !pane.hidden) return; cuePaneFor = key;
  let cs; try { cs = await api('tracks.cues', t.id); } catch { return; }
  if (cuePaneFor !== key) return; // selection changed meanwhile
  pane.textContent = ''; pane.hidden = false;
  const list = el('div', { class: 'cue-list', role: 'list' });
  pane.append(el('h3', { class: 'cue-head' }, el('span', { text: `Cue points (${cs.length})` }), isPlaying ? el('span', { class: 'cue-playing', text: 'Playing' }) : null), el('div', { class: 'cue-track', text: [t.artist, t.title].filter(Boolean).join(' – '), title: [t.artist, t.title].filter(Boolean).join(' – ') }), list);
  for (const c of cs) {
    const chip = el('span', { class: `cue-chip ${c.kind}`, text: c.kind === 'hot' ? 'ABCDEFGH'[c.num] : c.kind === 'loop' ? `L${c.num + 1}` : 'M' });
    if (c.color) chip.style.setProperty('--cue', c.color);
    list.append(el('button', { class: 'cue-row', type: 'button', role: 'listitem', title: `Play from ${fmtCue(c.start)}`, onclick: () => { playFrom(t, c.start); focusTable(); } },
      chip, el('span', { class: 'cue-time', text: fmtCue(c.start) + (c.end != null ? `–${fmtCue(c.end)}` : '') }),
      el('span', { class: 'cue-name', text: c.name || (c.kind === 'memory' ? (c.end != null ? 'Memory loop' : 'Memory cue') : c.end != null && c.kind === 'hot' ? 'Hot loop' : '') })));
  }
}

function renderInspector() {
  renderCuePane();
  const box = $('#inspector'); box.textContent = '';
  const sel = state.tracks.filter(t => state.selection.has(t.id));
  if (!sel.length) { box.append(el('p', { class: 'placeholder', text: 'Select a track to edit its tags. Changes are saved into the music files, so other DJ apps see them too.' })); return; }
  const one = sel.length === 1 ? sel[0] : null;
  box.append(el('h2', { text: one ? one.title : `${sel.length} tracks selected` }), el('div', { class: 'sub', text: one ? (one.artist || 'Unknown artist') : 'Fields you change apply to all of them. Fields left as “Mixed” keep each track’s own value.' }));
  const changes = {}; const form = el('form', { class: 'form' });
  const common = (f) => { const v = sel[0][f]; return sel.every(t => t[f] === v) ? v : undefined; };
  const show = (f, v) => (f === 'bpm' || f === 'year' || f === 'trackNumber') && !v ? '' : f === 'key' ? (v ? CrateKeys.format(v, state.notation) : '') : (v ?? '');
  const save = el('button', { class: 'btn primary', type: 'submit', disabled: true, text: sel.length > 1 ? `Save to ${sel.length} files` : 'Save to file' });
  const revert = el('button', { class: 'btn', type: 'button', disabled: true, text: 'Revert', onclick: () => renderInspector() });
  // "Save to file" also renames the files to "Artist - Title", so it's enabled when a file only needs renaming too.
  let needsRename = 0;
  const mark = () => { const any = Object.keys(changes).length > 0; revert.disabled = !any; save.disabled = !(any || needsRename); };
  const ids = sel.map(t => t.id);
  api('files.previewRename', ids).then(plan => { needsRename = plan.filter(p => p.status === 'rename').length; mark(); }).catch(() => {});
  for (const [f, label, extra = ''] of EDIT_FIELDS) {
    const v = common(f);
    const attrs = { id: `f-${f}`, name: f, value: v === undefined ? '' : show(f, v), placeholder: v === undefined ? 'Mixed' : '', autocomplete: 'off', spellcheck: 'false' };
    if (f === 'genre') attrs.list = 'genre-list';
    if (['bpm', 'year', 'trackNumber'].includes(f)) attrs.inputmode = 'decimal';
    const input = extra.includes('area') ? el('textarea', { ...attrs, value: undefined, text: attrs.value }) : el('input', { type: 'text', ...attrs });
    input.addEventListener('input', () => { const orig = v === undefined ? '' : String(show(f, v)); if (input.value !== orig) { changes[f] = input.value; input.classList.add('changed'); } else { delete changes[f]; input.classList.remove('changed'); } mark(); });
    form.append(el('div', { class: `field ${extra.includes('wide') ? 'wide' : ''}` }, el('label', { for: attrs.id, text: label }), input));
  }
  // rating
  const r = common('rating'); const rating = el('div', { class: 'rating-input', role: 'radiogroup', 'aria-label': 'Rating' });
  const paint = (n) => rating.querySelectorAll('button').forEach((b, i) => b.classList.toggle('on', i < n));
  for (let i = 1; i <= 5; i++) rating.append(el('button', { type: 'button', 'aria-label': `${i} star${i > 1 ? 's' : ''}`, text: '★', onclick: () => { const val = (changes.rating ?? r) === i ? 0 : i; changes.rating = val; paint(val); mark(); } }));
  paint(r || 0);
  form.append(el('div', { class: 'field wide' }, el('label', { text: r === undefined ? 'Rating (mixed)' : 'Rating' }), rating));
  form.append(el('div', { class: 'form-actions field wide' }, save, revert),
    el('p', { class: 'field wide save-note', text: `Saving writes the tags into the ${sel.length > 1 ? 'files' : 'file'} and renames ${sel.length > 1 ? 'them' : 'it'} to “Artist - Title”.` }));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const edited = Object.keys(changes).length > 0;
    save.disabled = true;
    // 1. tags into the files, 2. rename the files to "Artist - Title" (with the new artist/title)
    const res = edited ? await api('tracks.update', ids, changes) : { fileErrors: [] };
    const ren = await api('files.rename', ids);
    const what = sel.length > 1 ? plural(sel.length, 'track') : '';
    const bits = [edited ? `Saved${what ? ' ' + what : ''}` : null, ren.renamed ? `renamed ${plural(ren.renamed, 'file')} to “Artist - Title”` : null].filter(Boolean);
    let msg = bits.length ? bits.join(', ') : 'Nothing to save';
    msg = msg[0].toUpperCase() + msg.slice(1) + '.';
    const errs = [...res.fileErrors.map(x => x.error), ...ren.errors.map(x => x.error)];
    if (errs.length) msg += ` ${plural(errs.length, 'file')} couldn’t be changed: ${errs[0]}`;
    toast(msg, errs.length ? 'error' : 'ok', { timeout: ren.renamed ? 9000 : (errs.length ? 9000 : 2200), action: ren.renamed ? { label: 'Undo rename', run: async () => {
      const u = await api('files.undoRename');
      toast(u.errors.length ? `Restored ${plural(u.restored, 'file name')}; ${u.errors.length} couldn’t be: ${u.errors[0].error}` : `Restored ${plural(u.restored, 'file name')}`, u.errors.length ? 'error' : 'ok');
      await loadTracks({ keepScroll: true }); renderInspector();
    } } : null });
    await loadTracks({ keepScroll: true }); renderInspector(); refreshGenres();
  });
  box.append(form);
  if (one) {
    const facts = el('dl', { class: 'facts' });
    const add = (k, v) => facts.append(el('dt', { text: k }), el('dd', {}, v));
    add('Length', fmtTime(one.duration)); add('Format', `${(({ mp4: 'M4A' })[one.format] || one.format.toUpperCase())}, ${one.bitrate} kbps, ${(one.sampleRate / 1000).toFixed(1)} kHz`);
    add('Size', fmtSize(one.size)); add('Added', new Date(one.dateAdded).toLocaleDateString());
    add('File', el('span', {}, el('span', { text: one.path }), ' ', el('button', { class: 'linkish', type: 'button', text: 'Show in Finder', onclick: () => api('tracks.reveal', one.id) })));
    if (one.missing) add('Status', el('button', { class: 'linkish', type: 'button', text: 'File missing. Locate it…', onclick: async () => { const r2 = await api('tracks.relocate', one.id); if (r2) loadTracks({ keepScroll: true }); } }));
    box.append(facts);
  }
}
async function refreshGenres() {
  const g = await api('tracks.distinct', 'genre'); let dl = $('#genre-list');
  if (!dl) { dl = el('datalist', { id: 'genre-list' }); document.body.append(dl); }
  dl.textContent = ''; for (const x of g) dl.append(el('option', { value: x.value }));
  state.genres = g;
}

// ---------------------------------------------------------------- player
const audio = $('#audio');
const fmtCue = (s) => { const m = Math.floor(s / 60), x = s - m * 60; return `${m}:${x.toFixed(2).padStart(5, '0')}`; };
// Cue marks on the progress bar for the track that's playing.
async function showCueMarks(t) {
  const box = $('#cue-marks'); box.textContent = '';
  if (!t.cues || !t.duration) return;
  let cs = []; try { cs = await api('tracks.cues', t.id); } catch { return; }
  if (state.playingId !== t.id) return;
  for (const c of cs) {
    const pct = (p) => Math.max(0, Math.min(1, p / t.duration));
    const mark = el('button', { class: `cue-mark ${c.kind}`, type: 'button', tabindex: '-1', title: `${c.kind === 'hot' ? 'Hot cue ' + 'ABCDEFGH'[c.num] : c.kind === 'loop' ? 'Loop ' + (c.num + 1) : 'Memory cue'} · ${fmtCue(c.start)}${c.name ? ' · ' + c.name : ''}`,
      onclick: () => playFrom(t, c.start) });
    mark.style.setProperty('--at', pct(c.start)); if (c.end != null) mark.style.setProperty('--len', pct(c.end) - pct(c.start));
    if (c.color) mark.style.setProperty('--cue', c.color);
    box.append(mark);
  }
}
async function playFrom(t, sec) {
  if (state.playingId !== t.id || !audio.src) {
    await play(t);
    if (audio.readyState < 1) await new Promise(r => audio.addEventListener('loadedmetadata', r, { once: true }));
  }
  audio.currentTime = sec; if (audio.paused) audio.play().catch(() => {});
}
async function play(t) {
  if (t.missing) { toast('This file is missing. Right-click the track and choose Locate file.', 'error'); return; }
  state.playingId = t.id; state.playingTrack = t; audio.src = await api('tracks.audioUrl', t.id); showCueMarks(t); renderCuePane();
  try { await audio.play(); } catch (e) { toast(`Can't play this file: ${e.message}`, 'error'); }
  $('#now-title').textContent = t.title; $('#now-artist').textContent = [t.artist, t.bpm ? `${Math.round(t.bpm)} BPM` : '', t.key ? CrateKeys.format(t.key, state.notation) : ''].filter(Boolean).join('  ·  ');
  renderRows();
}
function togglePlay() {
  if (!audio.src) { const t = state.tracks[state.focus >= 0 ? state.focus : 0]; if (t) play(t); return; }
  audio.paused ? audio.play() : audio.pause();
}
$('#play').addEventListener('click', togglePlay);
audio.addEventListener('play', () => $('#player').classList.add('is-playing'));
audio.addEventListener('pause', () => $('#player').classList.remove('is-playing'));
audio.addEventListener('timeupdate', () => { $('#time-cur').textContent = fmtTime(audio.currentTime); if (!state.seeking && audio.duration) $('#seek').value = Math.round(audio.currentTime / audio.duration * 1000); });
audio.addEventListener('loadedmetadata', () => { $('#time-dur').textContent = fmtTime(audio.duration); });
audio.addEventListener('ended', () => { const i = state.tracks.findIndex(t => t.id === state.playingId); const next = state.tracks[i + 1]; if (next) play(next); });
audio.addEventListener('error', () => { if (audio.src) toast('This file could not be played.', 'error'); });
$('#seek').addEventListener('input', () => { state.seeking = true; });
$('#seek').addEventListener('change', (e) => { state.seeking = false; if (audio.duration) audio.currentTime = e.target.value / 1000 * audio.duration; });
$('#volume').addEventListener('input', (e) => { audio.volume = e.target.value / 100; store.set('volume', +e.target.value); });
audio.volume = store.get('volume', 80) / 100; $('#volume').value = store.get('volume', 80);

// ---------------------------------------------------------------- popover menus
let openMenu = null;
function closeMenu() { if (openMenu) { openMenu.remove(); openMenu = null; } }
function popMenu(items, x, y) {
  closeMenu();
  const m = el('div', { class: 'popmenu', role: 'menu' });
  for (const it of items) {
    if (it === '-') { if (m.lastChild && m.lastChild.tagName !== 'HR') m.append(el('hr')); continue; }
    m.append(el('button', { role: 'menuitem', class: it.danger ? 'danger' : '', onclick: () => { closeMenu(); it.run(); } }, el('span', { text: it.label }), it.hint ? el('span', { class: 'hint', text: it.hint }) : null));
  }
  if (m.lastChild?.tagName === 'HR') m.lastChild.remove();
  document.body.append(m);
  const r = m.getBoundingClientRect();
  m.style.left = `${Math.min(x, innerWidth - r.width - 8)}px`; m.style.top = `${Math.min(y, innerHeight - r.height - 8)}px`;
  m.querySelector('button')?.focus();
  m.addEventListener('keydown', (e) => {
    const bs = [...m.querySelectorAll('button')]; const i = bs.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); bs[(i + 1) % bs.length].focus(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); bs[(i - 1 + bs.length) % bs.length].focus(); }
    if (e.key === 'Escape') closeMenu();
  });
  openMenu = m;
}
document.addEventListener('mousedown', (e) => { if (openMenu && !openMenu.contains(e.target)) closeMenu(); });
const MENUS = {
  cleanup: () => [
    { label: 'Fix titles & artists…', run: fixesDialog }, { label: 'Find duplicates…', run: duplicatesDialog },
    { label: 'Rename genres…', run: genresDialog }, { label: 'Find & replace…', run: replaceDialog },
    { label: 'Rename files to “Artist - Title”…', run: renameFilesDialog },
    '-', { label: 'Check for missing files', run: checkMissing },
  ],
  export: () => [
    { label: 'Engine DJ…', run: engineDialog },
    { label: 'rekordbox library (native)…', run: rekordboxDbDialog }, { label: 'rekordbox XML…', run: rekordboxDialog },
    { label: 'M3U playlists…', run: exportM3u },
  ],
};
document.querySelectorAll('[data-menu]').forEach(b => b.addEventListener('click', () => { const r = b.getBoundingClientRect(); popMenu(MENUS[b.dataset.menu](), r.left, r.bottom + 4); }));

// ---------------------------------------------------------------- modals
function modal({ title, intro, body, actions = [], narrow = false, onClose }) {
  const back = el('div', { class: 'backdrop' });
  const footer = el('footer');
  const m = el('div', { class: `modal${narrow ? ' narrow' : ''}`, role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
    el('header', {}, el('h2', { text: title }), intro ? el('p', { text: intro }) : null), el('div', { class: 'body' }, body || ''), footer);
  const prevFocus = document.activeElement;
  const close = () => { back.remove(); document.removeEventListener('keydown', onKey, true); prevFocus?.focus?.(); onClose && onClose(); };
  const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  const setActions = (list) => {
    footer.textContent = '';
    for (const a of list) {
      if (a.note !== undefined) { footer.append(el('span', { class: 'grow', text: a.note })); continue; }
      const b = el('button', { class: `btn${a.primary ? ' primary' : ''}${a.danger ? ' danger' : ''}`, type: 'button', text: a.label, disabled: a.disabled });
      b.addEventListener('click', async () => { if (!a.run) return close(); b.disabled = true; try { const keep = await a.run(b); if (!keep) close(); } catch { /* toast shown */ } finally { b.disabled = false; } });
      footer.append(b);
    }
  };
  setActions(actions);
  back.append(m); document.body.append(back); document.addEventListener('keydown', onKey, true);
  setTimeout(() => (m.querySelector('input, select, textarea') || m.querySelector('footer .btn.primary') || m).focus(), 0);
  return { close, setActions, body: m.querySelector('.body'), el: m };
}
function confirmBox(title, text, okLabel = 'OK') {
  return new Promise(res => { const d = modal({ title, intro: text, narrow: true, onClose: () => res(false), actions: [{ label: 'Cancel' }, { label: okLabel, primary: true, run: () => { res(true); return false; } }] }); void d; });
}
function promptBox(title, label, value = '') {
  return new Promise(res => {
    const input = el('input', { type: 'text', value, 'aria-label': label });
    let result = null;
    const d = modal({ title, narrow: true, body: el('div', { class: 'field' }, el('label', { text: label }), input), onClose: () => res(result),
      actions: [{ label: 'Cancel' }, { label: 'Create', primary: true, run: () => { result = input.value.trim() || null; return false; } }] });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { result = input.value.trim() || null; d.close(); } });
    setTimeout(() => input.select(), 10);
  });
}
function scopePicker(name = 'scope') {
  const sel = state.selection.size;
  const wrap = el('div', { class: 'row-inline', role: 'radiogroup', 'aria-label': 'Which tracks' });
  const opts = [];
  if (sel) opts.push(['selection', `Selected tracks (${sel.toLocaleString()})`]);
  if (state.view.playlistId || state.view.search) opts.push(['view', `This view (${state.tracks.length.toLocaleString()})`]);
  opts.push(['all', `Whole library (${state.total.toLocaleString()})`]);
  opts.forEach(([v, label], i) => wrap.append(el('label', {}, el('input', { type: 'radio', name, value: v, checked: i === 0 }), label)));
  wrap.value = () => {
    const v = wrap.querySelector('input:checked').value;
    if (v === 'selection') return { ids: selectedIds() };
    if (v === 'view') return { ids: state.tracks.map(t => t.id) };
    return {};
  };
  return wrap;
}
function previewTable(edits, trackById) {
  const tbl = el('table', { class: 'preview' }); const checks = [];
  tbl.append(el('thead', {}, el('tr', {}, el('th', {}, el('input', { type: 'checkbox', checked: true, 'aria-label': 'Select all', onchange: (e) => checks.forEach(c => { c.checked = e.target.checked; }) })), el('th', { text: 'Track' }), el('th', { text: 'Field' }), el('th', { text: 'Before' }), el('th', { text: 'After' }))));
  const tb = el('tbody'); tbl.append(tb);
  for (const ed of edits.slice(0, 2000)) {
    const t = trackById.get(ed.id); const fields = Object.keys(ed.changes);
    const cb = el('input', { type: 'checkbox', checked: true, 'aria-label': `Apply to ${t ? t.title : ed.id}` }); cb.edit = ed; checks.push(cb);
    fields.forEach((f, i) => tb.append(el('tr', {}, i === 0 ? el('td', { rowspan: fields.length }, cb) : null, i === 0 ? el('td', { rowspan: fields.length, text: t ? `${t.artist ? t.artist + ' – ' : ''}${t.title}` : '' }) : null,
      el('td', { class: 'fld', text: f }), el('td', { class: 'before', text: ed.before[f] || '(empty)' }), el('td', { class: 'after', text: ed.changes[f] || '(empty)' }))));
  }
  return { el: el('div', { class: 'scrollbox' }, tbl), chosen: () => checks.filter(c => c.checked).map(c => c.edit), truncated: edits.length > 2000 };
}
async function applyEdits(edits, writeFiles) {
  if (!edits.length) return;
  const t = toast(`Saving ${plural(edits.length, 'track')}…`, 'info', { progress: true });
  const res = await api('cleanup.apply', edits, { writeFiles });
  t.done(res.fileErrors.length ? `Updated ${plural(res.updated, 'track')}. ${plural(res.fileErrors.length, 'file')} could not be written (${res.fileErrors[0].error}).` : `Updated ${plural(res.updated, 'track')}`, res.fileErrors.length ? 'error' : 'ok');
  await loadTracks({ keepScroll: true }); renderInspector(); refreshGenres();
}
async function trackMap() { const all = await api('tracks.list', {}); return new Map(all.map(t => [t.id, t])); }

// ----- Fix titles & artists
async function fixesDialog() {
  const list = await api('cleanup.fixList');
  const defaults = new Set(store.get('fixes', ['whitespace', 'underscores', 'urls', 'promo', 'numberPrefix', 'extractRemixer', 'splitArtistTitle']));
  const checks = el('div', { class: 'checks' }); const boxes = [];
  for (const f of list) { const cb = el('input', { type: 'checkbox', value: f.id, checked: defaults.has(f.id) }); boxes.push(cb); checks.append(el('label', {}, cb, f.label)); }
  const scope = scopePicker(); const write = el('input', { type: 'checkbox', checked: true });
  const result = el('div');
  const body = el('div', {}, checks, scope, el('div', { class: 'row-inline' }, el('label', {}, write, 'Also save changes into the music files')), result);
  let edits = null, pv = null;
  const d = modal({ title: 'Fix titles & artists', intro: 'Choose the fixes to run. You’ll see every change before anything is saved.', body,
    actions: [{ label: 'Cancel' }, { label: 'Preview changes', primary: true, run: preview }] });
  async function preview() {
    const fixes = boxes.filter(b => b.checked).map(b => b.value); store.set('fixes', fixes);
    if (!fixes.length) { toast('Choose at least one fix.', 'info'); return true; }
    edits = await api('cleanup.previewFixes', scope.value(), fixes);
    result.textContent = '';
    if (!edits.length) { result.append(el('div', { class: 'notice good', text: 'Nothing to fix. These tracks already look clean.' })); d.setActions([{ label: 'Done', primary: true }]); return true; }
    pv = previewTable(edits, await trackMap()); result.append(pv.el);
    d.setActions([{ note: `${plural(edits.length, 'track')} will change${pv.truncated ? ' (showing the first 2,000)' : ''}` }, { label: 'Cancel' }, { label: 'Preview again', run: preview }, { label: 'Apply selected changes', primary: true, run: async () => { await applyEdits(pv.chosen(), write.checked); } }]);
    return true;
  }
}

// ----- Write tags to file: saves Crate's tags into the music files.
async function writeTagsToFiles(ids) {
  const t = toast(`Writing tags to ${plural(ids.length, 'file')}…`, 'info', { progress: true });
  const off = window.crate.on('write-progress', (p) => t.set(`Writing tags: ${p.done.toLocaleString()} of ${p.total.toLocaleString()}…`, p.total ? p.done / p.total : 0));
  try {
    const r = await api('tracks.writeTags', ids);
    const bits = [`Wrote tags to ${plural(r.written, 'file')}`];
    if (r.skipped) bits.push(`${plural(r.skipped, 'missing file')} skipped`);
    if (r.errors.length) bits.push(`${plural(r.errors.length, 'file')} couldn’t be written: ${r.errors[0].error}`);
    t.done(bits.join('. ') + '.', r.errors.length ? 'error' : 'ok');
    await loadTracks({ keepScroll: true });
  } catch { t.close(); } finally { off(); }
}

// ----- Rename files to "Artist - Title"
async function renameFilesDialog() {
  const scope = scopePicker('rscope'); const result = el('div');
  const d = modal({ title: 'Rename files', intro: 'Renames music files to “Artist - Title”, using each track’s artist and title. Files stay in the same folder and keep their extension. You’ll see every new name first.',
    body: el('div', {}, scope, result), actions: [{ label: 'Cancel' }, { label: 'Preview new names', primary: true, run: preview }] });
  async function preview() {
    const ids = scope.value().ids;
    const plan = await api('files.previewRename', ids);
    const todo = plan.filter(p => p.status === 'rename');
    const count = (s) => plan.filter(p => p.status === s).length;
    result.textContent = '';
    const notes = [];
    if (count('same')) notes.push(`${plural(count('same'), 'file')} already named like this`);
    if (count('noTags')) notes.push(`${plural(count('noTags'), 'track')} skipped because the artist or title is empty`);
    if (count('missing')) notes.push(`${plural(count('missing'), 'missing file')} skipped`);
    if (notes.length) result.append(el('div', { class: 'notice', text: notes.join('; ') + '.' }));
    if (!todo.length) { result.append(el('div', { class: 'notice good', text: 'Nothing to rename.' })); d.setActions([{ label: 'Done', primary: true }]); return true; }
    const name = (p) => p.split(/[\\/]/).pop();
    const rows = el('tbody');
    for (const p of todo.slice(0, 2000)) rows.append(el('tr', {}, el('td', { class: 'before', text: name(p.from) }), el('td', { class: 'after', text: name(p.to) })));
    result.append(el('div', { class: 'scrollbox' }, el('table', { class: 'preview' }, el('thead', {}, el('tr', {}, el('th', { text: 'Current name' }), el('th', { text: 'New name' }))), rows)),
      el('p', { class: 'time', text: 'If another file already has the new name, “(2)” is added. rekordbox will see renamed files as missing until you relocate them there; Crate’s next Engine DJ export moves Engine’s tracks to the new names, keeping their cues and analysis.' }));
    d.setActions([{ note: `${plural(todo.length, 'file')} will be renamed${todo.length > 2000 ? ' (showing the first 2,000)' : ''}` }, { label: 'Cancel' },
      { label: `Rename ${plural(todo.length, 'file')}`, primary: true, run: async () => {
        const r = await api('files.rename', ids);
        const msg = `Renamed ${plural(r.renamed, 'file')}${r.errors.length ? `. ${plural(r.errors.length, 'file')} couldn’t be renamed: ${r.errors[0].error}` : ''}`;
        toast(msg, r.errors.length ? 'error' : 'ok', { timeout: 12000, action: r.renamed ? { label: 'Undo', run: async () => {
          const u = await api('files.undoRename');
          toast(u.errors.length ? `Restored ${plural(u.restored, 'file')}; ${u.errors.length} couldn’t be: ${u.errors[0].error}` : `Restored ${plural(u.restored, 'file name')}`, u.errors.length ? 'error' : 'ok');
          await loadTracks({ keepScroll: true }); renderInspector();
        } } : null });
        await loadTracks({ keepScroll: true }); renderInspector();
      } }]);
    return true;
  }
}

// ----- Find & replace
async function replaceDialog() {
  const fieldSel = el('select', { 'aria-label': 'Field' }, ...['title', 'artist', 'album', 'genre', 'label', 'remixer', 'comment', 'grouping', 'composer', 'mix'].map(f => el('option', { value: f, text: f[0].toUpperCase() + f.slice(1) })));
  const find = el('input', { type: 'text', placeholder: 'Find', 'aria-label': 'Find' }); const rep = el('input', { type: 'text', placeholder: 'Replace with', 'aria-label': 'Replace with' });
  const cs = el('input', { type: 'checkbox' }); const whole = el('input', { type: 'checkbox' }); const write = el('input', { type: 'checkbox', checked: true });
  const scope = scopePicker(); const result = el('div');
  const body = el('div', {}, el('div', { class: 'rule', style: 'grid-template-columns:140px 1fr 1fr' }, fieldSel, find, rep),
    el('div', { class: 'row-inline' }, el('label', {}, cs, 'Match case'), el('label', {}, whole, 'Whole value only'), el('label', {}, write, 'Also save into the music files')), scope, result);
  let pv = null;
  const d = modal({ title: 'Find & replace', body, actions: [{ label: 'Cancel' }, { label: 'Preview changes', primary: true, run: preview }] });
  async function preview() {
    if (!find.value) { toast('Type something to find.', 'info'); return true; }
    const edits = await api('cleanup.previewReplace', scope.value(), { field: fieldSel.value, find: find.value, replace: rep.value, caseSensitive: cs.checked, wholeValue: whole.checked });
    result.textContent = '';
    if (!edits.length) { result.append(el('div', { class: 'notice', text: `No ${fieldSel.value} values contain “${find.value}”.` })); return true; }
    pv = previewTable(edits, await trackMap()); result.append(pv.el);
    d.setActions([{ note: `${plural(edits.length, 'track')} will change` }, { label: 'Cancel' }, { label: 'Preview again', run: preview }, { label: 'Apply selected changes', primary: true, run: async () => { await applyEdits(pv.chosen(), write.checked); } }]);
    return true;
  }
}

// ----- Duplicates
async function duplicatesDialog() {
  const scope = scopePicker(); const result = el('div'); const trash = el('input', { type: 'checkbox' });
  const d = modal({ title: 'Find duplicates', intro: 'Tracks count as duplicates when artist, title and remix match and their lengths are within 3 seconds. The best-quality copy is picked to keep; you can change it.',
    body: el('div', {}, scope, result), actions: [{ label: 'Cancel' }, { label: 'Find duplicates', primary: true, run: scan }] });
  async function scan() {
    const groups = await api('cleanup.duplicates', scope.value());
    result.textContent = '';
    if (!groups.length) { result.append(el('div', { class: 'notice good', text: 'No duplicates found.' })); d.setActions([{ label: 'Done', primary: true }]); return true; }
    const box = el('div', { class: 'scrollbox', style: 'padding:8px' }); const keepers = new Map();
    groups.forEach((g, gi) => {
      keepers.set(gi, g.keep);
      const grp = el('div', { class: 'dupe-group' });
      for (const t of g.tracks) {
        const radio = el('input', { type: 'radio', name: `keep-${gi}`, checked: t.id === g.keep, 'aria-label': `Keep ${t.path}`, onchange: () => { keepers.set(gi, t.id); paint(); } });
        const badge = el('span', { class: `badge${t.id === g.keep ? ' keep' : ''}`, text: t.id === g.keep ? 'Keep' : 'Remove' }); badge.dataset.id = t.id; badge.dataset.g = gi;
        grp.append(el('div', { class: 'dupe' }, radio, el('div', {}, el('div', { text: `${t.artist} – ${t.title}` }), el('div', { class: 'path', title: t.path, text: shortPath(t.path) })),
          el('span', { class: 'badge', text: `${(({ mp4: 'm4a' })[t.format] || t.format)} ${t.bitrate}k` }), el('span', { class: 'time', text: fmtTime(t.duration) }), badge));
      }
      box.append(grp);
    });
    const paint = () => box.querySelectorAll('.badge[data-id]').forEach(b => { const keep = keepers.get(+b.dataset.g) === +b.dataset.id; b.textContent = keep ? 'Keep' : 'Remove'; b.classList.toggle('keep', keep); });
    result.append(box, el('div', { class: 'row-inline' }, el('label', {}, trash, 'Also move the removed copies’ files to the Trash')));
    const extras = () => groups.flatMap((g, gi) => g.tracks.filter(t => t.id !== keepers.get(gi)).map(t => t.id));
    d.setActions([{ note: `${plural(groups.length, 'group')}, ${plural(extras().length, 'extra copy')}`.replace('copys', 'copies') }, { label: 'Cancel' },
      { label: 'Remove extra copies', primary: true, run: async () => {
        const ids = extras();
        if (!(await confirmBox(`Remove ${plural(ids.length, 'track')}?`, trash.checked ? 'They are removed from Crate and their files go to the Trash. Playlists that used them switch to nothing, so add the kept copy where needed.' : 'They are removed from Crate only; the files stay on disk.', 'Remove'))) return true;
        const r = await api('cleanup.removeDuplicates', ids, { trashFiles: trash.checked });
        toast(r.errors.length ? `Removed ${r.removed}; ${r.errors.length} files couldn't be moved to the Trash` : `Removed ${plural(r.removed, 'duplicate')}`, r.errors.length ? 'error' : 'ok');
        state.selection.clear(); await refreshPlaylists(); await loadTracks({ keepScroll: true }); renderInspector();
      } }]);
    return true;
  }
}

// ----- Genres
async function genresDialog() {
  await refreshGenres();
  const rows = el('tbody'); const inputs = [];
  for (const g of state.genres) {
    const input = el('input', { type: 'text', placeholder: g.value, 'aria-label': `New name for ${g.value}` }); input.orig = g.value; inputs.push(input);
    rows.append(el('tr', {}, el('td', { text: g.value }), el('td', { class: 'fld', text: g.count.toLocaleString() }), el('td', {}, input)));
  }
  const filter = el('input', { type: 'text', placeholder: 'Filter genres', 'aria-label': 'Filter genres', oninput: (e) => { const q = e.target.value.toLowerCase(); [...rows.children].forEach(r => { r.hidden = !r.firstChild.textContent.toLowerCase().includes(q); }); } });
  const tbl = el('table', { class: 'preview' }, el('thead', {}, el('tr', {}, el('th', { text: 'Genre' }), el('th', { text: 'Tracks' }), el('th', { text: 'Rename to' }))), rows);
  const write = el('input', { type: 'checkbox', checked: true });
  modal({ title: 'Rename genres', intro: 'Type a new name next to any genre. Give several genres the same name to merge them.',
    body: state.genres.length ? el('div', {}, filter, el('div', { class: 'scrollbox', style: 'margin-top:8px' }, tbl), el('div', { class: 'row-inline' }, el('label', {}, write, 'Also save into the music files'))) : el('div', { class: 'notice', text: 'No genres in your library yet.' }),
    actions: [{ label: 'Cancel' }, { label: 'Rename', primary: true, run: async () => {
      const mapping = {}; for (const i of inputs) if (i.value.trim() && i.value.trim() !== i.orig) mapping[i.orig] = i.value.trim();
      if (!Object.keys(mapping).length) { toast('Type a new name next to at least one genre.', 'info'); return true; }
      const edits = await api('cleanup.previewGenres', mapping);
      if (!(await confirmBox(`Rename genres on ${plural(edits.length, 'track')}?`, Object.entries(mapping).map(([a, b]) => `${a} → ${b}`).join('\n'), 'Rename'))) return true;
      await applyEdits(edits, write.checked);
    } }] });
}

async function checkMissing() {
  const r = await api('tracks.checkMissing');
  toast(r.missing ? `${plural(r.missing, 'file')} missing. See “Missing files” in the sidebar.` : `All ${r.checked.toLocaleString()} files found.`, r.missing ? 'error' : 'ok');
  await loadTracks({ keepScroll: true });
}

// ----- Smartlist editor
let SMART = null;
const OP_LABELS = { contains: 'contains', not_contains: 'doesn’t contain', is: 'is', is_not: 'is not', starts_with: 'starts with', ends_with: 'ends with', is_empty: 'is empty', not_empty: 'isn’t empty',
  eq: '=', ne: '≠', gt: '>', gte: '≥', lt: '<', lte: '≤', between: 'between', compatible_with: 'mixes with', in_last_days: 'in the last (days)', not_in_last_days: 'not in the last (days)', before: 'before', after: 'on or after', in: 'is in playlist', not_in: 'isn’t in playlist' };
const FIELD_LABELS = { title: 'Title', artist: 'Artist', album: 'Album', genre: 'Genre', comment: 'Comment', label: 'Label', remixer: 'Remixer', composer: 'Composer', grouping: 'Grouping', mix: 'Mix', path: 'File path', format: 'File type',
  bpm: 'BPM', year: 'Year', rating: 'Rating', duration: 'Length (seconds)', bitrate: 'Bitrate', trackNumber: 'Track #', sampleRate: 'Sample rate', key: 'Key', dateAdded: 'Date added', playlist: 'Playlist' };
async function smartEditor(p, parentId = null) {
  if (!SMART) SMART = await api('playlists.smartMeta');
  const rules = p ? structuredClone(p.rules || { conditions: [] }) : { match: 'all', conditions: [{ field: 'genre', op: 'contains', value: '' }] };
  const name = el('input', { type: 'text', value: p ? p.name : 'New smartlist', 'aria-label': 'Smartlist name' });
  const match = el('select', { 'aria-label': 'Match' }, el('option', { value: 'all', text: 'all', selected: rules.match !== 'any' }), el('option', { value: 'any', text: 'any', selected: rules.match === 'any' }));
  const list = el('div'); const count = el('span');
  const limit = el('input', { type: 'number', min: 0, value: rules.limit || '', placeholder: 'No limit', style: 'width:110px', 'aria-label': 'Limit' });
  const sortSel = el('select', { 'aria-label': 'Sort' }, el('option', { value: '', text: 'Library order' }), el('option', { value: 'random', text: 'Random' }),
    ...['dateAdded', 'bpm', 'rating', 'year', 'title', 'artist'].flatMap(f => [el('option', { value: `${f}:desc`, text: `${FIELD_LABELS[f]}, high to low` }), el('option', { value: `${f}:asc`, text: `${FIELD_LABELS[f]}, low to high` })]));
  sortSel.value = rules.sort ? (rules.sort.field === 'random' ? 'random' : `${rules.sort.field}:${rules.sort.dir}`) : '';
  const collect = () => {
    const r = { match: match.value, conditions: [...list.children].map(row => row.read()) };
    if (+limit.value > 0) r.limit = +limit.value;
    if (sortSel.value) { const [field, dir] = sortSel.value.split(':'); r.sort = { field, dir: dir || 'asc' }; }
    return r;
  };
  const refresh = debounce(async () => { try { const n = await window.crate.call('playlists.previewSmart', collect()); count.textContent = `${plural(n, 'track')} match`; } catch { count.textContent = 'Finish the rules to see matches'; } }, 250);
  const addRow = (c) => {
    const field = el('select', { 'aria-label': 'Field' }, ...Object.keys(SMART.fields).map(f => el('option', { value: f, text: FIELD_LABELS[f] || f })));
    const op = el('select', { 'aria-label': 'Condition' }); const vbox = el('div', { class: 'two' });
    const row = el('div', { class: 'rule' }, field, op, vbox, el('button', { class: 'btn icon', type: 'button', title: 'Remove rule', 'aria-label': 'Remove rule', text: '−', onclick: () => { row.remove(); refresh(); } }));
    let v1, v2;
    const fillOps = (keepOp) => { const type = SMART.fields[field.value]; op.textContent = ''; for (const o of SMART.ops[type]) op.append(el('option', { value: o, text: OP_LABELS[o] || o })); if (keepOp && SMART.ops[type].includes(keepOp)) op.value = keepOp; };
    const fillValue = (val, val2) => {
      vbox.textContent = ''; const type = SMART.fields[field.value];
      if (['is_empty', 'not_empty'].includes(op.value)) { v1 = v2 = null; return; }
      if (type === 'playlist') { v1 = el('select', { 'aria-label': 'Playlist' }, ...state.playlists.filter(x => x.type === 'playlist').map(x => el('option', { value: x.id, text: x.name }))); if (val) v1.value = val; }
      else if (type === 'date' && ['before', 'after'].includes(op.value)) v1 = el('input', { type: 'date', value: val || '', 'aria-label': 'Date' });
      else v1 = el('input', { type: type === 'number' || type === 'date' ? 'number' : 'text', value: val ?? '', 'aria-label': 'Value', list: field.value === 'genre' ? 'genre-list' : null, placeholder: type === 'key' ? 'e.g. 8A or Am' : '' });
      vbox.append(v1);
      if (op.value === 'between') { v2 = el('input', { type: 'number', value: val2 ?? '', 'aria-label': 'and' }); vbox.append(el('span', { class: 'time', text: 'and' }), v2); } else v2 = null;
      vbox.querySelectorAll('input,select').forEach(i => i.addEventListener('input', refresh));
    };
    field.value = c.field; fillOps(c.op); fillValue(c.value, c.value2);
    field.addEventListener('change', () => { fillOps(); fillValue(); refresh(); });
    op.addEventListener('change', () => { fillValue(v1?.value, v2?.value); refresh(); });
    row.read = () => { const o = { field: field.value, op: op.value }; if (v1) o.value = v1.value; if (v2) o.value2 = v2.value; return o; };
    list.append(row);
  };
  (rules.conditions.length ? rules.conditions : [{ field: 'genre', op: 'contains', value: '' }]).forEach(addRow);
  [match, limit, sortSel].forEach(x => x.addEventListener('input', refresh));
  const body = el('div', {},
    el('div', { class: 'field' }, el('label', { text: 'Name' }), name),
    el('div', { class: 'row-inline' }, 'Match', match, 'of these rules'), list,
    el('button', { class: 'btn', type: 'button', text: 'Add rule', onclick: () => { addRow({ field: 'bpm', op: 'between', value: 120, value2: 128 }); refresh(); } }),
    el('div', { class: 'row-inline', style: 'margin-top:14px' }, el('label', {}, 'Limit to', limit, 'tracks'), el('label', {}, 'Sorted by', sortSel)));
  modal({ title: p ? 'Edit smartlist' : 'New smartlist', intro: 'A smartlist updates itself as your library changes.', body,
    actions: [{ note: '' }, { label: 'Cancel' }, { label: p ? 'Save smartlist' : 'Create smartlist', primary: true, run: async () => {
      const r = collect();
      if (p) await api('playlists.update', p.id, { name: name.value.trim() || p.name, rules: r });
      else { const id = await api('playlists.create', { name: name.value.trim() || 'New smartlist', type: 'smart', parentId, rules: r }); if (parentId) { state.expanded.add(parentId); saveExpanded(); } state.view.playlistId = id; }
      await refreshPlaylists(); await selectView({ playlistId: p ? p.id : state.view.playlistId });
    } }] }).el.querySelector('footer .grow').append(count);
  refresh();
}

// ----- Exports
async function rekordboxDialog() {
  const notation = el('select', { 'aria-label': 'Key notation' }, el('option', { value: 'musical', text: 'Musical (Am, F#)' }), el('option', { value: 'camelot', text: 'Camelot (8A)' }), el('option', { value: 'openkey', text: 'Open Key (1m)' }));
  const result = el('div'); const rbCues = el('input', { type: 'checkbox', checked: store.get('exportCues', true) });
  modal({ title: 'Export rekordbox XML', narrow: true,
    intro: 'Writes your whole library, cue points and every playlist to one XML file that rekordbox can import. Smartlists are exported as normal playlists.',
    body: el('div', {}, el('div', { class: 'row-inline' }, el('label', {}, 'Write keys as', notation)),
      el('div', { class: 'checks', style: 'margin-top:8px' }, el('label', {}, rbCues, 'Include cue points (hot cues, memory cues and loops)')), result),
    actions: [{ label: 'Close' }, { label: 'Choose file and export', primary: true, run: async () => {
      store.set('exportCues', rbCues.checked);
      const r = await api('export.rekordbox', { keyNotation: notation.value, cues: rbCues.checked }); if (!r) return true;
      result.textContent = '';
      result.append(el('div', { class: 'notice good', text: `Exported ${plural(r.tracks, 'track')}${r.cueTracks ? ` (${r.cueTracks.toLocaleString()} with cue points)` : ''} to ${r.file}` }),
        el('div', { class: 'notice', text: 'In rekordbox: Preferences › View › Layout, turn on “rekordbox xml”. Then Preferences › Advanced › Database › rekordbox xml, choose this file. Your Crate playlists appear under “rekordbox xml” in the sidebar; drag them into your collection. Engine DJ can read the same file from its rekordbox panel.' }),
        r.cueTracks ? el('div', { class: 'notice', text: 'Cue points: rekordbox takes them when a track is added to your collection from the XML. For tracks already in your collection, right-click them under “rekordbox xml” and choose Import To Collection; rekordbox then asks before replacing their existing cues.' }) : '');
      return true;
    } }] });
}
// rekordbox native: writes into rekordbox's own master.db + masterPlaylists6.xml.
async function rekordboxDbDialog() {
  let dir = null; const status = el('div');
  const cuesBox = el('input', { type: 'checkbox', checked: store.get('exportCues', true) });
  const showStatus = async () => {
    const s = await api('export.rekordboxDbInspect', dir); dir = s.dir;
    status.textContent = '';
    if (!s.ok) { status.append(el('div', { class: 'notice bad', text: s.reason })); return false; }
    status.append(el('div', { class: 'notice good', text: `Found your rekordbox library at ${s.dir}.` }));
    if (s.running) status.append(el('div', { class: 'notice bad', text: 'rekordbox is open. Quit rekordbox before exporting; it would overwrite or damage the changes.' }));
    return !s.running;
  };
  const d = modal({ title: 'Export to rekordbox library',
    intro: 'Writes straight into rekordbox’s own library, so your tracks, playlists and cue points appear in rekordbox’s Collection and Playlists without importing an XML file. Tracks new to rekordbox are added (it analyses them when you load them), tracks it already has get Crate’s tags, and rekordbox’s playlists are made to match Crate’s exactly: every playlist, folder and smart playlist there is replaced with yours, at the top level.',
    body: el('div', {}, status,
      el('div', { class: 'row-inline' }, el('button', { class: 'btn', type: 'button', text: 'Choose a different rekordbox folder…', onclick: async () => { const p = await api('export.rekordboxDbChooseDir'); if (p) { dir = p; d.setActions(actions(await showStatus())); } } }),
        el('button', { class: 'btn', type: 'button', text: 'Check again', onclick: async () => d.setActions(actions(await showStatus())) })),
      el('div', { class: 'checks', style: 'margin-top:10px' }, el('label', {}, cuesBox, 'Write cue points (replaces rekordbox’s cues on tracks that have cue points in Crate; other tracks keep theirs)')),
      el('div', { class: 'notice bad', text: 'Playlists you made only in rekordbox will be removed (its built-in lists stay). Quit rekordbox before exporting. Crate copies master.db and masterPlaylists6.xml into a “Crate backups” folder next to them every time, so you can roll back.' })),
    actions: [{ label: 'Cancel' }] });
  const actions = (ok) => [{ label: 'Cancel' }, { label: 'Export to rekordbox', primary: true, disabled: !ok, run: async () => {
    store.set('exportCues', cuesBox.checked);
    const t = toast('Exporting to rekordbox…', 'info', { progress: true });
    try {
      const r = await api('export.rekordboxDb', { dir, cues: cuesBox.checked, keyNotation: 'musical' });
      const notes = [];
      if (r.smartAsPlaylists.length) notes.push(`${plural(r.smartAsPlaylists.length, 'smartlist')} went as normal playlists because rekordbox can’t express their rules: ${r.smartAsPlaylists.slice(0, 3).map(x => `“${x.name}” (${x.reason})`).join('; ')}.`);
      if (r.cueSkipped.length) notes.push(`Cue points weren’t written for ${plural(r.cueSkipped.length, 'track')} (${[...new Set(r.cueSkipped.map(x => x.reason))].join(' and ')} files, which need seek data only rekordbox can create).`);
      const moved = r.moved ? `, ${r.moved} renamed` : '';
      t.done(`rekordbox updated: ${r.added} added, ${r.updated} updated${moved}${r.skipped ? `, ${r.skipped} missing files skipped` : ''}; playlists replaced with ${plural(r.playlists, 'playlist')}${r.smartlists ? ` and ${plural(r.smartlists, 'smart playlist')}` : ''}${r.cueTracks ? `; cue points for ${plural(r.cueTracks, 'track')}` : ''}.${notes.length ? ' ' + notes.join(' ') : ''}`, notes.length ? 'info' : 'ok');
    } catch { t.close(); return true; }
  } }];
  d.setActions(actions(await showStatus()));
}
async function engineDialog() {
  let dir = null; const status = el('div');
  const engCues = el('input', { type: 'checkbox', checked: store.get('exportCues', true) });
  const showStatus = async () => {
    const s = await api('export.engineInspect', dir); dir = s.file.replace(/[\\/]Database2[\\/]m\.db$/, '');
    status.textContent = '';
    status.append(s.ok ? el('div', { class: 'notice good', text: `Found Engine Library ${s.version} with ${plural(s.tracks, 'track')} at ${dir}` }) : el('div', { class: 'notice bad', text: s.reason }));
    return s.ok;
  };
  const d = modal({ title: 'Export to Engine DJ', intro: 'Adds your tracks to Engine DJ’s library and makes Engine’s playlists match Crate’s exactly: every playlist, folder and smartlist in Engine is replaced with yours, at the top level. Smartlists stay smart where Engine supports their rules; others become normal playlists of their current tracks. Engine analyses beatgrids and waveforms itself the first time you load each track.',
    body: el('div', {}, status,
      el('div', { class: 'row-inline' }, el('button', { class: 'btn', type: 'button', text: 'Choose a different Engine Library…', onclick: async () => { const p = await api('export.engineChooseDir'); if (p) { dir = p; const ok = await showStatus(); d.setActions(actions(ok)); } } })),
      el('div', { class: 'checks', style: 'margin-top:10px' }, el('label', {}, engCues, 'Write cue points (replaces Engine’s cues on tracks that have cue points in Crate; other tracks keep theirs)')),
      el('div', { class: 'notice bad', text: 'Playlists you made only in Engine DJ will be removed. Quit Engine DJ before exporting. A backup of Engine’s database is saved next to it every time, so you can roll back.' })),
    actions: [{ label: 'Cancel' }] });
  const actions = (ok) => [{ label: 'Cancel' }, { label: 'Export to Engine DJ', primary: true, disabled: !ok, run: async () => {
    const t = toast('Exporting to Engine DJ…', 'info', { progress: true });
    try {
      store.set('exportCues', engCues.checked);
      const r = await api('export.engine', { libraryDir: dir, cues: engCues.checked });
      const cueNote = r.cueTracks ? ` Cue points written for ${plural(r.cueTracks, 'track')}${r.cuesDropped ? ` (${plural(r.cuesDropped, 'extra memory cue')} left out: Engine has one main cue per track and 8 loop pads)` : ''}.` : '';
      const asStatic = r.smartAsPlaylists.length ? ` ${plural(r.smartAsPlaylists.length, 'smartlist')} went as normal playlists because Engine can’t express their rules: ${r.smartAsPlaylists.slice(0, 3).map(x => `“${x.name}” (${x.reason})`).join('; ')}.` : '';
      t.done(`Engine DJ updated: ${r.added} added, ${r.updated} updated${r.skipped ? `, ${r.skipped} missing files skipped` : ''}, playlists replaced with ${plural(r.playlists, 'playlist')}${r.smartlists ? ` and ${plural(r.smartlists, 'smartlist')}` : ''}.${cueNote}${asStatic}`, asStatic ? 'info' : 'ok');
    } catch { t.close(); return true; }
  } }];
  d.setActions(actions(await showStatus()));
}
async function exportM3u() {
  const r = await api('export.m3u'); if (r) toast(`Wrote ${plural(r.files, 'playlist')} to ${r.dir}`, 'ok', { timeout: 7000 });
}

// ---------------------------------------------------------------- import from rekordbox / Engine DJ
function commonDir(paths) {
  if (!paths.length) return '';
  const split = paths.map(p => String(p).replace(/\\/g, '/').split('/').slice(0, -1));
  const first = split[0]; let n = first.length;
  for (const s of split) { let i = 0; while (i < n && s[i] === first[i]) i++; n = i; }
  return first.slice(0, n).join('/');
}
async function externalImportDialog(kind) {
  const NAME = kind === 'rekordbox' ? 'rekordbox' : 'Engine DJ';
  let dir = null, info = null;
  const status = el('div');
  const from = el('input', { type: 'text', placeholder: 'e.g. C:/Users/me/Music', 'aria-label': 'Path starts with' });
  const to = el('input', { type: 'text', placeholder: 'e.g. /Users/me/Music', 'aria-label': 'Replace with' });
  const pathBox = el('div', { hidden: true }, el('div', { class: 'field', style: 'margin-top:8px' }, el('label', { text: 'Files not found? Fix their location: replace the start of each path' }),
    el('div', { class: 'rule', style: 'grid-template-columns:1fr auto 1fr' }, from, el('span', { class: 'time', text: 'with' }), to)));
  const fill = el('input', { type: 'radio', name: 'mode', value: 'fill', checked: true });
  const over = el('input', { type: 'radio', name: 'mode', value: 'overwrite' });
  const write = el('input', { type: 'checkbox' });
  const bundled = el('input', { type: 'checkbox' });
  const show = async () => {
    status.textContent = ''; status.append(el('div', { class: 'notice', text: `Reading your ${NAME} library…` }));
    info = await api(kind === 'rekordbox' ? 'import.rekordboxInspect' : 'import.engineInspect', dir);
    dir = info.dir; status.textContent = '';
    if (!info.ok) { status.append(el('div', { class: 'notice bad', text: info.reason })); return false; }
    const lines = [`Found ${plural(info.tracks, 'track')} and ${plural(info.playlists, 'playlist')} in ${info.dir}.`];
    if (kind === 'rekordbox') lines.push(info.xmlFile ? 'Using masterPlaylists6.xml to decide which playlists exist.' : 'masterPlaylists6.xml not found, so every playlist in master.db is imported.');
    if (info.smartlists) lines.push(`${plural(info.smartlists, 'smart playlist')} will come across as live smartlists.`);
    if (info.cueTracks) lines.push(`${plural(info.cueTracks, 'track')} ${info.cueTracks === 1 ? 'has' : 'have'} cue points (${info.cues.toLocaleString()} in all).`);
    if (info.foldersSkipped) lines.push('The “Crate” folder an older version of Crate exported is skipped, so playlists aren’t duplicated.');
    status.append(el('div', { class: 'notice good', text: lines.join(' ') }));
    if (info.smartSkipped) status.append(el('div', { class: 'notice', text: `${plural(info.smartSkipped, 'smart playlist')} can’t be converted and will be skipped: ${info.smartSkippedList.slice(0, 4).map(x => `“${x.name}” (${x.reason})`).join('; ')}${info.smartSkipped > 4 ? '…' : ''}` }));
    if (info.unsavedChanges) status.append(el('div', { class: 'notice bad', text: 'rekordbox seems to be open, so its latest changes may not be saved yet. Quit rekordbox first for a complete import.' }));
    const missing = info.tracks - info.filesFound;
    pathBox.hidden = !missing;
    if (missing) {
      status.append(el('div', { class: 'notice', text: `${plural(missing, 'file')} can’t be found at the paths ${NAME} has, e.g. ${info.samplePaths[0]}. They’ll be imported as missing (you can relink them later), or fix the paths below.` }));
      if (!from.value) from.value = commonDir(info.samplePaths);
    }
    return true;
  };
  const body = el('div', {}, status,
    el('div', { class: 'row-inline' }, el('button', { class: 'btn', type: 'button', text: `Choose a different ${NAME} folder…`, onclick: async () => {
      const p = await api('import.chooseFolder', kind === 'rekordbox' ? 'Choose the folder that contains master.db' : 'Choose your "Engine Library" folder', dir); if (p) { dir = p; d.setActions(actions(await show())); }
    } })),
    pathBox,
    el('div', { class: 'checks', style: 'margin-top:12px' },
      el('label', {}, fill, `For tracks already in Crate, keep Crate’s tags and cue points, and only fill what’s empty`),
      el('label', {}, over, `For tracks already in Crate, use ${NAME}’s tags and cue points`),
      el('label', {}, write, 'Also save the imported tags into the music files'),
      kind === 'rekordbox' ? el('label', {}, bundled, 'Include rekordbox’s own sampler sounds and demo tracks') : null),
    el('p', { class: 'time', text: `Playlists and smart playlists go straight into your playlists. Importing from ${NAME} again replaces the ones the last import made; playlists you made in Crate stay. Cue points come across; beatgrids aren’t imported.` }));
  const actions = (ok) => [{ label: 'Cancel' }, { label: `Import from ${NAME}`, primary: true, disabled: !ok, run: async () => {
    const pathMap = from.value.trim() && to.value.trim() ? [{ from: from.value.trim(), to: to.value.trim() }] : [];
    const t = toast(`Importing from ${NAME}…`, 'info', { progress: true });
    const off = window.crate.on('import-progress', (p) => t.set(`Importing ${p.done.toLocaleString()} of ${p.total.toLocaleString()} tracks from ${NAME}…`, p.total ? p.done / p.total : 0));
    try {
      const r = await api(kind === 'rekordbox' ? 'import.rekordbox' : 'import.engine', { dir, mode: over.checked ? 'overwrite' : 'fill', writeFiles: write.checked, pathMap, includeBundled: bundled.checked });
      const bits = [`${plural(r.added, 'new track')}`];
      if (r.updated) bits.push(`${r.updated} updated`); if (r.unchanged) bits.push(`${r.unchanged} already up to date`);
      if (r.missing) bits.push(`${r.missing} with missing files`);
      if (r.cueTracks) bits.push(`cue points for ${plural(r.cueTracks, 'track')}`);
      t.done(`${NAME}: ${bits.join(', ')}; ${plural(r.playlists, 'playlist')}${r.smartlists ? ` and ${plural(r.smartlists, 'smartlist')}` : ''} added to your playlists.${r.failed.length ? ` ${r.failed.length} couldn’t be read.` : ''}`, r.failed.length ? 'error' : 'ok');
      await refreshPlaylists();
      await loadTracks({ keepScroll: true });
      refreshGenres();
    } catch { t.close(); return true; } finally { off(); }
  } }];
  const d = modal({ title: `Import from ${NAME}`, intro: kind === 'rekordbox'
    ? 'Reads your rekordbox 6/7 library (master.db) and playlists (masterPlaylists6.xml). rekordbox itself is not changed.'
    : 'Reads your Engine DJ library (m.db) and playlists. Engine DJ itself is not changed.', body, actions: [{ label: 'Cancel' }] });
  d.setActions(actions(await show()));
}

// ---------------------------------------------------------------- import
async function doImport(paths) {
  const t = toast('Looking for music…', 'info', { progress: true });
  const off = window.crate.on('import-progress', (p) => t.set(`Importing ${p.done.toLocaleString()} of ${p.total.toLocaleString()} files…`, p.total ? p.done / p.total : 0));
  try {
    const r = Array.isArray(paths) ? await api('import.paths', paths) : await api('import.choose');
    if (!r) { t.close(); return; }
    const bits = [`${plural(r.added, 'new track')}`]; if (r.updated) bits.push(`${r.updated} updated`); if (r.unchanged) bits.push(`${r.unchanged} already in your library`);
    t.done(r.failed.length ? `${bits.join(', ')}. ${plural(r.failed.length, 'file')} couldn't be read (${r.failed[0].error}).` : bits.join(', ') + '.', r.failed.length ? 'error' : 'ok');
  } catch { t.close(); } finally { off(); }
  await refreshPlaylists(); await loadTracks({ keepScroll: true }); refreshGenres();
}
const importMenu = () => [
  { label: 'Folders or files…', hint: '⌘I', run: () => doImport() },
  '-', { label: 'From rekordbox…', run: () => externalImportDialog('rekordbox') }, { label: 'From Engine DJ…', run: () => externalImportDialog('engine') },
];
$('#btn-import').addEventListener('click', (e) => { const r = e.currentTarget.getBoundingClientRect(); popMenu(importMenu(), r.left, r.bottom + 4); });
let dragDepth = 0;
window.addEventListener('dragenter', (e) => { if (e.dataTransfer.types.includes('Files')) { dragDepth++; $('#drop-hint').hidden = false; } });
window.addEventListener('dragleave', (e) => { if (e.dataTransfer.types.includes('Files') && --dragDepth <= 0) { dragDepth = 0; $('#drop-hint').hidden = true; } });
window.addEventListener('dragover', (e) => { if (e.dataTransfer.types.includes('Files')) e.preventDefault(); });
window.addEventListener('drop', (e) => {
  if (!e.dataTransfer.types.includes('Files')) return;
  e.preventDefault(); dragDepth = 0; $('#drop-hint').hidden = true;
  const paths = [...e.dataTransfer.files].map(f => window.crate.pathForFile(f)).filter(Boolean);
  if (paths.length) doImport(paths);
});

// ---------------------------------------------------------------- wiring
const runSearch = debounce(() => loadTracks(), 160);
$('#search').addEventListener('input', (e) => { state.view.search = e.target.value; runSearch(); });
$('#search').addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.target.value = ''; state.view.search = ''; loadTracks(); } if (e.key === 'ArrowDown') { e.preventDefault(); $('#table').focus(); if (state.tracks.length) selectIndex(0); } });
$('#key-notation').value = state.notation;
$('#key-notation').addEventListener('change', (e) => { state.notation = e.target.value; store.set('notation', state.notation); renderRows(); renderInspector(); });
$('#new-menu').addEventListener('click', (e) => {
  const r = e.currentTarget.getBoundingClientRect();
  popMenu([{ label: 'Playlist', hint: '⌘N', run: () => newPlaylist('playlist') }, { label: 'Smartlist', hint: '⇧⌘N', run: () => newPlaylist('smart') }, { label: 'Folder', run: () => newPlaylist('folder') }], r.left, r.bottom + 4);
});
const setInspector = (on) => { $('.main').classList.toggle('no-inspector', !on); $('#btn-inspector').setAttribute('aria-pressed', String(on)); store.set('inspector', on); renderRows(); };
$('#btn-inspector').addEventListener('click', () => setInspector($('.main').classList.contains('no-inspector')));
setInspector(store.get('inspector', true));

document.addEventListener('keydown', (e) => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName) || document.querySelector('.backdrop');
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'f' && !e.shiftKey) { e.preventDefault(); $('#search').focus(); $('#search').select(); }
  else if (e.key === ' ' && !typing) { e.preventDefault(); togglePlay(); }
  else if (!typing && !openMenu && !document.activeElement?.closest?.('.sidebar')) tableKeys(e);
});

window.crate.on('library-changed', () => { refreshPlaylists(); });
window.crate.onMenu((action) => ({
  import: () => doImport(), 'import-rekordbox': () => externalImportDialog('rekordbox'), 'import-engine': () => externalImportDialog('engine'), 'new-playlist': () => newPlaylist('playlist'), 'new-smartlist': () => newPlaylist('smart'),
  'export-rekordbox': rekordboxDialog, 'export-rekordbox-db': rekordboxDbDialog, 'export-engine': engineDialog, 'export-m3u': exportM3u, 'check-missing': checkMissing,
  'cleanup-fixes': fixesDialog, 'cleanup-duplicates': duplicatesDialog, 'cleanup-genres': genresDialog, 'cleanup-replace': replaceDialog, 'cleanup-rename': renameFilesDialog,
})[action]?.());

(async function init() {
  if (window.crate.platform !== 'darwin') document.querySelector('.toolbar').style.paddingLeft = '14px';
  window.crate.call('app.version').then(v => {
    document.title = `Crate ${v}`;
    const b = document.querySelector('.brand'); b.title = `Crate version ${v}`;
    b.append(el('span', { class: 'brand-ver', text: `v${v}` }));
  }).catch(() => {});
  await refreshPlaylists(); await loadTracks(); renderInspector(); refreshGenres();
})();
