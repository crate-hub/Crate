'use strict';
// rekordbox native export: writes straight into rekordbox 6/7's own library (master.db, encrypted
// with SQLCipher) and its playlist list (masterPlaylists6.xml), the way rekordbox itself does.
//
// Safety:
//  - refuses while rekordbox is open, or while master.db-wal holds changes rekordbox hasn't saved;
//  - copies master.db and masterPlaylists6.xml into a dated backup folder first;
//  - makes every change on a decrypted temporary copy, in one transaction, then checks it with
//    SQLite's integrity check, re-encrypts it, decrypts that result again to confirm it, and only
//    then swaps it in. If anything fails, the original files are put back.
//
// What it writes (following pyrekordbox and rbx, which compare against real rekordbox libraries):
//  - tracks: new files are added (rekordbox analyses them when you load them); tracks already in
//    rekordbox get Crate's tags; files Crate renamed are moved instead of added twice;
//  - playlists: every playlist, folder and smart playlist in rekordbox is replaced with Crate's, at
//    the top level (smartlists as rekordbox smart playlists where the rules convert); rekordbox's
//    own system lists stay;
//  - cue points for tracks that have them in Crate (djmdCue + the contentCue copy rekordbox keeps);
//  - the update counters (USNs) rekordbox uses to notice changes.
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');
const { decryptFile, encryptFile, isPlainSqlite } = require('../import/sqlcipher');
const rbImport = require('../import/rekordbox');
const keys = require('../keys');
const cueLib = require('../cues');
const { toRekordbox } = require('../smartconvert');
const mpeg = require('../tags/mpeg');

const PASSPHRASE = '402fd482c38817c35ffa8ffb8c7d93143b749e7d315df7a81732a1ff43608497';
const FILE_TYPE = { mp3: 1, m4a: 4, mp4: 4, aac: 4, alac: 4, flac: 5, wav: 11, aif: 12, aiff: 12 };
const ATTR = { PLAYLIST: 0, FOLDER: 1, SMART: 4 };
const pad = (n, w = 2) => String(n).padStart(w, '0');
// rekordbox ignores rows whose timestamps lack milliseconds and the time zone.
const rbNow = (d = new Date()) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}.${pad(d.getUTCMilliseconds(), 3)} +00:00`;
const isoStamp = (s) => s.replace(' ', 'T').replace(' +', '+'); // contentCue's form of the same time
const toPosix = (p) => String(p).replace(/\\/g, '/');
const hexId = (id) => BigInt(id).toString(16).toUpperCase();

/** Is rekordbox's library here, and can Crate write to it? */
function inspect(dir = rbImport.DEFAULT_DIR) {
  const loc = rbImport.locate(dir);
  if (!loc.ok) return loc;
  if (!loc.xmlFile) return { ...loc, ok: false, reason: 'masterPlaylists6.xml is missing next to master.db, so rekordbox wouldn’t show new playlists. Open and quit rekordbox once, then try again.' };
  const wal = loc.dbFile + '-wal';
  if (fs.existsSync(wal) && fs.statSync(wal).size > 0) return { ...loc, ok: false, reason: 'rekordbox is open, or didn’t close cleanly, so some of its changes are still unsaved. Quit rekordbox (open and quit it again if it isn’t running), then try again.' };
  return { ...loc, ok: true, encrypted: !isPlainSqlite(loc.dbFile) };
}

function isVbrMp3(file) {
  try {
    const fd = fs.openSync(file, 'r');
    try {
      const size = fs.fstatSync(fd).size; const head = Buffer.alloc(10); fs.readSync(fd, head, 0, 10, 0);
      let tag = 0;
      if (head.toString('latin1', 0, 3) === 'ID3') tag = 10 + (((head[6] & 0x7f) << 21) | ((head[7] & 0x7f) << 14) | ((head[8] & 0x7f) << 7) | (head[9] & 0x7f)) + ((head[5] & 0x10) ? 10 : 0);
      const buf = Buffer.alloc(Math.min(size, tag + 128 * 1024)); fs.readSync(fd, buf, 0, buf.length, 0);
      return !!mpeg.info(buf, tag, size).vbr;
    } finally { fs.closeSync(fd); }
  } catch { return true; } // can't tell: treat as VBR, so no cues are written that could land in the wrong place
}

/**
 * tracks: library rows; tree: Library.playlistTree({ withTracks: true }).
 * opts: { dir, cues (Map trackId -> cues) | null, previousPaths (Map) | null, keyNotation }
 */
function exportTo(tracks, tree, { dir = rbImport.DEFAULT_DIR, cues = null, previousPaths = null, keyNotation = 'musical' } = {}) {
  const loc = inspect(dir); if (!loc.ok) throw new Error(loc.reason);
  const res = { added: 0, updated: 0, unchanged: 0, moved: 0, skipped: 0, playlists: 0, smartlists: 0, smartAsPlaylists: [],
    cueTracks: 0, cueSkipped: [], removed: 0, backup: null, dir: loc.dir };

  // 1. Backup
  const d = new Date(); const tag = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}.${pad(d.getMinutes())}.${pad(d.getSeconds())}`;
  const backupDir = path.join(loc.dir, 'Crate backups', tag); fs.mkdirSync(backupDir, { recursive: true });
  fs.copyFileSync(loc.dbFile, path.join(backupDir, 'master.db'));
  fs.copyFileSync(loc.xmlFile, path.join(backupDir, 'masterPlaylists6.xml'));
  res.backup = backupDir;

  // 2. Work on a decrypted copy
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'crate-rbx-')); const plain = path.join(work, 'master.db');
  try {
    if (loc.encrypted) decryptFile(loc.dbFile, plain, PASSPHRASE); else fs.copyFileSync(loc.dbFile, plain);
    const xmlText = fs.readFileSync(loc.xmlFile, 'utf8');
    const xml = editPlaylistXml(xmlText);
    const db = new DatabaseSync(plain);
    try {
      db.exec('PRAGMA foreign_keys = OFF');
      db.exec('BEGIN');
      try { write(db, xml, tracks, tree, { cues, previousPaths, keyNotation }, res); db.exec('COMMIT'); }
      catch (e) { db.exec('ROLLBACK'); throw e; }
      const ok = db.prepare('PRAGMA integrity_check').get(); if (Object.values(ok)[0] !== 'ok') throw new Error('The updated rekordbox database failed its integrity check, so nothing was changed.');
    } finally { db.close(); }
    for (const ext of ['-wal', '-shm', '-journal']) if (fs.existsSync(plain + ext)) { if (ext === '-wal' && fs.statSync(plain + ext).size) throw new Error('Internal error: changes were left in a journal.'); fs.rmSync(plain + ext, { force: true }); }

    // 3. Re-encrypt and confirm before swapping in
    const tmpDb = loc.dbFile + '.crate-new', tmpXml = loc.xmlFile + '.crate-new';
    if (loc.encrypted) {
      encryptFile(plain, tmpDb, PASSPHRASE, loc.dbFile);
      const check = path.join(work, 'check.db'); decryptFile(tmpDb, check, PASSPHRASE);
      if (!fs.readFileSync(check).equals(fs.readFileSync(plain))) throw new Error('Encrypting the updated rekordbox database didn’t check out, so nothing was changed.');
    } else fs.copyFileSync(plain, tmpDb);
    fs.writeFileSync(tmpXml, xml.text(), 'utf8');
    try { fs.renameSync(tmpDb, loc.dbFile); fs.renameSync(tmpXml, loc.xmlFile); }
    catch (e) { // put the originals back
      fs.copyFileSync(path.join(backupDir, 'master.db'), loc.dbFile); fs.copyFileSync(path.join(backupDir, 'masterPlaylists6.xml'), loc.xmlFile);
      throw e;
    } finally { fs.rmSync(tmpDb, { force: true }); fs.rmSync(tmpXml, { force: true }); }
    for (const ext of ['-shm']) fs.rmSync(loc.dbFile + ext, { force: true }); // stale index of the old file
  } finally { fs.rmSync(work, { recursive: true, force: true }); }
  return res;
}

/** masterPlaylists6.xml, edited line by line so everything rekordbox wrote stays as it was. */
function editPlaylistXml(text) {
  const nl = text.includes('\r\n') ? '\r\n' : '\n';
  let lines = text.split(/\r?\n/);
  const indentOf = () => { const l = lines.find(x => /^\s*<NODE /.test(x)); return l ? l.match(/^\s*/)[0] : '    '; };
  return {
    remove(id) { const needle = `<NODE Id="${hexId(id)}"`; lines = lines.filter(l => !l.includes(needle)); },
    add(id, parentId, attribute, ms) {
      const node = `${indentOf()}<NODE Id="${hexId(id)}" ParentId="${parentId === 'root' ? '0' : hexId(parentId)}" Attribute="${attribute}" Timestamp="${ms}" Lib_Type="0" CheckType="0"/>`;
      let i = lines.findIndex(l => l.includes('</PLAYLISTS>'));
      if (i < 0) { // <PLAYLISTS/> with no children
        const j = lines.findIndex(l => /<PLAYLISTS\s*\/>/.test(l)); if (j < 0) throw new Error('masterPlaylists6.xml has no PLAYLISTS section.');
        const ind = lines[j].match(/^\s*/)[0]; lines.splice(j, 1, `${ind}<PLAYLISTS>`, `${ind}</PLAYLISTS>`); i = j + 1;
      }
      lines.splice(i, 0, node);
    },
    text: () => lines.join(nl),
  };
}

function write(db, xml, tracks, tree, { cues, previousPaths, keyNotation }, res) {
  const now = rbNow(); const nowMs = Date.now(); const today = now.slice(0, 10);
  const cols = (t) => new Set(db.prepare(`PRAGMA table_info(${t})`).all().map(c => c.name));
  const contentCols = cols('djmdContent');

  // Update sequence numbers: every change takes the next one, like rekordbox.
  const reg = db.prepare("SELECT int_1 FROM agentRegistry WHERE registry_id = 'localUpdateCount'").get();
  let usn = reg ? Number(reg.int_1) || 0 : 0;
  const nextUsn = () => ++usn;

  // rekordbox-style 28-bit numeric IDs, unique per table.
  const idTaken = {};
  const newId = (table, field = 'ID') => {
    const q = idTaken[table + field] || (idTaken[table + field] = db.prepare(`SELECT 1 FROM ${table} WHERE ${field} = ?`));
    for (;;) { const id = crypto.randomBytes(4).readUInt32BE(0) >>> 4; if (id >= 100 && !q.get(String(id))) return String(id); }
  };
  const uuid = () => crypto.randomUUID();

  // Lookup tables (artist, album, genre, label, key): reuse by exact name, else add.
  const named = {};
  const lookup = (table, name, extra = {}) => {
    name = String(name || '').trim(); if (!name) return null;
    const m = named[table] || (named[table] = new Map(db.prepare(`SELECT ID, ${table === 'djmdKey' ? 'ScaleName' : 'Name'} AS n FROM ${table} WHERE IFNULL(rb_local_deleted, 0) = 0`).all().map(r => [r.n, String(r.ID)])));
    if (m.has(name)) return m.get(name);
    const id = newId(table);
    if (table === 'djmdKey') {
      const seq = (db.prepare('SELECT MAX(Seq) s FROM djmdKey').get().s || 0) + 1;
      db.prepare('INSERT INTO djmdKey (ID, ScaleName, Seq, UUID, rb_local_usn, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(id, name, seq, uuid(), nextUsn(), now, now);
    } else {
      const c = ['ID', 'Name', 'UUID', 'rb_local_usn', 'created_at', 'updated_at', ...Object.keys(extra)];
      db.prepare(`INSERT INTO ${table} (${c.join(', ')}) VALUES (${c.map(() => '?').join(', ')})`).run(id, name, uuid(), nextUsn(), now, now, ...Object.values(extra));
    }
    m.set(name, id); return id;
  };
  // Keys: match rekordbox's existing key names in any notation (8A = Am).
  const keyRows = db.prepare('SELECT ID, ScaleName FROM djmdKey WHERE IFNULL(rb_local_deleted, 0) = 0').all();
  const keyId = (k) => {
    const p = keys.parse(k); if (!p) return null;
    const hit = keyRows.find(r => { const q = keys.parse(r.ScaleName); return q && q.num === p.num && q.letter === p.letter; });
    return hit ? String(hit.ID) : lookup('djmdKey', keys.format(k, keyNotation === 'camelot' || keyNotation === 'openkey' ? keyNotation : 'musical'));
  };

  // ---- tracks
  const device = db.prepare('SELECT ID, MasterDBID FROM djmdDevice ORDER BY created_at LIMIT 1').get() || {};
  const prop = db.prepare('SELECT DBID FROM djmdProperty LIMIT 1').get() || {};
  const menu = db.prepare("SELECT rb_local_usn FROM djmdMenuItems WHERE Name = 'TRACK'").get();
  const byPath = new Map(db.prepare('SELECT ID, FolderPath FROM djmdContent WHERE IFNULL(rb_local_deleted, 0) = 0').all().map(r => [r.FolderPath, String(r.ID)]));
  const getC = db.prepare('SELECT * FROM djmdContent WHERE ID = ?');
  const rbId = new Map();
  for (const t of tracks) {
    if (t.missing || !fs.existsSync(t.path)) { res.skipped++; continue; }
    const fp = toPosix(t.path);
    let id = byPath.get(fp);
    if (!id && previousPaths) for (const old of previousPaths.get(t.id) || []) {
      const oid = byPath.get(toPosix(old));
      if (oid) { db.prepare('UPDATE djmdContent SET FolderPath = ?, FileNameL = ?, rb_local_usn = ?, updated_at = ? WHERE ID = ?').run(fp, path.basename(t.path), nextUsn(), now, oid); byPath.delete(toPosix(old)); byPath.set(fp, oid); id = oid; res.moved++; break; }
    }
    const meta = {
      Title: t.title || '', ArtistID: lookup('djmdArtist', t.artist), AlbumID: lookup('djmdAlbum', t.album), GenreID: lookup('djmdGenre', t.genre),
      LabelID: lookup('djmdLabel', t.label), RemixerID: lookup('djmdArtist', t.remixer), ComposerID: lookup('djmdArtist', t.composer),
      KeyID: keyId(t.key), BPM: t.bpm ? Math.round(t.bpm * 100) : 0, Rating: Math.max(0, Math.min(5, t.rating || 0)),
      ReleaseYear: t.year || 0, Commnt: t.comment || '', TrackNo: t.trackNumber || 0, Subtitle: t.mix || '',
    };
    if (id) {
      const cur = getC.get(id);
      const changed = Object.keys(meta).filter(k => contentCols.has(k) && String(cur[k] ?? '') !== String(meta[k] ?? '') && !(cur[k] == null && (meta[k] === '' || meta[k] === 0)));
      if (changed.length) {
        db.prepare(`UPDATE djmdContent SET ${changed.map(k => `${k} = ?`).join(', ')}, rb_local_usn = ?, updated_at = ? WHERE ID = ?`).run(...changed.map(k => meta[k]), nextUsn(), now, id);
        res.updated++;
      } else res.unchanged++;
    } else {
      id = newId('djmdContent');
      const ext = path.extname(t.path).slice(1).toLowerCase();
      const row = {
        ID: id, UUID: uuid(), FolderPath: fp, FileNameL: path.basename(t.path), FileSize: t.size || fs.statSync(t.path).size, FileType: FILE_TYPE[ext] || 0,
        Length: Math.round(t.duration || 0), BitRate: t.bitrate || 0, SampleRate: t.sampleRate || 0, ...meta,
        ContentLink: menu ? menu.rb_local_usn : null, DateCreated: today, StockDate: String(t.dateAdded || today).slice(0, 10),
        DeviceID: device.ID ?? null, MasterDBID: device.MasterDBID ?? prop.DBID ?? null, MasterSongID: id, HotCueAutoLoad: 'on',
        DJPlayCount: 0, rb_file_id: newId('djmdContent', 'rb_file_id'), rb_local_usn: nextUsn(), created_at: now, updated_at: now,
      };
      const ks = Object.keys(row).filter(k => contentCols.has(k));
      db.prepare(`INSERT INTO djmdContent (${ks.join(', ')}) VALUES (${ks.map(() => '?').join(', ')})`).run(...ks.map(k => row[k]));
      byPath.set(fp, id); res.added++;
    }
    rbId.set(t.id, id);
  }

  // ---- cue points
  if (cues && cues.size && cols('djmdCue').size) {
    const hasContentCue = cols('contentCue').size > 0;
    for (const t of tracks) {
      const list = cueLib.normalize(cues.get(t.id) || []); const id = rbId.get(t.id);
      if (!list.length || !id) continue;
      const ext = path.extname(t.path).slice(1).toLowerCase();
      // rekordbox also stores seek data for FLAC and frame offsets for VBR MP3, which no open tool reproduces.
      if (ext === 'flac' || (ext === 'mp3' && isVbrMp3(t.path))) { res.cueSkipped.push({ title: t.title, reason: ext === 'flac' ? 'FLAC' : 'VBR MP3' }); continue; }
      writeCues(db, id, list, { now, newId, uuid, nextUsn, hasContentCue });
      res.cueTracks++;
    }
  }

  // ---- playlists: replace every playlist, folder and smart playlist with Crate's, at the top level.
  // rekordbox's own system lists stay: Cloud Library Sync (100000), CUE Analysis Playlist (200000)
  // and anything with a negative (system) attribute.
  const SPECIAL = new Set(['100000', '200000']);
  const delSongs = db.prepare('DELETE FROM djmdSongPlaylist WHERE PlaylistID = ?'), delPl = db.prepare('DELETE FROM djmdPlaylist WHERE ID = ?');
  for (const old of db.prepare('SELECT ID, Attribute FROM djmdPlaylist WHERE IFNULL(rb_local_deleted, 0) = 0').all()) {
    if (SPECIAL.has(String(old.ID)) || Number(old.Attribute) < 0) continue;
    delSongs.run(String(old.ID)); delPl.run(String(old.ID)); xml.remove(String(old.ID)); res.removed++;
  }
  if (res.removed) nextUsn(); // the deletions count as one change
  const rootStart = db.prepare("SELECT MAX(Seq) s FROM djmdPlaylist WHERE ParentID = 'root' AND IFNULL(rb_local_deleted, 0) = 0").get().s || 0;

  const insPl = db.prepare('INSERT INTO djmdPlaylist (ID, Seq, Name, ImagePath, Attribute, ParentID, SmartList, UUID, rb_local_usn, created_at, updated_at) VALUES (?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?)');
  const insSong = db.prepare('INSERT INTO djmdSongPlaylist (ID, PlaylistID, ContentID, TrackNo, UUID, rb_local_usn, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
  const makeList = (name, parentId, seq, attribute, smart = null) => {
    const id = newId('djmdPlaylist'); const smartXml = smart ? smart(id) : null;
    insPl.run(id, seq, name, attribute, parentId, smartXml, uuid(), nextUsn(), now, now);
    xml.add(id, parentId, attribute, nowMs);
    return id;
  };
  const walk = (nodes, parentId) => {
    let seq = parentId === 'root' ? rootStart : 0; // after rekordbox's system lists
    for (const n of nodes) {
      seq++;
      if (n.type === 'folder') { walk(n.children || [], makeList(n.name, parentId, seq, ATTR.FOLDER)); continue; }
      if (n.type === 'smart') {
        const test = toRekordbox(n.rules || {}, 1);
        if (!test.error) { makeList(n.name, parentId, seq, ATTR.SMART, (id) => toRekordbox(n.rules || {}, id).xml); res.smartlists++; continue; }
        res.smartAsPlaylists.push({ name: n.name, reason: test.error });
      }
      const pid = makeList(n.name, parentId, seq, ATTR.PLAYLIST); res.playlists++;
      let no = 0; const seen = new Set();
      for (const tid of n.trackIds || []) {
        const cid = rbId.get(tid); if (!cid || seen.has(cid)) continue; seen.add(cid);
        insSong.run(uuid(), pid, cid, ++no, uuid(), nextUsn(), now, now);
      }
    }
  };
  walk(tree, 'root');

  if (reg) db.prepare("UPDATE agentRegistry SET int_1 = ? WHERE registry_id = 'localUpdateCount'").run(usn);
}

/** Replaces a track's cue points: djmdCue rows plus the JSON copy in contentCue, as rekordbox keeps them. */
function writeCues(db, contentId, list, { now, newId, uuid, nextUsn, hasContentCue }) {
  const content = db.prepare('SELECT UUID, CueUpdated FROM djmdContent WHERE ID = ?').get(contentId);
  const removed = db.prepare('SELECT COUNT(*) n FROM djmdCue WHERE ContentID = ?').get(contentId).n;
  db.prepare('DELETE FROM djmdCue WHERE ContentID = ?').run(contentId);
  const ms = (s) => Math.round(s * 1000); const frame = (m) => Math.floor(m * 150 / 1000);
  const entries = []; let memoryCount = 0;
  const ins = db.prepare(`INSERT INTO djmdCue (ID, ContentID, InMsec, InFrame, InMpegFrame, InMpegAbs, OutMsec, OutFrame, OutMpegFrame, OutMpegAbs,
    Kind, Color, ColorTableIndex, ActiveLoop, Comment, BeatLoopSize, CueMicrosec, ContentUUID, UUID, created_at, updated_at)
    VALUES (?, ?, ?, ?, 0, 0, ?, ?, 0, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  for (const c of list) {
    const hot = c.kind === 'hot';
    if (!hot && ++memoryCount > 10) continue; // rekordbox keeps at most 10 memory cues
    const inMs = ms(c.start), loop = c.end != null, outMs = loop ? ms(c.end) : -1;
    const kind = hot ? (c.num < 3 ? c.num + 1 : c.num + 2) : 0; // A-C = 1-3, D-H = 5-9 (4 is skipped)
    let color, cti;
    if (loop) { color = 255; cti = hot ? Math.max(0, cueLib.nearest(cueLib.RB_HOT, c.color)) : 0; }
    else if (hot) { color = -1; const i = cueLib.nearest(cueLib.RB_HOT, c.color); cti = i > 0 ? i : null; }
    else { const i = cueLib.nearest(cueLib.RB_MEMORY, c.color); color = i >= 0 ? i : -1; cti = null; }
    const row = { ID: newId('djmdCue'), ContentID: contentId, ContentUUID: content.UUID, InMsec: inMs, InFrame: frame(inMs), InMpegFrame: 0, InMpegAbs: 0,
      OutMsec: outMs, OutFrame: loop ? frame(outMs) : 0, OutMpegFrame: 0, OutMpegAbs: 0, Kind: kind, Color: color, ColorTableIndex: cti,
      ActiveLoop: loop ? 0 : null, Comment: loop ? (c.name || '') : (c.name || null), BeatLoopSize: loop ? 0 : null, CueMicrosec: loop ? 0 : null, UUID: uuid() };
    ins.run(row.ID, contentId, row.InMsec, row.InFrame, row.OutMsec, row.OutFrame, row.Kind, row.Color, row.ColorTableIndex, row.ActiveLoop, row.Comment,
      row.BeatLoopSize, row.CueMicrosec, row.ContentUUID, row.UUID, now, now);
    // contentCue entry: rekordbox's field order, NULL fields and an empty comment left out.
    const e = {}; for (const k of ['ID', 'ContentID', 'ContentUUID', 'InMsec', 'InFrame', 'InMpegFrame', 'InMpegAbs', 'OutMsec', 'OutFrame', 'OutMpegFrame', 'OutMpegAbs',
      'Kind', 'Color', 'ColorTableIndex', 'ActiveLoop', 'Comment', 'BeatLoopSize', 'CueMicrosec']) if (row[k] != null && !(k === 'Comment' && row[k] === '')) e[k] = row[k];
    e.UUID = row.UUID; e.created_at = isoStamp(now); e.updated_at = isoStamp(now);
    entries.push(e);
  }
  if (hasContentCue) {
    const json = JSON.stringify(entries);
    const existing = db.prepare('SELECT ID FROM contentCue WHERE ContentID = ?').get(contentId);
    if (existing) db.prepare('UPDATE contentCue SET Cues = ?, rb_cue_count = ?, rb_local_usn = ?, updated_at = ? WHERE ContentID = ?').run(json, entries.length, nextUsn(), now, contentId);
    else db.prepare(`INSERT INTO contentCue (ID, ContentID, Cues, rb_cue_count, UUID, rb_data_status, rb_local_data_status, rb_local_deleted, rb_local_synced, rb_local_usn, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, 0, 0, 0, 0, ?, ?, ?)`).run(content.UUID || uuid(), contentId, json, entries.length, uuid(), nextUsn(), now, now);
  }
  const bump = removed + entries.length;
  db.prepare('UPDATE djmdContent SET CueUpdated = ?, rb_local_usn = ?, updated_at = ? WHERE ID = ?').run(String((Number(content.CueUpdated) || 0) + bump), nextUsn(), now, contentId);
}

module.exports = { exportTo, inspect, editPlaylistXml, PASSPHRASE, DEFAULT_DIR: rbImport.DEFAULT_DIR };
