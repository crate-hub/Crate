'use strict';
// rekordbox XML (DJ_PLAYLISTS 1.0.0). rekordbox imports it via Preferences > Advanced > Database >
// "rekordbox xml"; Engine DJ can also read it from its rekordbox library panel.
const fs = require('fs');
const cueLib = require('../cues');
const path = require('path');
const keys = require('../keys');

const KIND = { mp3: 'MP3 File', flac: 'FLAC File', mp4: 'M4A File', wav: 'WAV File', aiff: 'AIFF File' };
const RATING = [0, 51, 102, 153, 204, 255];
const xml = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
  .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '');

/** file URL in the form rekordbox writes: file://localhost/Users/... (Windows: file://localhost/C:/...) */
function location(p) {
  const abs = path.resolve(p).replace(/\\/g, '/');
  const parts = abs.split('/').map((seg, i) => (i === 0 && /^[A-Za-z]:$/.test(seg)) ? seg : encodeURIComponent(seg));
  const joined = parts.join('/');
  return 'file://localhost' + (joined.startsWith('/') ? joined : '/' + joined);
}

/**
 * Build the XML. tracks: library rows; tree: Library.playlistTree({ withTracks: true }).
 * keyNotation: how keys are written to Tonality ('musical' is what rekordbox itself writes).
 */
function build(tracks, tree, { keyNotation = 'musical', productName = 'Crate', cues = null, stats = {} } = {}) {
  const ids = new Set(tracks.map(t => t.id));
  const out = ['<?xml version="1.0" encoding="UTF-8"?>', '<DJ_PLAYLISTS Version="1.0.0">',
    `  <PRODUCT Name="${xml(productName)}" Version="1.0.0" Company=""/>`, `  <COLLECTION Entries="${tracks.length}">`];
  for (const t of tracks) {
    const a = {
      TrackID: t.id, Name: t.title, Artist: t.artist, Composer: t.composer, Album: t.album, Grouping: t.grouping, Genre: t.genre,
      Kind: KIND[t.format] || 'Audio File', Size: t.size, TotalTime: Math.round(t.duration || 0), DiscNumber: 0,
      TrackNumber: t.trackNumber || 0, Year: t.year || 0, AverageBpm: (t.bpm || 0).toFixed(2),
      DateAdded: String(t.dateAdded || '').slice(0, 10), BitRate: t.bitrate || 0, SampleRate: t.sampleRate || 0,
      Comments: t.comment, PlayCount: 0, Rating: RATING[t.rating || 0] ?? 0, Location: location(t.path),
      Remixer: t.remixer, Tonality: t.key ? keys.format(t.key, keyNotation) : '', Label: t.label, Mix: t.mix,
    };
    const attrs = Object.entries(a).map(([k, v]) => `${k}="${xml(v)}"`).join(' ');
    // Cue points: POSITION_MARK (Num 0-7 = hot cue A-H, -1 = memory cue; Type 4 = loop).
    const marks = cues ? cueLib.toRekordboxMarks(cues.get(t.id) || []) : [];
    if (!marks.length) { out.push(`    <TRACK ${attrs}/>`); continue; }
    stats.cueTracks = (stats.cueTracks || 0) + 1;
    out.push(`    <TRACK ${attrs}>`);
    for (const m of marks) out.push('      <POSITION_MARK ' + Object.entries(m).map(([k, v]) => `${k}="${xml(v)}"`).join(' ') + '/>');
    out.push('    </TRACK>');
  }
  out.push('  </COLLECTION>', '  <PLAYLISTS>');
  const node = (n, ind) => {
    if (n.type === 'folder') {
      out.push(`${ind}<NODE Type="0" Name="${xml(n.name)}" Count="${n.children.length}">`);
      n.children.forEach(c => node(c, ind + '  ')); out.push(`${ind}</NODE>`);
    } else {
      const list = (n.trackIds || []).filter(id => ids.has(id));
      out.push(`${ind}<NODE Name="${xml(n.name)}" Type="1" KeyType="0" Entries="${list.length}">`);
      for (const id of list) out.push(`${ind}  <TRACK Key="${id}"/>`);
      out.push(`${ind}</NODE>`);
    }
  };
  out.push(`    <NODE Type="0" Name="ROOT" Count="${tree.length}">`); tree.forEach(n => node(n, '      ')); out.push('    </NODE>');
  out.push('  </PLAYLISTS>', '</DJ_PLAYLISTS>', '');
  return out.join('\n');
}

function write(file, tracks, tree, opts) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const stats = {}; const tmp = file + '.tmp'; fs.writeFileSync(tmp, build(tracks, tree, { ...opts, stats }), 'utf8'); fs.renameSync(tmp, file);
  return { file, tracks: tracks.length, cueTracks: stats.cueTracks || 0 };
}

module.exports = { build, write, location };
