'use strict';
// Engine DJ export: writes tracks and playlists into an existing Engine Library database (Database2/m.db).
// Engine DJ must be closed. A timestamped backup of m.db is made before every export.
// Every playlist and smartlist in Engine is replaced with Crate's, at the top level, so Engine's
// playlists end up exactly like Crate's. Engine analyses beatgrids/waveforms itself.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const crypto = require('crypto');
const keys = require('../keys');
const { toEngine } = require('../smartconvert');
const cueLib = require('../cues');

const DEFAULT_LIBRARY = path.join(os.homedir(), 'Music', 'Engine Library');
const dbPath = (libraryDir) => path.join(libraryDir, 'Database2', 'm.db');
const pad = n => String(n).padStart(2, '0');
const stamp = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;

function inspect(libraryDir = DEFAULT_LIBRARY) {
  const file = dbPath(libraryDir);
  if (!fs.existsSync(file)) return { ok: false, file, reason: 'No Engine Library found here. Open Engine DJ once so it creates its library, or choose the folder that contains "Database2".' };
  const db = new DatabaseSync(file, { readOnly: true });
  try {
    const info = db.prepare('SELECT uuid, schemaVersionMajor AS major, schemaVersionMinor AS minor, schemaVersionPatch AS patch FROM Information LIMIT 1').get();
    if (!info) return { ok: false, file, reason: 'The Engine database has no Information row.' };
    if (info.major < 2) return { ok: false, file, reason: `Engine database schema ${info.major}.${info.minor} is too old (needs Engine DJ 2 or later).` };
    const tracks = db.prepare('SELECT COUNT(*) n FROM Track').get().n;
    return { ok: true, file, version: `${info.major}.${info.minor}.${info.patch}`, tracks };
  } finally { db.close(); }
}

function backup(file) {
  const d = new Date(); const tag = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
  const dest = `${file}.crate-backup-${tag}`;
  fs.copyFileSync(file, dest);
  for (const ext of ['-wal', '-shm', '-journal']) if (fs.existsSync(file + ext)) fs.copyFileSync(file + ext, dest + ext);
  return dest;
}

/**
 * tracks: library rows to export; tree: Library.playlistTree({ withTracks: true }).
 * Returns { added, updated, skipped, playlists, backup }.
 */
function exportTo(tracks, tree, { libraryDir = DEFAULT_LIBRARY, cues = null, previousPaths = null } = {}) {
  const check = inspect(libraryDir); if (!check.ok) throw new Error(check.reason);
  const file = check.file; const bak = backup(file);
  const db = new DatabaseSync(file);
  const res = { added: 0, updated: 0, moved: 0, skipped: 0, playlists: 0, smartlists: 0, smartAsPlaylists: [], cueTracks: 0, cuesDropped: 0, removed: 0, backup: bak };
  try {
    db.exec('PRAGMA foreign_keys = OFF');
    const cols = new Set(db.prepare('PRAGMA table_info(Track)').all().map(c => c.name));
    const info = db.prepare('SELECT uuid, schemaVersionMajor AS major, schemaVersionMinor AS minor FROM Information LIMIT 1').get();
    // Engine has smartlists from database schema 2.21 on.
    const smartOk = (info.major > 2 || (info.major === 2 && info.minor >= 21)) && !!db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'Smartlist'").get();
    db.exec('BEGIN');
    try {
      // An AlbumArt row with no image, which tracks without imported artwork point at.
      let art = db.prepare("SELECT id FROM AlbumArt WHERE hash IS NULL OR hash = '' ORDER BY id LIMIT 1").get();
      if (!art) art = { id: Number(db.prepare('INSERT INTO AlbumArt (hash, albumArt) VALUES (NULL, NULL)').run().lastInsertRowid) };

      const byPath = new Map(db.prepare('SELECT id, path FROM Track').all().map(r => [r.path, r.id]));
      const engineId = new Map(); const now = Math.floor(Date.now() / 1000);
      for (const t of tracks) {
        if (t.missing || !fs.existsSync(t.path)) { res.skipped++; continue; }
        const rel = path.relative(libraryDir, t.path).split(path.sep).join('/');
        const meta = {
          title: t.title, artist: t.artist, album: t.album, genre: t.genre, comment: t.comment, label: t.label,
          composer: t.composer, remixer: t.remixer, year: t.year || null, rating: (t.rating || 0) * 20,
          key: keys.toEngine(t.key), bpm: t.bpm ? Math.round(t.bpm) : null,
        };
        let existing = byPath.get(rel);
        // A file Crate renamed: point Engine's existing track at the new name, keeping its cues and analysis.
        if (!existing && previousPaths) {
          for (const old of previousPaths.get(t.id) || []) {
            const oldRel = path.relative(libraryDir, old).split(path.sep).join('/'); const id = byPath.get(oldRel);
            if (id) {
              db.prepare('UPDATE Track SET path = ?, filename = ? WHERE id = ?').run(rel, path.basename(t.path), id);
              byPath.delete(oldRel); byPath.set(rel, id); existing = id; res.moved++; break;
            }
          }
        }
        if (existing) {
          const ks = Object.keys(meta).filter(k => cols.has(k));
          db.prepare(`UPDATE Track SET ${ks.map(k => `"${k}" = ?`).join(', ')} WHERE id = ?`).run(...ks.map(k => meta[k]), existing);
          engineId.set(t.id, existing); res.updated++;
        } else {
          const row = {
            ...meta, path: rel, filename: path.basename(t.path), fileType: path.extname(t.path).slice(1).toLowerCase(),
            fileBytes: t.size, length: Math.round(t.duration || 0), bitrate: t.bitrate || null, bpmAnalyzed: t.bpm || null,
            dateAdded: Math.floor(new Date(t.dateAdded || Date.now()).getTime() / 1000), dateCreated: now, lastEditTime: now,
            albumArtId: art.id, albumArt: 'image://planck/0', playOrder: 0, isPlayed: 0, isAvailable: 1, isAnalyzed: 0,
            isMetadataImported: 1, isMetadataOfPackedTrackChanged: 0, isPerfomanceDataOfPackedTrackChanged: 0,
            playedIndicator: 0, pdbImportKey: 0, isBeatGridLocked: 0, streamingFlags: 0, explicitLyrics: 0,
          };
          const ks = Object.keys(row).filter(k => cols.has(k));
          const id = Number(db.prepare(`INSERT INTO Track (${ks.map(k => `"${k}"`).join(', ')}) VALUES (${ks.map(() => '?').join(', ')})`).run(...ks.map(k => row[k])).lastInsertRowid);
          byPath.set(rel, id); engineId.set(t.id, id); res.added++;
        }
      }

      // Cue points go into PerformanceData. Only tracks that have cues in Crate are touched, so cues
      // made in Engine for other tracks stay. Other performance data (beatgrid, waveform) is kept.
      if (cues && cues.size && db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'PerformanceData'").get()) {
        const getP = db.prepare('SELECT trackData, quickCues FROM PerformanceData WHERE trackId = ?');
        const updP = db.prepare('UPDATE PerformanceData SET quickCues = ?, loops = ? WHERE trackId = ?');
        const insP = db.prepare('INSERT INTO PerformanceData (trackId, trackData, quickCues, loops) VALUES (?, ?, ?, ?)');
        const updPT = db.prepare('UPDATE PerformanceData SET trackData = ?, quickCues = ?, loops = ? WHERE trackId = ?');
        for (const t of tracks) {
          const list = cues.get(t.id); const eid = engineId.get(t.id);
          if (!list || !list.length || !eid) continue;
          const row = getP.get(eid);
          const rate = (row && cueLib.engineTrackData(row.trackData)?.sampleRate) || t.sampleRate;
          if (!rate) continue;
          const enc = cueLib.toEngine(list, rate, row && row.quickCues);
          // A track Engine hasn't analysed yet has an empty row (or none): give it the sample rate too.
          const td = cueLib.makeEngineTrackData(rate, (t.duration || 0) * rate);
          if (row && row.trackData) updP.run(enc.quickCues, enc.loops, eid);
          else if (row) updPT.run(td, enc.quickCues, enc.loops, eid);
          else insP.run(eid, td, enc.quickCues, enc.loops);
          res.cueTracks++; res.cuesDropped += enc.dropped;
        }
      }

      // Replace every playlist and smartlist in Engine with Crate's, at the top level.
      // (The prepare list is a separate table and stays.)
      res.removed = db.prepare('SELECT COUNT(*) n FROM Playlist WHERE isPersisted = 1').get().n + (smartOk ? db.prepare('SELECT COUNT(*) n FROM Smartlist').get().n : 0);
      db.exec('DELETE FROM PlaylistEntity WHERE listId IN (SELECT id FROM Playlist WHERE isPersisted = 1)');
      db.exec('DELETE FROM Playlist WHERE isPersisted = 1');
      if (smartOk) db.exec('DELETE FROM Smartlist');
      const insS = smartOk ? db.prepare('INSERT INTO Smartlist (listUuid, title, parentPlaylistPath, nextPlaylistPath, nextListUuid, rules, lastEditTime) VALUES (?, ?, ?, ?, ?, ?, ?)') : null;
      const insP = db.prepare('INSERT INTO Playlist (title, parentListId, isPersisted, nextListId, lastEditTime, isExplicitlyExported) VALUES (?, ?, 1, 0, ?, 0)');
      const insE = db.prepare('INSERT INTO PlaylistEntity (listId, trackId, databaseUuid, nextEntityId, membershipReference) VALUES (?, ?, ?, 0, 0)');
      const link = db.prepare('UPDATE PlaylistEntity SET nextEntityId = ? WHERE id = ?');
      const ts = stamp();
      // Engine needs unique names among siblings (left over non-persisted lists count too).
      const taken = (parentId) => new Set(db.prepare('SELECT title FROM Playlist WHERE parentListId = ?').all(parentId).map(r => String(r.title).toLowerCase()));
      let lastTitle = '';
      const addList = (name, parentId, used) => {
        let title = name, n = 2; while (used.has(title.toLowerCase())) title = `${name} (${n++})`; used.add(title.toLowerCase()); lastTitle = title;
        res.playlists++; return Number(insP.run(title, parentId, ts).lastInsertRowid);
      };
      const walk = (nodes, parentId, pathKey) => {
        const used = taken(parentId); const smart = [];
        for (const n of nodes) {
          let conv = null;
          if (n.type === 'smart') {
            conv = smartOk ? toEngine(n.rules || {}) : { error: 'this Engine version has no smartlists' };
            if (!conv.error) { smart.push({ n, json: conv.json }); continue; } // written after the playlists below
            res.smartAsPlaylists.push({ name: n.name, reason: conv.error });
          }
          const id = addList(n.name, parentId, used);
          if (n.type === 'folder') { walk(n.children, id, `${pathKey}${lastTitle};`); continue; }
          let prev = null; const seen = new Set();
          for (const tid of n.trackIds || []) {
            const eid = engineId.get(tid); if (!eid || seen.has(eid)) continue; seen.add(eid);
            const id2 = Number(insE.run(id, eid, info.uuid).lastInsertRowid);
            if (prev) link.run(id2, prev); prev = id2;
          }
        }
        // Smartlists go after this folder's playlists, chained through nextListUuid (empty = last).
        const sUsed = new Set(); const uuids = smart.map(() => crypto.randomUUID());
        smart.forEach(({ n, json }, i) => {
          let title = n.name, k = 2; while (sUsed.has(title.toLowerCase())) title = `${n.name} (${k++})`; sUsed.add(title.toLowerCase());
          insS.run(uuids[i], title, pathKey, '', uuids[i + 1] || '', json, ts); res.smartlists++;
        });
      };
      walk(tree, 0, ''); // top level: parent 0, smartlist path ''
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
  } finally { db.close(); }
  return res;
}

module.exports = { exportTo, inspect, DEFAULT_LIBRARY };
