'use strict';
// M3U8 playlists, one file per playlist, folders mirrored as directories.
const fs = require('fs');
const path = require('path');

const safe = s => String(s).replace(/[\/\\:*?"<>|\u0000-\u001f]/g, '_').replace(/^\.+/, '_').trim() || 'Untitled';

function playlistText(tracks) {
  const lines = ['#EXTM3U'];
  for (const t of tracks) { lines.push(`#EXTINF:${Math.round(t.duration || 0)},${t.artist ? t.artist + ' - ' : ''}${t.title}`); lines.push(t.path); }
  return lines.join('\n') + '\n';
}

/** Write the tree under `dir`. getTracks(ids) -> rows. Returns the list of files written. */
function write(dir, tree, getTracks) {
  const written = [];
  const walk = (nodes, d) => {
    fs.mkdirSync(d, { recursive: true });
    for (const n of nodes) {
      if (n.type === 'folder') walk(n.children, path.join(d, safe(n.name)));
      else { const f = path.join(d, safe(n.name) + '.m3u8'); fs.writeFileSync(f, playlistText(getTracks(n.trackIds || [])), 'utf8'); written.push(f); }
    }
  };
  walk(tree, dir);
  return written;
}

module.exports = { write, playlistText };
