'use strict';
// Smartlist rules -> parameterised SQL. Rules format:
// { match: 'all'|'any', conditions: [{ field, op, value, value2 }], sort?: { field, dir }, limit? }
const keys = require('./keys');

const TEXT = ['title', 'artist', 'album', 'genre', 'comment', 'label', 'remixer', 'composer', 'grouping', 'mix', 'path', 'format'];
const NUMBER = ['bpm', 'year', 'rating', 'duration', 'bitrate', 'trackNumber', 'sampleRate'];
const FIELDS = { ...Object.fromEntries(TEXT.map(f => [f, 'text'])), ...Object.fromEntries(NUMBER.map(f => [f, 'number'])),
  key: 'key', dateAdded: 'date', playlist: 'playlist' };
const OPS = {
  text: ['contains', 'not_contains', 'is', 'is_not', 'starts_with', 'ends_with', 'is_empty', 'not_empty'],
  number: ['eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'between'],
  key: ['is', 'is_not', 'compatible_with', 'is_empty', 'not_empty'],
  date: ['in_last_days', 'not_in_last_days', 'before', 'after'],
  playlist: ['in', 'not_in'],
};
const esc = s => String(s).replace(/[\\%_]/g, m => '\\' + m);

function condition(c) {
  const type = FIELDS[c.field]; if (!type) throw new Error(`Unknown smartlist field: ${c.field}`);
  if (!OPS[type].includes(c.op)) throw new Error(`Operator ${c.op} not valid for ${c.field}`);
  const col = `t.${c.field}`; const v = c.value;
  switch (type) {
    case 'text': switch (c.op) {
      case 'contains': return [`${col} LIKE ? ESCAPE '\\'`, [`%${esc(v)}%`]];
      case 'not_contains': return [`${col} NOT LIKE ? ESCAPE '\\'`, [`%${esc(v)}%`]];
      case 'is': return [`${col} = ? COLLATE NOCASE`, [String(v)]];
      case 'is_not': return [`${col} != ? COLLATE NOCASE`, [String(v)]];
      case 'starts_with': return [`${col} LIKE ? ESCAPE '\\'`, [`${esc(v)}%`]];
      case 'ends_with': return [`${col} LIKE ? ESCAPE '\\'`, [`%${esc(v)}`]];
      case 'is_empty': return [`${col} = ''`, []];
      case 'not_empty': return [`${col} != ''`, []];
    } break;
    case 'number': {
      const n = Number(v); if (Number.isNaN(n)) throw new Error(`${c.field} needs a number`);
      const ops = { eq: '=', ne: '!=', gt: '>', gte: '>=', lt: '<', lte: '<=' };
      if (c.op === 'between') { const m = Number(c.value2); if (Number.isNaN(m)) throw new Error('between needs two numbers'); return [`${col} BETWEEN ? AND ?`, [Math.min(n, m), Math.max(n, m)]]; }
      return [`${col} ${ops[c.op]} ?`, [n]];
    }
    case 'key': {
      if (c.op === 'is_empty') return [`t.key = ''`, []];
      if (c.op === 'not_empty') return [`t.key != ''`, []];
      const k = keys.parse(v); if (!k) throw new Error(`Unrecognised key: ${v}`);
      if (c.op === 'compatible_with') { const list = keys.compatible(v); return [`camelot(t.key) IN (${list.map(() => '?').join(',')})`, list]; }
      return [`camelot(t.key) ${c.op === 'is' ? '=' : 'IS NOT'} ?`, [keys.toCamelot(k)]];
    }
    case 'date': {
      if (c.op === 'in_last_days' || c.op === 'not_in_last_days') {
        const d = new Date(Date.now() - Number(v) * 864e5).toISOString();
        return [`t.dateAdded ${c.op === 'in_last_days' ? '>=' : '<'} ?`, [d]];
      }
      const d = new Date(v); if (Number.isNaN(+d)) throw new Error('Invalid date');
      return [`t.dateAdded ${c.op === 'before' ? '<' : '>='} ?`, [d.toISOString()]];
    }
    case 'playlist':
      return [`t.id ${c.op === 'in' ? 'IN' : 'NOT IN'} (SELECT trackId FROM playlist_tracks WHERE playlistId = ?)`, [Number(v)]];
  }
  throw new Error('Bad condition');
}

function compile(rules = {}) {
  const conds = rules.conditions || [];
  const parts = [], params = [];
  for (const c of conds) { const [sql, p] = condition(c); parts.push(`(${sql})`); params.push(...p); }
  const where = parts.length ? parts.join(rules.match === 'any' ? ' OR ' : ' AND ') : '1';
  let order = null;
  if (rules.sort && FIELDS[rules.sort.field] && rules.sort.field !== 'playlist') order = `t.${rules.sort.field} ${rules.sort.dir === 'desc' ? 'DESC' : 'ASC'}`;
  if (rules.sort && rules.sort.field === 'random') order = 'RANDOM()';
  const limit = Number(rules.limit) > 0 ? Math.floor(Number(rules.limit)) : null;
  return { where: `(${where})`, params, order, limit };
}

module.exports = { compile, FIELDS, OPS };
