'use strict';
// The library: SQLite (node:sqlite, built into Node/Electron) holding tracks, playlists and smartlists.
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const tags = require('./tags');
const cueLib = require('./cues');
const renamer = require('./rename');
const smart = require('./smartlist');
const keys = require('./keys');

const TRACK_COLS = ['path', 'title', 'artist', 'album', 'genre', 'comment', 'bpm', 'key', 'year', 'rating', 'label', 'remixer',
  'composer', 'grouping', 'mix', 'trackNumber', 'duration', 'bitrate', 'sampleRate', 'size', 'format', 'mtime', 'dateAdded', 'missing'];
const EDITABLE = ['title', 'artist', 'album', 'genre', 'comment', 'bpm', 'key', 'year', 'rating', 'label', 'remixer', 'composer', 'grouping', 'mix', 'trackNumber'];
// The fields "Write tags to file" saves into the music files.
const WRITE_TAG_FIELDS = ['artist', 'title', 'album', 'genre', 'year', 'comment'];
const SORTABLE = new Set([...TRACK_COLS, 'id', 'position', 'cues']);

const SCHEMA = `
CREATE TABLE IF NOT EXISTS tracks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  path TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL DEFAULT '', artist TEXT NOT NULL DEFAULT '', album TEXT NOT NULL DEFAULT '',
  genre TEXT NOT NULL DEFAULT '', comment TEXT NOT NULL DEFAULT '', bpm REAL NOT NULL DEFAULT 0,
  key TEXT NOT NULL DEFAULT '', year INTEGER NOT NULL DEFAULT 0, rating INTEGER NOT NULL DEFAULT 0,
  label TEXT NOT NULL DEFAULT '', remixer TEXT NOT NULL DEFAULT '', composer TEXT NOT NULL DEFAULT '',
  grouping TEXT NOT NULL DEFAULT '', mix TEXT NOT NULL DEFAULT '', trackNumber INTEGER NOT NULL DEFAULT 0,
  duration REAL NOT NULL DEFAULT 0, bitrate INTEGER NOT NULL DEFAULT 0, sampleRate INTEGER NOT NULL DEFAULT 0,
  size INTEGER NOT NULL DEFAULT 0, format TEXT NOT NULL DEFAULT '', mtime INTEGER NOT NULL DEFAULT 0,
  dateAdded TEXT NOT NULL, missing INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS tracks_artist ON tracks(artist COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS tracks_title ON tracks(title COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS tracks_genre ON tracks(genre COLLATE NOCASE);
CREATE VIRTUAL TABLE IF NOT EXISTS tracks_fts USING fts5(title, artist, album, remixer, label, genre, comment,
  content='tracks', content_rowid='id', tokenize='unicode61 remove_diacritics 2');
CREATE TRIGGER IF NOT EXISTS tracks_ai AFTER INSERT ON tracks BEGIN
  INSERT INTO tracks_fts(rowid, title, artist, album, remixer, label, genre, comment)
  VALUES (new.id, new.title, new.artist, new.album, new.remixer, new.label, new.genre, new.comment); END;
CREATE TRIGGER IF NOT EXISTS tracks_ad AFTER DELETE ON tracks BEGIN
  INSERT INTO tracks_fts(tracks_fts, rowid, title, artist, album, remixer, label, genre, comment)
  VALUES ('delete', old.id, old.title, old.artist, old.album, old.remixer, old.label, old.genre, old.comment); END;
CREATE TRIGGER IF NOT EXISTS tracks_au AFTER UPDATE ON tracks BEGIN
  INSERT INTO tracks_fts(tracks_fts, rowid, title, artist, album, remixer, label, genre, comment)
  VALUES ('delete', old.id, old.title, old.artist, old.album, old.remixer, old.label, old.genre, old.comment);
  INSERT INTO tracks_fts(rowid, title, artist, album, remixer, label, genre, comment)
  VALUES (new.id, new.title, new.artist, new.album, new.remixer, new.label, new.genre, new.comment); END;
CREATE TABLE IF NOT EXISTS playlists (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parentId INTEGER REFERENCES playlists(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('folder','playlist','smart')),
  position INTEGER NOT NULL DEFAULT 0,
  rules TEXT
);
CREATE TABLE IF NOT EXISTS playlist_tracks (
  playlistId INTEGER NOT NULL REFERENCES playlists(id) ON DELETE CASCADE,
  trackId INTEGER NOT NULL REFERENCES tracks(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  PRIMARY KEY (playlistId, trackId)
);
CREATE INDEX IF NOT EXISTS playlist_tracks_pos ON playlist_tracks(playlistId, position);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
-- Cue points (see cues.js). source: 'file' = read from the file's Serato tags, 'rekordbox' / 'engine' = imported.
CREATE TABLE IF NOT EXISTS cues (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trackId INTEGER NOT NULL REFERENCES tracks(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('hot','memory','loop')),
  num INTEGER, start REAL NOT NULL, "end" REAL, name TEXT NOT NULL DEFAULT '', color TEXT,
  source TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS cues_track ON cues(trackId);
-- Earlier paths of renamed files, so exports can find the track under its old name in other apps.
CREATE TABLE IF NOT EXISTS path_history (
  trackId INTEGER NOT NULL REFERENCES tracks(id) ON DELETE CASCADE,
  path TEXT NOT NULL, renamedAt TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS path_history_track ON path_history(trackId);
`;

const sameInode = (a, b) => { try { const x = fs.statSync(a), y = fs.statSync(b); return x.ino === y.ino && x.dev === y.dev; } catch { return false; } };

class Library {
  constructor(file) {
    this.file = file;
    if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
    this.db = new DatabaseSync(file);
    this.db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA synchronous = NORMAL;');
    // camelot(key) normalises any key notation for smartlist key rules.
    const keys = require('./keys');
    this.db.function('camelot', { deterministic: true }, (k) => keys.toCamelot(keys.parse(k)) || null);
    this.db.exec(SCHEMA);
    this.db.exec('PRAGMA user_version = 1');
  }
  close() { this.db.close(); }
  tx(fn) {
    this.db.exec('BEGIN');
    try { const r = fn(); this.db.exec('COMMIT'); return r; } catch (e) { this.db.exec('ROLLBACK'); throw e; }
  }

  // ---------- settings ----------
  getSetting(key, def = null) { const r = this.db.prepare('SELECT value FROM settings WHERE key = ?').get(key); return r ? JSON.parse(r.value) : def; }
  setSetting(key, value) { this.db.prepare('INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, JSON.stringify(value)); }

  // ---------- import ----------
  static *walk(dir) {
    let entries; try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (e.name.startsWith('.')) continue;
      const p = path.join(dir, e.name);
      if (e.isDirectory()) yield* Library.walk(p);
      else if (e.isFile() && tags.AUDIO_EXT.has(path.extname(e.name).toLowerCase())) yield p;
    }
  }
  /** Import (or refresh) audio files from folders or individual files. Yields to the event loop as it goes. */
  async importPaths(paths, onProgress = () => {}) {
    const files = [];
    for (const p of paths) {
      let st; try { st = fs.statSync(p); } catch { continue; }
      if (st.isDirectory()) for (const f of Library.walk(p)) files.push(f);
      else if (tags.AUDIO_EXT.has(path.extname(p).toLowerCase())) files.push(p);
    }
    const getByPath = this.db.prepare('SELECT id, mtime, size FROM tracks WHERE path = ?');
    const hasCues = this.db.prepare('SELECT 1 FROM cues WHERE trackId = ? LIMIT 1');
    const res = { added: 0, updated: 0, unchanged: 0, failed: [], total: files.length, ids: [] };
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      try {
        const st = fs.statSync(f); const existing = getByPath.get(f);
        if (existing && existing.mtime === Math.floor(st.mtimeMs) && existing.size === st.size) {
          res.unchanged++; res.ids.push(existing.id);
          // Unchanged file with no cue points yet (e.g. imported before Crate read cues): look for Serato cues.
          if (!hasCues.get(existing.id)) { try { const c = tags.readTags(f).cues; if (c && c.length) this.setCues(existing.id, c, 'file'); } catch { /* unreadable: leave it */ } }
        }
        else {
          const id = this.upsertFromFile(f, st); res.ids.push(id);
          existing ? res.updated++ : res.added++;
        }
      } catch (e) { res.failed.push({ path: f, error: e.message }); }
      if (i % 25 === 24) { onProgress({ done: i + 1, total: files.length }); await new Promise(r => setImmediate(r)); }
    }
    onProgress({ done: files.length, total: files.length });
    return res;
  }
  upsertFromFile(file, st = fs.statSync(file)) {
    const t = tags.readTags(file);
    const row = { title: '', artist: '', album: '', genre: '', comment: '', bpm: 0, key: '', year: 0, rating: 0, label: '', remixer: '',
      composer: '', grouping: '', mix: '', trackNumber: 0, ...t.fields };
    if (!row.title) row.title = path.basename(file, path.extname(file));
    Object.assign(row, { path: file, duration: t.duration, bitrate: t.bitrate, sampleRate: t.sampleRate, size: st.size, format: t.format,
      mtime: Math.floor(st.mtimeMs), missing: 0 });
    const cols = TRACK_COLS.filter(c => c !== 'dateAdded');
    const sql = `INSERT INTO tracks (${cols.join(',')}, dateAdded) VALUES (${cols.map(() => '?').join(',')}, ?)
      ON CONFLICT(path) DO UPDATE SET ${cols.filter(c => c !== 'path').map(c => `${c}=excluded.${c}`).join(',')}`;
    this.db.prepare(sql).run(...cols.map(c => row[c] ?? null), new Date().toISOString());
    const id = this.db.prepare('SELECT id FROM tracks WHERE path = ?').get(file).id;
    // Cue points from the file's Serato tags (also written by Mixed In Key). They never replace
    // cues imported from rekordbox or Engine DJ.
    const src = this.db.prepare('SELECT source FROM cues WHERE trackId = ? LIMIT 1').get(id);
    if (!src || src.source === 'file') this.setCues(id, t.cues || [], 'file');
    return id;
  }

  // ---------- cue points ----------
  getCues(trackId) {
    return this.db.prepare('SELECT kind, num, start, "end", name, color, source FROM cues WHERE trackId = ? ORDER BY id').all(trackId)
      .map(c => ({ kind: c.kind, num: c.num, start: c.start, end: c.end, name: c.name, color: c.color, source: c.source }));
  }
  /** Map of trackId -> cues, for exports. */
  cuesByTrack(ids) {
    const out = new Map(); const CH = 500;
    for (let i = 0; i < ids.length; i += CH) {
      const part = ids.slice(i, i + CH);
      for (const c of this.db.prepare(`SELECT trackId, kind, num, start, "end", name, color FROM cues WHERE trackId IN (${part.map(() => '?').join(',')}) ORDER BY id`).all(...part)) {
        if (!out.has(c.trackId)) out.set(c.trackId, []);
        out.get(c.trackId).push({ kind: c.kind, num: c.num, start: c.start, end: c.end, name: c.name, color: c.color });
      }
    }
    return out;
  }
  /** Replaces a track's cue points. */
  setCues(trackId, list, source = '') {
    const clean = cueLib.normalize(list);
    this.db.prepare('DELETE FROM cues WHERE trackId = ?').run(trackId);
    const ins = this.db.prepare('INSERT INTO cues (trackId, kind, num, start, "end", name, color, source) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    for (const c of clean) ins.run(trackId, c.kind, c.num, c.start, c.end, c.name, c.color, source);
    return clean.length;
  }
  /** Flag tracks whose files have disappeared. */
  checkMissing() {
    const rows = this.db.prepare('SELECT id, path, missing FROM tracks').all(); let missing = 0;
    const upd = this.db.prepare('UPDATE tracks SET missing = ? WHERE id = ?');
    this.tx(() => { for (const r of rows) { const m = fs.existsSync(r.path) ? 0 : 1; missing += m; if (m !== r.missing) upd.run(m, r.id); } });
    return { checked: rows.length, missing };
  }
  /** Point a track at a new file location (e.g. after files were moved) and re-read its stream info. */
  relocate(id, newPath) {
    const st = fs.statSync(newPath); const t = tags.readTags(newPath);
    this.db.prepare('UPDATE tracks SET path=?, size=?, mtime=?, duration=?, bitrate=?, sampleRate=?, format=?, missing=0 WHERE id=?')
      .run(newPath, st.size, Math.floor(st.mtimeMs), t.duration, t.bitrate, t.sampleRate, t.format, id);
  }

  // ---------- renaming files ----------
  /** Preview of renaming files to "Artist - Title" (nothing changes on disk). */
  previewRenames(ids) { return renamer.plan(this.getTracks(ids)); }
  /**
   * Renames files to "Artist - Title". Returns { renamed: [{ id, from, to }], skipped, errors }.
   * Each rename is applied on disk first, then in the library, so a failure leaves both matching.
   */
  renameFiles(ids) {
    const res = { renamed: [], skipped: 0, errors: [] };
    const upd = this.db.prepare('UPDATE tracks SET path = ?, mtime = ? WHERE id = ?');
    const hist = this.db.prepare('INSERT INTO path_history (trackId, path, renamedAt) VALUES (?, ?, ?)');
    for (const p of this.previewRenames(ids)) {
      if (p.status !== 'rename') { res.skipped++; continue; }
      try {
        if (fs.existsSync(p.to) && !fs.existsSync(p.from)) throw new Error('file not found');
        fs.renameSync(p.from, p.to);
        try { upd.run(p.to, Math.floor(fs.statSync(p.to).mtimeMs), p.id); hist.run(p.id, p.from, new Date().toISOString()); }
        catch (e) { fs.renameSync(p.to, p.from); throw e; } // keep the library and the disk in step
        res.renamed.push({ id: p.id, from: p.from, to: p.to });
      } catch (e) { res.errors.push({ path: p.from, error: e.message }); }
    }
    return res;
  }
  /** Puts renamed files back (the list returned by renameFiles). */
  undoRenames(list) {
    const res = { restored: 0, errors: [] };
    const upd = this.db.prepare('UPDATE tracks SET path = ? WHERE id = ? AND path = ?');
    for (const r of list || []) {
      try {
        if (fs.existsSync(r.from) && !sameInode(r.from, r.to)) throw new Error('a file with the old name exists again');
        fs.renameSync(r.to, r.from); upd.run(r.from, r.id, r.to);
        this.db.prepare('DELETE FROM path_history WHERE trackId = ? AND path = ?').run(r.id, r.from); res.restored++;
      } catch (e) { res.errors.push({ path: r.to, error: e.message }); }
    }
    return res;
  }
  /** Map of trackId -> earlier paths, newest first. */
  previousPaths(ids) {
    const out = new Map(); const CH = 500;
    for (let i = 0; i < ids.length; i += CH) {
      const part = ids.slice(i, i + CH);
      for (const r of this.db.prepare(`SELECT trackId, path FROM path_history WHERE trackId IN (${part.map(() => '?').join(',')}) ORDER BY renamedAt DESC`).all(...part)) {
        if (!out.has(r.trackId)) out.set(r.trackId, []); out.get(r.trackId).push(r.path);
      }
    }
    return out;
  }

  // ---------- import from another DJ app ----------
  /**
   * Merge a library read from rekordbox / Engine DJ ({ tracks, tree } from src/core/import/*).
   * - Tracks match on file path. Files that exist are read like a normal import; files that don't are
   *   added as "missing" with the DJ app's details, so you can relink them later.
   * - mode 'fill' only fills fields that are empty in Crate; 'overwrite' takes the DJ app's values.
   * - pathMap: [{ from, to }] prefix replacements, for libraries made on another computer or drive.
   * - Playlists are recreated inside one top-level folder (rootName), replaced on each import.
   */
  async importExternal(src, { mode = 'fill', writeFiles = false, pathMap = [], rootName = null, replace = [], onProgress = () => {} } = {}) {
    const mapPath = (p) => {
      let out = String(p).replace(/\\/g, '/');
      for (const m of pathMap) {
        const from = String(m.from || '').replace(/\\/g, '/'); if (!from) continue;
        if (out.toLowerCase().startsWith(from.toLowerCase())) { out = String(m.to || '').replace(/\\/g, '/').replace(/\/$/, '') + '/' + out.slice(from.length).replace(/^\//, ''); break; }
      }
      return out;
    };
    const res = { added: 0, updated: 0, missing: 0, unchanged: 0, failed: [], playlists: 0, smartlists: 0, cueTracks: 0, total: src.tracks.length };
    const cueSource = this.db.prepare('SELECT source FROM cues WHERE trackId = ? LIMIT 1');
    const idMap = new Map(); const getByPath = this.db.prepare('SELECT * FROM tracks WHERE path = ?');
    const NUM = new Set(['bpm', 'year', 'rating', 'trackNumber']);
    for (let i = 0; i < src.tracks.length; i++) {
      const t = src.tracks[i]; const file = mapPath(t.path);
      try {
        let row = getByPath.get(file); const isNew = !row;
        if (fs.existsSync(file)) {
          if (!row) { this.upsertFromFile(file); row = getByPath.get(file); }
        } else if (!row) {
          const ext = path.extname(file).toLowerCase().slice(1);
          this.db.prepare(`INSERT INTO tracks (path, title, format, duration, bitrate, sampleRate, size, dateAdded, missing) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`)
            .run(file, t.fields.title || path.basename(file), ({ m4a: 'mp4', aif: 'aiff' })[ext] || ext, t.duration || 0, t.bitrate || 0, t.sampleRate || 0, t.size || 0, t.dateAdded || new Date().toISOString());
          row = getByPath.get(file); res.missing++;
        }
        const changes = {};
        for (const [k, v] of Object.entries(t.fields)) {
          if (!EDITABLE.includes(k)) continue;
          const empty = NUM.has(k) ? !(Number(v) > 0) : !String(v ?? '').trim();
          if (empty) continue;
          const cur = row[k];
          // a title that's only the file name (no title tag) counts as empty
          const curEmpty = NUM.has(k) ? !(Number(cur) > 0) : (!String(cur ?? '').trim() || (k === 'title' && cur === path.basename(file, path.extname(file))));
          let same = NUM.has(k) ? Math.abs(Number(cur) - Number(v)) < 0.005 : String(cur) === String(v);
          if (k === 'key' && !same) { const a = keys.parse(cur), b = keys.parse(v); same = !!(a && b && a.num === b.num && a.letter === b.letter); } // same key, other notation
          if (!same && (mode === 'overwrite' || curEmpty || (isNew && row.missing))) changes[k] = v;
        }
        if (isNew && t.dateAdded) this.db.prepare('UPDATE tracks SET dateAdded = ? WHERE id = ?').run(t.dateAdded, row.id);
        if (Object.keys(changes).length) this.updateTracks([row.id], changes, { writeFiles: writeFiles && !row.missing });
        // Cue points: by default only for tracks without cues of their own (cues read from the file's
        // Serato tags count as none); "take the DJ app's" replaces them.
        if (t.cues && t.cues.length) {
          const have = cueSource.get(row.id);
          if (mode === 'overwrite' || !have || have.source === 'file') { this.setCues(row.id, t.cues, src.source || 'import'); res.cueTracks++; }
        }
        if (isNew && !row.missing) res.added++; else if (!isNew) Object.keys(changes).length ? res.updated++ : res.unchanged++;
        idMap.set(t.sourceId, row.id);
      } catch (e) { res.failed.push({ path: file, error: e.message }); }
      if (i % 25 === 24) { onProgress({ done: i + 1, total: src.tracks.length }); await new Promise(r => setImmediate(r)); }
    }
    onProgress({ done: src.tracks.length, total: src.tracks.length });
    // Playlists go straight to Crate's top level. The playlists the previous import from this app
    // made (`replace`: [{ id, name }]) are replaced; playlists you made in Crate stay untouched.
    // A "From rekordbox" / "From Engine DJ" folder from Crate 1.7 and earlier is cleared out too.
    this.tx(() => {
      const get = this.db.prepare('SELECT id, name FROM playlists WHERE id = ?');
      for (const o of replace || []) { const row = get.get(o.id); if (row && row.name === o.name) this.deletePlaylist(row.id); }
      if (rootName) for (const old of this.db.prepare("SELECT id FROM playlists WHERE parentId IS NULL AND type = 'folder' AND name = ?").all(rootName)) this.deletePlaylist(old.id);
    });
    res.created = []; res.rootId = null;
    const rootId = null;
    const make = (nodes, parentId) => {
      for (const n of nodes) {
        const name = String(n.name || '').trim() || 'Untitled';
        // At the top level, a playlist with the same name and type already in Crate is replaced by the
        // imported one, so a round trip (Crate -> DJ app -> Crate) never shows the same playlist twice.
        if (!parentId) for (const dup of this.db.prepare('SELECT id FROM playlists WHERE parentId IS NULL AND name = ? AND type = ?').all(name, n.type === 'folder' ? 'folder' : n.type === 'smart' ? 'smart' : 'playlist'))
          if (!res.created.some(c => c.id === dup.id)) { this.deletePlaylist(dup.id); res.replacedByName = (res.replacedByName || 0) + 1; }
        const top = (id) => { if (!parentId) res.created.push({ id, name }); return id; };
        if (n.type === 'folder') { make(n.children || [], top(this.createPlaylist({ name, type: 'folder', parentId }))); continue; }
        if (n.type === 'smart') { top(this.createPlaylist({ name, type: 'smart', parentId, rules: n.rules })); res.smartlists++; continue; }
        const id = top(this.createPlaylist({ name, type: 'playlist', parentId })); res.playlists++;
        this.addToPlaylist(id, (n.sourceIds || []).map(s => idMap.get(s)).filter(Boolean));
      }
    };
    make(src.tree || [], rootId);
    return res;
  }

  // ---------- tracks ----------
  getTracks(ids) {
    if (!ids.length) return [];
    const out = []; const CH = 500;
    for (let i = 0; i < ids.length; i += CH) {
      const part = ids.slice(i, i + CH);
      out.push(...this.db.prepare(`SELECT t.*, (SELECT COUNT(*) FROM cues c WHERE c.trackId = t.id) AS cues FROM tracks t WHERE t.id IN (${part.map(() => '?').join(',')})`).all(...part));
    }
    const byId = new Map(out.map(t => [t.id, t])); return ids.map(id => byId.get(id)).filter(Boolean);
  }
  /**
   * List tracks for a view. view: { playlistId?, search?, sort?, dir? }.
   * Search uses full-text matching on words (prefix matching), e.g. "dead strob".
   */
  listTracks(view = {}) {
    const where = [], params = [];
    let from = 'tracks t', order = 't.artist COLLATE NOCASE, t.title COLLATE NOCASE', limit = '';
    let pl = null;
    if (view.rules) { // ad-hoc smartlist (used for live previews in the editor)
      const q = smart.compile(view.rules); where.push(q.where); params.push(...q.params);
      if (q.order) order = q.order; if (q.limit) limit = ` LIMIT ${q.limit}`;
    } else if (view.playlistId) {
      pl = this.db.prepare('SELECT * FROM playlists WHERE id = ?').get(view.playlistId);
      if (!pl) return [];
      if (pl.type === 'playlist') { from = 'playlist_tracks pt JOIN tracks t ON t.id = pt.trackId'; where.push('pt.playlistId = ?'); params.push(pl.id); order = 'pt.position'; }
      else if (pl.type === 'smart') {
        const q = smart.compile(JSON.parse(pl.rules || '{}'));
        where.push(q.where); params.push(...q.params);
        if (q.order) order = q.order; if (q.limit) limit = ` LIMIT ${q.limit}`;
      } else if (pl.type === 'folder') { // a folder shows everything inside it
        const ids = this.folderTrackIds(pl.id); return this.getTracks(ids);
      }
    }
    if (view.search && view.search.trim()) {
      const terms = view.search.trim().split(/\s+/).map(w => w.replace(/["*^():]/g, '')).filter(Boolean).map(w => `"${w}"*`);
      if (terms.length) { where.push('t.id IN (SELECT rowid FROM tracks_fts WHERE tracks_fts MATCH ?)'); params.push(terms.join(' ')); }
    }
    if (view.sort && SORTABLE.has(view.sort) && !(view.sort === 'position' && !(pl && pl.type === 'playlist'))) {
      const dir = view.dir === 'desc' ? 'DESC' : 'ASC';
      const col = view.sort === 'position' ? 'pt.position' : view.sort === 'cues' ? 'cues' : `t.${view.sort}`;
      order = `${col}${['title', 'artist', 'album', 'genre', 'label', 'key', 'comment'].includes(view.sort) ? ' COLLATE NOCASE' : ''} ${dir}, t.id`;
    }
    const sql = `SELECT t.*, (SELECT COUNT(*) FROM cues c WHERE c.trackId = t.id) AS cues${pl && pl.type === 'playlist' ? ', pt.position AS position' : ''} FROM ${from}${where.length ? ' WHERE ' + where.join(' AND ') : ''} ORDER BY ${order}${limit}`;
    return this.db.prepare(sql).all(...params);
  }
  countTracks() { return this.db.prepare('SELECT COUNT(*) n FROM tracks').get().n; }

  /**
   * Edit tracks. `changes` is { field: value } applied to every id (only editable fields).
   * With writeFiles (default) the new values are also written into each file's tags.
   */
  updateTracks(ids, changes, { writeFiles = true } = {}) {
    const fields = {}; for (const k of EDITABLE) if (k in changes) fields[k] = changes[k];
    const keys = Object.keys(fields); if (!keys.length) return { updated: 0, fileErrors: [] };
    const num = new Set(['bpm', 'year', 'rating', 'trackNumber']);
    for (const k of keys) fields[k] = num.has(k) ? (Number(fields[k]) || 0) : String(fields[k] ?? '');
    if ('rating' in fields) fields.rating = Math.max(0, Math.min(5, Math.round(fields.rating)));
    const fileErrors = [];
    const tracks = this.getTracks(ids);
    const upd = this.db.prepare(`UPDATE tracks SET ${keys.map(k => `${k} = ?`).join(', ')}, mtime = ?, size = ? WHERE id = ?`);
    for (const t of tracks) {
      let mtime = t.mtime, size = t.size;
      if (writeFiles) {
        try { tags.writeTags(t.path, fields); const st = fs.statSync(t.path); mtime = Math.floor(st.mtimeMs); size = st.size; }
        catch (e) { fileErrors.push({ id: t.id, path: t.path, error: e.message }); }
      }
      upd.run(...keys.map(k => fields[k]), mtime, size, t.id);
    }
    return { updated: tracks.length, fileErrors };
  }
  /**
   * Writes Crate's artist, title, album, genre, year and comment into the music files (only these;
   * every other tag in the file is left as it is), e.g. after importing from a DJ app without saving
   * to the files. Missing files are skipped. Returns { written, skipped, errors }.
   */
  async writeTagsToFiles(ids, onProgress = () => {}) {
    const res = { written: 0, skipped: 0, errors: [] };
    const upd = this.db.prepare('UPDATE tracks SET mtime = ?, size = ? WHERE id = ?');
    const tracks = this.getTracks(ids);
    for (let i = 0; i < tracks.length; i++) {
      const t = tracks[i];
      if (t.missing || !fs.existsSync(t.path)) { res.skipped++; continue; }
      const fields = {}; for (const k of WRITE_TAG_FIELDS) fields[k] = t[k];
      try { tags.writeTags(t.path, fields); const st = fs.statSync(t.path); upd.run(Math.floor(st.mtimeMs), st.size, t.id); res.written++; }
      catch (e) { res.errors.push({ id: t.id, path: t.path, error: e.message }); }
      if (i % 10 === 9) { onProgress({ done: i + 1, total: tracks.length }); await new Promise(r => setImmediate(r)); }
    }
    onProgress({ done: tracks.length, total: tracks.length });
    return res;
  }
  /** Per-track edits: [{id, changes}] (used by clean-up previews). */
  applyEdits(edits, opts) {
    const fileErrors = []; let updated = 0;
    for (const e of edits) { const r = this.updateTracks([e.id], e.changes, opts); updated += r.updated; fileErrors.push(...r.fileErrors); }
    return { updated, fileErrors };
  }
  /** Remove tracks from the library (files on disk are not touched). */
  removeTracks(ids) { this.tx(() => { const d = this.db.prepare('DELETE FROM tracks WHERE id = ?'); for (const id of ids) d.run(id); }); }

  // ---------- playlists ----------
  listPlaylists() {
    const rows = this.db.prepare('SELECT p.*, (SELECT COUNT(*) FROM playlist_tracks pt WHERE pt.playlistId = p.id) AS count FROM playlists p ORDER BY parentId, position, id').all();
    for (const r of rows) { r.rules = r.rules ? JSON.parse(r.rules) : null; if (r.type !== 'playlist') r.count = null; }
    return rows;
  }
  createPlaylist({ name, type = 'playlist', parentId = null, rules = null }) {
    if (!name || !String(name).trim()) throw new Error('Name required');
    if (parentId) { const p = this.db.prepare('SELECT type FROM playlists WHERE id = ?').get(parentId); if (!p || p.type !== 'folder') throw new Error('Parent must be a folder'); }
    if (type === 'smart') smart.compile(rules || {}); // validate
    const pos = this.db.prepare('SELECT COALESCE(MAX(position), -1) + 1 AS p FROM playlists WHERE parentId IS ?').get(parentId).p;
    const r = this.db.prepare('INSERT INTO playlists(parentId, name, type, position, rules) VALUES (?, ?, ?, ?, ?)')
      .run(parentId, String(name).trim(), type, pos, type === 'smart' ? JSON.stringify(rules || {}) : null);
    return Number(r.lastInsertRowid);
  }
  updatePlaylist(id, { name, rules }) {
    if (name !== undefined) this.db.prepare('UPDATE playlists SET name = ? WHERE id = ?').run(String(name).trim(), id);
    if (rules !== undefined) { smart.compile(rules); this.db.prepare("UPDATE playlists SET rules = ? WHERE id = ? AND type = 'smart'").run(JSON.stringify(rules), id); }
  }
  deletePlaylist(id) { this.db.prepare('DELETE FROM playlists WHERE id = ?').run(id); }
  /** Move a playlist/folder under another folder (or root) at a given index. */
  movePlaylist(id, parentId, index) {
    if (parentId) {
      const p = this.db.prepare('SELECT type FROM playlists WHERE id = ?').get(parentId);
      if (!p || p.type !== 'folder') throw new Error('Target must be a folder');
      for (let cur = parentId; cur; cur = this.db.prepare('SELECT parentId FROM playlists WHERE id = ?').get(cur)?.parentId) if (cur === id) throw new Error('Cannot move a folder into itself');
    }
    this.tx(() => {
      const sibs = this.db.prepare('SELECT id FROM playlists WHERE parentId IS ? AND id != ? ORDER BY position, id').all(parentId, id).map(r => r.id);
      sibs.splice(Math.max(0, Math.min(index ?? sibs.length, sibs.length)), 0, id);
      this.db.prepare('UPDATE playlists SET parentId = ? WHERE id = ?').run(parentId, id);
      const up = this.db.prepare('UPDATE playlists SET position = ? WHERE id = ?'); sibs.forEach((s, i) => up.run(i, s));
    });
  }
  /** Add tracks to a playlist (skips ones already in it). Returns how many were added. */
  addToPlaylist(playlistId, trackIds) {
    const p = this.db.prepare('SELECT type FROM playlists WHERE id = ?').get(playlistId);
    if (!p || p.type !== 'playlist') throw new Error('Tracks can only be added to normal playlists');
    return this.tx(() => {
      let pos = this.db.prepare('SELECT COALESCE(MAX(position), -1) + 1 AS p FROM playlist_tracks WHERE playlistId = ?').get(playlistId).p;
      const ins = this.db.prepare('INSERT OR IGNORE INTO playlist_tracks(playlistId, trackId, position) VALUES (?, ?, ?)');
      let added = 0; for (const t of trackIds) { const r = ins.run(playlistId, t, pos); if (r.changes) { added++; pos++; } }
      return added;
    });
  }
  removeFromPlaylist(playlistId, trackIds) {
    this.tx(() => { const d = this.db.prepare('DELETE FROM playlist_tracks WHERE playlistId = ? AND trackId = ?'); for (const t of trackIds) d.run(playlistId, t); });
    this.renumber(playlistId);
  }
  /** Set a playlist's full order. */
  reorderPlaylist(playlistId, trackIds) {
    this.tx(() => { const u = this.db.prepare('UPDATE playlist_tracks SET position = ? WHERE playlistId = ? AND trackId = ?'); trackIds.forEach((t, i) => u.run(i, playlistId, t)); });
    this.renumber(playlistId);
  }
  renumber(playlistId) {
    const ids = this.db.prepare('SELECT trackId FROM playlist_tracks WHERE playlistId = ? ORDER BY position').all(playlistId).map(r => r.trackId);
    this.tx(() => { const u = this.db.prepare('UPDATE playlist_tracks SET position = ? WHERE playlistId = ? AND trackId = ?'); ids.forEach((t, i) => u.run(i, playlistId, t)); });
  }
  playlistTrackIds(id) {
    const p = this.db.prepare('SELECT type FROM playlists WHERE id = ?').get(id); if (!p) return [];
    if (p.type === 'folder') return this.folderTrackIds(id);
    return this.listTracks({ playlistId: id }).map(t => t.id);
  }
  folderTrackIds(folderId) {
    const seen = new Set(), out = [];
    for (const c of this.db.prepare('SELECT id FROM playlists WHERE parentId = ? ORDER BY position, id').all(folderId))
      for (const t of this.playlistTrackIds(c.id)) if (!seen.has(t)) { seen.add(t); out.push(t); }
    return out;
  }
  /** Playlist tree as nested nodes: { id, name, type, children?, trackIds? } (smartlists resolved). */
  playlistTree({ withTracks = false } = {}) {
    const rows = this.listPlaylists(); const byParent = new Map();
    for (const r of rows) { const k = r.parentId ?? 0; if (!byParent.has(k)) byParent.set(k, []); byParent.get(k).push(r); }
    const build = (pid) => (byParent.get(pid) || []).map(r => {
      const n = { id: r.id, name: r.name, type: r.type };
      if (r.type === 'folder') n.children = build(r.id); else if (withTracks) n.trackIds = this.playlistTrackIds(r.id);
      if (r.type === 'smart') n.rules = r.rules;
      return n;
    });
    return build(0);
  }

  // ---------- facets ----------
  distinct(field) {
    if (!['genre', 'artist', 'label', 'key', 'album', 'remixer', 'grouping', 'composer'].includes(field)) throw new Error('Bad field');
    // Each exact spelling is its own row, so case variants can be spotted and merged.
    return this.db.prepare(`SELECT ${field} AS value, COUNT(*) AS count FROM tracks WHERE ${field} != '' GROUP BY ${field} ORDER BY ${field} COLLATE NOCASE, ${field}`).all();
  }
}

module.exports = { Library, EDITABLE, TRACK_COLS };
