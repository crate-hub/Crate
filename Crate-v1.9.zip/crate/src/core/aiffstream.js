'use strict';
// Plays AIFF files in the app's player. Chromium (and so Electron) has no AIFF decoder, but AIFF
// is plain PCM audio, so the player is served a WAV made on the fly: a 44-byte WAV header followed
// by the AIFF's samples with their byte order swapped. Nothing is written to disk and the file
// itself is never changed. The WAV is exactly as long as header + samples, so seeking (HTTP range
// requests) maps 1:1 onto the AIFF's sound data.
const fs = require('fs');
const { Readable } = require('stream');

function ext80(b) { // IEEE 754 80-bit extended -> number (AIFF sample rate)
  const exp = ((b[0] & 0x7f) << 8) | b[1];
  const hi = b.readUInt32BE(2), lo = b.readUInt32BE(6);
  if (!exp && !hi && !lo) return 0;
  return (hi * 2 ** 32 + lo) * 2 ** (exp - 16383 - 63);
}

/** Reads an AIFF/AIFF-C file's layout. Returns null when it isn't one we can serve as WAV. */
function probe(file) {
  const fd = fs.openSync(file, 'r');
  try {
    const size = fs.fstatSync(fd).size;
    const read = (pos, len) => { const b = Buffer.alloc(len); const n = fs.readSync(fd, b, 0, len, pos); return b.subarray(0, n); };
    const head = read(0, 12);
    if (head.length < 12 || head.toString('latin1', 0, 4) !== 'FORM') return null;
    const form = head.toString('latin1', 8, 12); if (form !== 'AIFF' && form !== 'AIFC') return null;
    let pos = 12, comm = null, ssnd = null;
    while (pos + 8 <= size && !(comm && ssnd)) {
      const h = read(pos, 8); const id = h.toString('latin1', 0, 4); const len = h.readUInt32BE(4);
      if (id === 'COMM') {
        const c = read(pos + 8, Math.min(len, 64));
        comm = { channels: c.readInt16BE(0), frames: c.readUInt32BE(2), bits: c.readInt16BE(6), rate: Math.round(ext80(c.subarray(8, 18))),
          compression: form === 'AIFC' && c.length >= 22 ? c.toString('latin1', 18, 22) : 'NONE' };
      } else if (id === 'SSND') {
        const s = read(pos + 8, 8); const offset = s.readUInt32BE(0);
        ssnd = { start: pos + 16 + offset, length: Math.max(0, Math.min(len - 8 - offset, size - (pos + 16 + offset))) };
      }
      pos += 8 + len + (len & 1);
    }
    if (!comm || !ssnd || comm.channels < 1 || !comm.rate) return null;
    const comp = comm.compression;
    let format, swap, bytes;
    if (comp === 'NONE' || comp === 'twos') { format = 1; swap = true; }
    else if (comp === 'sowt') { format = 1; swap = false; }
    else if (comp === 'fl32' || comp === 'FL32') { format = 3; swap = true; comm.bits = 32; }
    else if (comp === 'fl64' || comp === 'FL64') { format = 3; swap = true; comm.bits = 64; }
    else return null; // compressed AIFF-C (ima4, ulaw, …): not supported
    bytes = Math.ceil(comm.bits / 8);
    if (![1, 2, 3, 4, 8].includes(bytes) || (format === 1 && bytes === 8)) return null;
    const frame = bytes * comm.channels;
    const dataLen = Math.min(ssnd.length, comm.frames * frame) - (Math.min(ssnd.length, comm.frames * frame) % frame);
    return { channels: comm.channels, rate: comm.rate, bits: bytes * 8, bytes, format, swap, signed8: bytes === 1, dataStart: ssnd.start, dataLen, size: 44 + dataLen };
  } finally { fs.closeSync(fd); }
}

function wavHeader(p) {
  const h = Buffer.alloc(44);
  h.write('RIFF', 0, 'latin1'); h.writeUInt32LE(36 + p.dataLen, 4); h.write('WAVE', 8, 'latin1');
  h.write('fmt ', 12, 'latin1'); h.writeUInt32LE(16, 16); h.writeUInt16LE(p.format, 20); h.writeUInt16LE(p.channels, 22);
  h.writeUInt32LE(p.rate, 24); h.writeUInt32LE(p.rate * p.bytes * p.channels, 28); h.writeUInt16LE(p.bytes * p.channels, 32); h.writeUInt16LE(p.bits, 34);
  h.write('data', 36, 'latin1'); h.writeUInt32LE(p.dataLen, 40);
  return h;
}

// Converts a whole number of samples in place: big-endian -> little-endian, and signed -> unsigned for 8-bit.
function convert(buf, p) {
  if (p.signed8) { for (let i = 0; i < buf.length; i++) buf[i] ^= 0x80; return buf; }
  if (!p.swap) return buf;
  const n = p.bytes;
  if (n === 2) return buf.swap16();
  if (n === 4) return buf.swap32();
  if (n === 8) return buf.swap64();
  for (let i = 0; i + 2 < buf.length; i += 3) { const t = buf[i]; buf[i] = buf[i + 2]; buf[i + 2] = t; } // 24-bit
  return buf;
}

/**
 * Bytes [start, end] (inclusive) of the WAV version of an AIFF, as a Node stream.
 * Reads are aligned to whole samples so every sample is converted correctly, then trimmed.
 */
function wavStream(file, p, start = 0, end = p.size - 1) {
  const header = wavHeader(p);
  const fromData = Math.max(0, start - 44), toData = end - 44; // inclusive offsets into the sound data
  const alignedFrom = fromData - (fromData % p.bytes);
  const CHUNK = 64 * 1024 - ((64 * 1024) % (p.bytes || 1));
  async function* gen() {
    if (start < 44) yield header.subarray(start, Math.min(44, end + 1));
    if (toData < 0) return;
    const fd = await fs.promises.open(file, 'r');
    try {
      let pos = alignedFrom; let skip = fromData - alignedFrom;
      while (pos <= toData) {
        const want = Math.min(CHUNK, toData - pos + 1 + ((p.bytes - ((toData - pos + 1) % p.bytes)) % p.bytes));
        const buf = Buffer.alloc(want);
        const { bytesRead } = await fd.read(buf, 0, want, p.dataStart + pos);
        if (!bytesRead) break;
        const whole = bytesRead - (bytesRead % p.bytes);
        let out = convert(buf.subarray(0, whole || bytesRead), p);
        const keep = Math.min(out.length, toData - pos + 1);
        out = out.subarray(skip, keep); skip = 0;
        if (out.length) yield out;
        pos += whole || bytesRead;
      }
    } finally { await fd.close(); }
  }
  return Readable.from(gen(), { objectMode: false });
}

module.exports = { probe, wavHeader, wavStream };
