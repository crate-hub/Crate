(function () {
'use strict';
// Musical key parsing and conversion between Camelot, Open Key and classic notation.
// Internal canonical form: Camelot number (1-12) + letter ('A' minor, 'B' major).

const MAJOR = ['B', 'F#', 'C#', 'G#', 'D#', 'A#', 'F', 'C', 'G', 'D', 'A', 'E']; // Camelot 1B..12B
const MINOR = ['G#', 'D#', 'A#', 'F', 'C', 'G', 'D', 'A', 'E', 'B', 'F#', 'C#']; // Camelot 1A..12A
const ENHARMONIC = { DB: 'C#', EB: 'D#', GB: 'F#', AB: 'G#', BB: 'A#', 'E#': 'F', 'B#': 'C', FB: 'E', CB: 'B' };
const PRETTY_FLAT = { 'C#': 'Db', 'D#': 'Eb', 'G#': 'Ab', 'A#': 'Bb' }; // conventional spellings for display

/** Parse anything common in DJ tags. Returns { num, letter } or null. */
function parse(input) {
  if (input === undefined || input === null) return null;
  let s = String(input).trim(); if (!s) return null;
  let m = s.match(/^0?(\d{1,2})\s*([ABab])$/); // Camelot
  if (m) { const n = +m[1]; return n >= 1 && n <= 12 ? { num: n, letter: m[2].toUpperCase() } : null; }
  m = s.match(/^0?(\d{1,2})\s*([dmDM])$/); // Open Key: 1d = 8B (C major), 1m = 8A (A minor)
  if (m) { const n = +m[1]; if (n < 1 || n > 12) return null; return { num: ((n + 6) % 12) + 1, letter: m[2].toLowerCase() === 'd' ? 'B' : 'A' }; }
  m = s.replace(/♯/g, '#').replace(/♭/g, 'b').match(/^([A-Ga-g])\s*([#b]?)\s*(m|min|minor|maj|major|M)?$/);
  if (m) {
    let note = m[1].toUpperCase() + (m[2] === '#' ? '#' : m[2] === 'b' ? 'B' : '');
    note = ENHARMONIC[note] || note;
    const minor = m[3] && /^(m|min|minor)$/.test(m[3]);
    const list = minor ? MINOR : MAJOR; const i = list.indexOf(note);
    return i < 0 ? null : { num: i + 1, letter: minor ? 'A' : 'B' };
  }
  return null;
}

function toCamelot(k) { return k ? `${k.num}${k.letter}` : ''; }
function toOpenKey(k) { return k ? `${((k.num + 4) % 12) + 1}${k.letter === 'B' ? 'd' : 'm'}` : ''; }
function toMusical(k) {
  if (!k) return '';
  const note = (k.letter === 'B' ? MAJOR : MINOR)[k.num - 1];
  return (PRETTY_FLAT[note] || note) + (k.letter === 'A' ? 'm' : '');
}
/** Format a raw key string in the chosen notation ('camelot' | 'openkey' | 'musical'); unknown input is returned as-is. */
function format(raw, notation = 'camelot') {
  const k = parse(raw); if (!k) return raw ? String(raw) : '';
  return notation === 'openkey' ? toOpenKey(k) : notation === 'musical' ? toMusical(k) : toCamelot(k);
}
/** Harmonically compatible keys (same, +/-1, relative major/minor) as Camelot strings. */
function compatible(raw) {
  const k = parse(raw); if (!k) return [];
  const up = (k.num % 12) + 1, down = ((k.num + 10) % 12) + 1, other = k.letter === 'A' ? 'B' : 'A';
  return [`${k.num}${k.letter}`, `${up}${k.letter}`, `${down}${k.letter}`, `${k.num}${other}`];
}
/** Engine DJ stores keys as 0-23: index = 2*(openKeyNumber-1) + (minor ? 1 : 0). */
function toEngine(raw) {
  const k = parse(raw); if (!k) return null;
  const ok = ((k.num + 4) % 12) + 1; return 2 * (ok - 1) + (k.letter === 'A' ? 1 : 0);
}

const api = { parse, format, compatible, toCamelot, toOpenKey, toMusical, toEngine };
// Shared with the window (loaded as a plain script there).
if (typeof module !== 'undefined' && module.exports) module.exports = api; else globalThis.CrateKeys = api;
})();
