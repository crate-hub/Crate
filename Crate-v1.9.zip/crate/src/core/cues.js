'use strict';
// Cue points: Crate's model, plus conversion to and from rekordbox, Engine DJ and Serato tag data.
//
// A cue in Crate is { kind, num, start, end, name, color }:
//   kind   'hot'    hot cue (num 0-7 = A-H); with `end` it is a hot loop
//          'memory' memory cue (no num); with `end` it is a memory loop
//          'loop'   saved loop in a numbered bank (num 0-7), like Engine DJ's and Serato's loop pads
//   start  seconds from the start of the track; end: seconds or null
//   name   label ('' if none); color: '#rrggbb' or null
const zlib = require('zlib');

const KINDS = new Set(['hot', 'memory', 'loop']);
const hex = (r, g, b) => '#' + [r, g, b].map(v => (v & 255).toString(16).padStart(2, '0')).join('');
const rgb = (c) => { const m = /^#?([0-9a-f]{6})$/i.exec(c || ''); if (!m) return null; const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };

/** Cleans a list of cues: valid kinds, finite times, at most one cue per hot/loop pad, sorted. */
function normalize(list) {
  const out = []; const taken = new Set();
  for (const c of list || []) {
    if (!c || !KINDS.has(c.kind)) continue;
    const start = Number(c.start); if (!Number.isFinite(start) || start < 0) continue;
    let end = c.end == null ? null : Number(c.end); if (!Number.isFinite(end) || end <= start) end = null;
    let num = c.kind === 'memory' ? null : Math.trunc(Number(c.num));
    if (c.kind !== 'memory') { if (!(num >= 0 && num < 8) || taken.has(c.kind + num)) continue; taken.add(c.kind + num); }
    if (c.kind === 'loop' && end == null) continue;
    out.push({ kind: c.kind, num, start: Math.round(start * 1e6) / 1e6, end: end == null ? null : Math.round(end * 1e6) / 1e6,
      name: String(c.name || '').slice(0, 200), color: rgb(c.color) ? String(c.color).toLowerCase().replace(/^#?/, '#') : null });
  }
  const order = { hot: 0, loop: 1, memory: 2 };
  return out.sort((a, b) => order[a.kind] - order[b.kind] || (a.num ?? 0) - (b.num ?? 0) || a.start - b.start);
}

/** Display label: "A"–"H" for hot cues, "Loop 1"–"Loop 8", "Memory". */
function label(c) { return c.kind === 'hot' ? 'ABCDEFGH'[c.num] : c.kind === 'loop' ? `Loop ${c.num + 1}` : 'Memory'; }

// ---------------------------------------------------------------- rekordbox
// Hot cue colour table (djmdCue.ColorTableIndex / ANLZ hot cue colour index). 0 = no colour.
const RB_HOT = [null, '#305aff', '#5073ff', '#508cff', '#50a0ff', '#50b4ff', '#50b0f2', '#50aee8', '#45acdb', '#00e0ff', '#19daf0', '#32d2e6',
  '#21b4b9', '#20aaa0', '#1fa392', '#19a08c', '#14a584', '#14aa7d', '#10b176', '#30d26e', '#37de5a', '#3ceb50', '#28e214', '#7dc13d',
  '#8cc832', '#9bd723', '#a5e116', '#a5dc0a', '#aad208', '#b4c805', '#b4be04', '#bab404', '#c3af04', '#e1aa00', '#ffa000', '#ff9600',
  '#ff8c00', '#ff7500', '#e0641b', '#e0461e', '#e0301e', '#e02823', '#e62828', '#ff376f', '#ff2d6f', '#ff127b', '#f51e8c', '#eb2da0',
  '#e637b4', '#de44cf', '#de448d', '#e630b4', '#e619dc', '#e600ff', '#dc00ff', '#cc00ff', '#b432ff', '#b93cff', '#c542ff', '#aa5aff',
  '#aa72ff', '#8272ff', '#6473ff'];
// Memory cue colours (djmdCue.Color 0-7): pink, red, orange, yellow, green, aqua, blue, purple.
const RB_MEMORY = ['#f870f8', '#e62828', '#ffa000', '#ffdc00', '#28e214', '#00e0ff', '#305aff', '#a000ff'];

const dist = (a, b) => (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2;
const nearest = (table, color) => { const c = rgb(color); if (!c) return -1; let best = -1, bd = Infinity; table.forEach((t, i) => { const v = rgb(t); if (v && dist(v, c) < bd) { bd = dist(v, c); best = i; } }); return best; };

/** One djmdCue row (rekordbox 6/7 master.db) -> Crate cue. */
function fromRekordboxRow(r) {
  const kind = Number(r.Kind) || 0;
  const start = Number(r.InMsec) / 1000;
  const end = Number(r.OutMsec) > 0 ? Number(r.OutMsec) / 1000 : null;
  const name = String(r.Comment || '');
  // Kind: 0 = memory cue; hot cues A-C are 1-3 and D-H are 5-9.
  if (kind >= 1 && kind <= 9 && kind !== 4) {
    const num = kind <= 3 ? kind - 1 : kind - 2;
    const ci = Number(r.ColorTableIndex);
    return { kind: 'hot', num, start, end, name, color: ci > 0 && ci < RB_HOT.length ? RB_HOT[ci] : null };
  }
  const ci = Number(r.Color);
  return { kind: 'memory', num: null, start, end, name, color: ci >= 0 && ci < RB_MEMORY.length ? RB_MEMORY[ci] : null };
}

/** Crate cues -> rekordbox XML POSITION_MARK attribute sets. */
function toRekordboxMarks(list) {
  const marks = [];
  for (const c of normalize(list)) {
    const loop = c.end != null;
    const m = { Name: c.name, Type: loop ? 4 : 0, Start: c.start.toFixed(3), Num: c.kind === 'hot' ? c.num : -1 };
    if (loop) m.End = c.end.toFixed(3);
    if (c.kind === 'hot' && c.color) { const [r, g, b] = rgb(c.color); Object.assign(m, { Red: r, Green: g, Blue: b }); }
    marks.push(m);
  }
  return marks;
}

// ---------------------------------------------------------------- Engine DJ
// Engine keeps cues in PerformanceData: quickCues (zlib, big-endian), loops (raw, little-endian),
// both in sample offsets, with the sample rate in trackData. qCompress = 4-byte big-endian length + zlib.
const ENGINE_HOT_DEFAULTS = ['#4b88e2', '#1ebc61', '#f4d345', '#ce3232', '#4b88e2', '#1ebc61', '#f4d345', '#ce3232'];
const ENGINE_LOOP_DEFAULT = '#ef8130';
const qUncompress = (b) => { if (!b || b.length < 5) return null; return zlib.inflateSync(Buffer.from(b).subarray(4)); };
const qCompress = (buf) => { const h = Buffer.alloc(4); h.writeUInt32BE(buf.length); return Buffer.concat([h, zlib.deflateSync(buf)]); };

function engineTrackData(blob) {
  const d = qUncompress(blob); if (!d || d.length < 16) return null;
  return { sampleRate: d.readDoubleBE(0), samples: Number(d.readBigInt64BE(8)) };
}
function makeEngineTrackData(sampleRate, samples) {
  const d = Buffer.alloc(68); d.writeDoubleBE(sampleRate, 0); d.writeBigInt64BE(BigInt(Math.max(0, Math.round(samples))), 8);
  return qCompress(d);
}
const argbToHex = (b, o) => hex(b[o + 1], b[o + 2], b[o + 3]);
const writeArgb = (buf, o, color, alpha = 0xff) => { const c = rgb(color) || [0, 0, 0]; buf[o] = alpha; buf[o + 1] = c[0]; buf[o + 2] = c[1]; buf[o + 3] = c[2]; };

/** PerformanceData blobs -> Crate cues. Returns [] when there's nothing usable. */
function fromEngine({ trackData, quickCues, loops }) {
  const td = engineTrackData(trackData); const rate = td && td.sampleRate;
  if (!rate) return [];
  const out = [];
  const q = quickCues ? qUncompress(quickCues) : null;
  if (q && q.length >= 8) {
    let o = 0; const n = Number(q.readBigInt64BE(0)); o = 8;
    for (let i = 0; i < n && o < q.length; i++) {
      const l = q[o++]; const name = q.toString('utf8', o, o + l); o += l;
      const pos = q.readDoubleBE(o); o += 8; const color = argbToHex(q, o); o += 4;
      // Engine labels unnamed pads "Cue 1"…"Cue 8"; only that exact default counts as no name.
      if (pos >= 0 && i < 8) out.push({ kind: 'hot', num: i, start: pos / rate, end: null, name: name === `Cue ${i + 1}` ? '' : name, color });
    }
    if (o + 17 <= q.length) {
      const adjusted = q.readDoubleBE(o), isAdjusted = q[o + 8];
      if (isAdjusted && adjusted > 0) out.push({ kind: 'memory', num: null, start: adjusted / rate, end: null, name: '', color: null });
    }
  }
  if (loops && loops.length >= 8) {
    const L = Buffer.from(loops); let o = 8; const n = Number(L.readBigInt64LE(0));
    for (let i = 0; i < n && o < L.length; i++) {
      const l = L[o++]; const name = L.toString('utf8', o, o + l); o += l;
      const s = L.readDoubleLE(o), e = L.readDoubleLE(o + 8); o += 16; const ss = L[o++], es = L[o++]; const color = argbToHex(L, o); o += 4;
      if (ss && es && s >= 0 && e > s && i < 8) out.push({ kind: 'loop', num: i, start: s / rate, end: e / rate, name: name === `Loop ${i + 1}` ? '' : name, color });
    }
  }
  return normalize(out);
}

/**
 * Crate cues -> Engine blobs. Hot cues go to the 8 quick cue pads; saved loops to their loop pads,
 * then hot loops and memory loops fill free loop pads; the first memory cue becomes the main cue.
 * `existingQuick` keeps Engine's default main cue position. Returns { quickCues, loops, dropped }.
 */
function toEngine(list, sampleRate, existingQuick) {
  const cues = normalize(list); const S = (t) => Math.round(t * sampleRate); // Engine stores whole sample offsets
  const hot = new Array(8).fill(null), loops = new Array(8).fill(null); let dropped = 0;
  for (const c of cues) if (c.kind === 'hot') hot[c.num] = c;
  for (const c of cues) if (c.kind === 'loop') loops[c.num] = c;
  for (const c of cues) if (c.kind !== 'loop' && c.end != null) { // hot loops keep their cue pad too
    const free = loops.indexOf(null); if (free >= 0) loops[free] = c; else if (c.kind === 'memory') dropped++;
  }
  // Engine has no memory cues, only one main cue: the earliest memory cue becomes it.
  const memoryCues = cues.filter(c => c.kind === 'memory' && c.end == null);
  const main = memoryCues[0]; dropped += Math.max(0, memoryCues.length - 1);

  const parts = []; const n8 = Buffer.alloc(8); n8.writeBigInt64BE(8n); parts.push(n8);
  hot.forEach((c, i) => {
    const name = Buffer.from(c ? (c.name || `Cue ${i + 1}`) : '', 'utf8').subarray(0, 255);
    const b = Buffer.alloc(1 + name.length + 12); b[0] = name.length; name.copy(b, 1);
    b.writeDoubleBE(c ? S(c.start) : -1, 1 + name.length); writeArgb(b, 9 + name.length, c ? (c.color || ENGINE_HOT_DEFAULTS[i]) : null, c ? 0xff : 0); // empty pad: 00000000
    parts.push(b);
  });
  let defaultMain = 0;
  const old = existingQuick ? qUncompress(existingQuick) : null;
  if (old && old.length >= 17) defaultMain = old.readDoubleBE(old.length - 8);
  const tail = Buffer.alloc(17);
  tail.writeDoubleBE(main ? S(main.start) : defaultMain, 0); tail[8] = main ? 1 : 0; tail.writeDoubleBE(defaultMain, 9);
  parts.push(tail);

  const lp = []; const c8 = Buffer.alloc(8); c8.writeBigInt64LE(8n); lp.push(c8);
  loops.forEach((c, i) => {
    const name = Buffer.from(c ? (c.name || `Loop ${i + 1}`) : '', 'utf8').subarray(0, 255);
    const b = Buffer.alloc(1 + name.length + 22); b[0] = name.length; name.copy(b, 1); let o = 1 + name.length;
    b.writeDoubleLE(c ? S(c.start) : -1, o); b.writeDoubleLE(c ? S(c.end) : -1, o + 8); o += 16;
    b[o++] = c ? 1 : 0; b[o++] = c ? 1 : 0; writeArgb(b, o, c ? (c.color || ENGINE_LOOP_DEFAULT) : null);
    lp.push(b);
  });
  return { quickCues: qCompress(Buffer.concat(parts)), loops: Buffer.concat(lp), dropped };
}

// ---------------------------------------------------------------- Serato (also written by Mixed In Key)
// "Serato Markers2": base64 text inside an ID3 GEOB frame (MP3/AIFF/WAV), or base64 of the whole
// GEOB payload in FLAC (SERATO_MARKERS_V2) and MP4 (----:com.serato.dj:markersv2).
function b64(s) { s = String(s).replace(/[^A-Za-z0-9+/]/g, ''); if (s.length % 4 === 1) s = s.slice(0, -1); return Buffer.from(s, 'base64'); }
function fromSeratoMarkers2(data) {
  if (!data || !data.length) return [];
  let buf = Buffer.isBuffer(data) ? data : b64(data);
  // FLAC/MP4 wrap the GEOB payload: "application/octet-stream\0\0Serato Markers2\0" + payload
  const tag = buf.indexOf('Serato Markers2\0', 0, 'latin1');
  if (tag >= 0 && tag < 64) buf = buf.subarray(tag + 16);
  if (buf[0] !== 1 || buf[1] !== 1) return [];
  let end = buf.indexOf(0, 2); if (end < 0) end = buf.length;
  const body = b64(buf.toString('latin1', 2, end));
  if (body[0] !== 1 || body[1] !== 1) return [];
  const out = []; let o = 2;
  while (o < body.length) {
    const z = body.indexOf(0, o); if (z <= o) break;
    const type = body.toString('latin1', o, z); o = z + 1;
    if (o + 4 > body.length) break;
    const len = body.readUInt32BE(o); o += 4; const p = body.subarray(o, o + len); o += len;
    try {
      if (type === 'CUE' && p.length >= 13) {
        const ne = p.indexOf(0, 12);
        out.push({ kind: 'hot', num: p[1], start: p.readUInt32BE(2) / 1000, end: null, name: p.toString('utf8', 12, ne < 0 ? p.length : ne), color: hex(p[7], p[8], p[9]) });
      } else if (type === 'LOOP' && p.length >= 20) {
        const ne = p.indexOf(0, 19);
        out.push({ kind: 'loop', num: p[1], start: p.readUInt32BE(2) / 1000, end: p.readUInt32BE(6) / 1000, name: p.toString('utf8', 19, ne < 0 ? p.length : ne), color: null });
      }
    } catch { /* skip a damaged entry */ }
  }
  return normalize(out);
}

module.exports = { normalize, label, fromRekordboxRow, toRekordboxMarks, nearest, RB_HOT, RB_MEMORY,
  fromEngine, toEngine, engineTrackData, makeEngineTrackData, qCompress, qUncompress, fromSeratoMarkers2 };
