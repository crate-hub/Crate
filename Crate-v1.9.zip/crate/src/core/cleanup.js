'use strict';
// Clean-up tools. Every tool returns a preview list of { id, changes, before } that the UI shows
// before anything is written; Library.applyEdits() then applies the accepted rows.

// ---------- duplicates ----------
const LOSSLESS = new Set(['flac', 'wav', 'aiff']);
function norm(s) {
  return String(s || '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase()
    .replace(/\b(feat|ft|featuring)\.?\s.*$/, '') // drop featured artists
    .replace(/\((original|extended)( mix)?\)|\[(original|extended)( mix)?\]|\boriginal mix\b/g, '')
    .replace(/[^a-z0-9]+/g, ' ').trim();
}
function quality(t) { return (LOSSLESS.has(t.format) ? 10000 : 0) + (t.bitrate || 0); }

/**
 * Group likely duplicates: same normalised artist + title (+ mix/remixer), durations within `tolerance` seconds.
 * Returns [{ key, keep: id, tracks: [...] }] with the best-quality copy suggested as the keeper.
 */
function findDuplicates(tracks, { tolerance = 3 } = {}) {
  const groups = new Map();
  for (const t of tracks) {
    const k = `${norm(t.artist)}|${norm(t.title)}|${norm(t.mix)}|${norm(t.remixer)}`;
    if (k.replace(/\|/g, '') === '') continue;
    if (!groups.has(k)) groups.set(k, []); groups.get(k).push(t);
  }
  const out = [];
  for (const [key, list] of groups) {
    if (list.length < 2) continue;
    // split by duration so different edits (radio vs extended) are not merged
    const sorted = [...list].sort((a, b) => a.duration - b.duration); let cluster = [sorted[0]];
    const flush = () => { if (cluster.length > 1) { const best = [...cluster].sort((a, b) => quality(b) - quality(a) || a.id - b.id)[0]; out.push({ key, keep: best.id, tracks: cluster }); } };
    for (let i = 1; i < sorted.length; i++) {
      if (!sorted[i].duration || !cluster[0].duration || Math.abs(sorted[i].duration - cluster[cluster.length - 1].duration) <= tolerance) cluster.push(sorted[i]);
      else { flush(); cluster = [sorted[i]]; }
    }
    flush();
  }
  return out.sort((a, b) => a.key.localeCompare(b.key));
}

// ---------- SmartFix-style text fixes ----------
const SMALL = new Set(['a', 'an', 'and', 'as', 'at', 'but', 'by', 'for', 'in', 'of', 'on', 'or', 'the', 'to', 'vs', 'via', 'feat', 'ft', 'x']);
function titleCase(s) {
  let first = true;
  return s.replace(/[\p{L}\p{N}'’]+/gu, (w, idx) => {
    const lower = w.toLowerCase();
    const isFirst = first; first = false;
    if (/\p{L}/u.test(w) && /\d/.test(w)) return w; // stylised names like deadmau5, mau5trap, b2b
    const prev = s.slice(Math.max(0, idx - 2), idx);
    if (!isFirst && SMALL.has(lower) && !/[(\[-]\s?$/.test(prev)) return lower;
    if (/^(dj|mc|uk|usa|edm|ep|lp|vip|ii|iii|iv)$/.test(lower)) return w.toUpperCase();
    return lower.charAt(0).toUpperCase() + lower.slice(1);
  });
}
const FIXES = {
  whitespace: { label: 'Tidy spaces and stray punctuation', fields: ['title', 'artist', 'album', 'label', 'remixer', 'genre'],
    fn: s => s.replace(/\s+/g, ' ').replace(/\s+([,)\]])/g, '$1').replace(/([(\[])\s+/g, '$1').trim() },
  underscores: { label: 'Replace underscores with spaces', fields: ['title', 'artist', 'album', 'genre', 'label'],
    fn: s => s.includes(' ') && !s.includes('_') ? s : s.replace(/_+/g, ' ').replace(/\s+/g, ' ').trim() },
  urls: { label: 'Remove web addresses', fields: ['title', 'artist', 'album', 'comment', 'label'],
    fn: s => s.replace(/\b(get|buy|download|grab|available|stream)(\s+(it|this|now))?\s+(at|on|from)\s+(?=https?:|www\.|\S+\.(com|net|org|ru|info|io|fm|to|cc)\b)/gi, '')
      .replace(/\s*[\[(]?\s*(https?:\/\/\S+|www\.\S+|\S+\.(com|net|org|ru|info|io|fm|to|cc)\b\S*)\s*[\])]?/gi, ' ').replace(/\s+/g, ' ')
      .replace(/^[\s\-–—|:]+|[\s\-–—|:]+$/g, '').trim() }, // also drop separators the URL leaves behind
  promo: { label: 'Remove promo text ("Free Download", "Out Now", "Premiere"...)', fields: ['title', 'artist', 'comment'],
    fn: s => s.replace(/\s*[\[(]\s*(free\s*(dl|download)|out\s*now|premiere|promo(\s*only)?|exclusive|preview|buy\s*=\s*free[^\])]*)\s*[\])]/gi, '')
      .replace(/^\s*(premiere|free download)\s*[:|-]\s*/i, '').trim() },
  numberPrefix: { label: 'Remove track-number prefixes ("01 - ", "A1. ")', fields: ['title'],
    fn: s => s.replace(/^\s*(?:[A-D]?\d{1,3})\s*(?:[-._)]\s*|\s+-\s+)(?=\S)/i, '').trim() },
  // Titles and albums only: artist and label names are often styled on purpose (FISHER, deadmau5, RÜFÜS DU SOL).
  titleCase: { label: 'Title Case titles and albums written in ALL CAPS or all lower case', fields: ['title', 'album'],
    fn: s => { if (!/\p{L}/u.test(s)) return s; if (s === s.toLowerCase()) return titleCase(s); if (s === s.toUpperCase() && /\s/.test(s.trim())) return titleCase(s); return s; } },
};

// Field-to-field fixes (need the whole track)
const TRACK_FIXES = {
  extractRemixer: { label: 'Fill Remixer from the title ("Title (Someone Remix)")',
    fn: t => {
      if (t.remixer) return null;
      const m = String(t.title).match(/[\[(]\s*([^\])]+?)\s+(remix|re-?mix|rework|re-?edit|edit|bootleg|flip|dub|vip mix)\s*[\])]/i);
      if (!m) return null;
      // "Eric Prydz Private Remix" -> "Eric Prydz"
      const name = m[1].replace(/\s+(private|extended|club|dub|radio|vocal|instrumental|official|original|special|unreleased|edit)$/i, '').trim();
      if (!name || /^(original|extended|radio|club|dub|vocal|instrumental|official|private|special)$/i.test(name)) return null;
      return { remixer: name };
    } },
  splitArtistTitle: { label: 'Split "Artist - Title" when the artist field is empty',
    fn: t => {
      if (t.artist) return null;
      const m = String(t.title).match(/^(.+?)\s+[-–—]\s+(.+)$/); if (!m) return null;
      return { artist: m[1].trim(), title: m[2].trim() };
    } },
};

/** Preview chosen fixes over tracks. fixes: array of keys from FIXES / TRACK_FIXES. */
function previewFixes(tracks, fixes) {
  const out = [];
  for (const t of tracks) {
    const changes = {}; const cur = { ...t };
    for (const name of fixes) {
      if (FIXES[name]) {
        for (const f of FIXES[name].fields) { const v = cur[f]; if (typeof v !== 'string' || !v) continue; const nv = FIXES[name].fn(v); if (nv !== v) { cur[f] = nv; changes[f] = nv; } }
      } else if (TRACK_FIXES[name]) {
        const r = TRACK_FIXES[name].fn(cur); if (r) for (const [f, v] of Object.entries(r)) if (v !== cur[f]) { cur[f] = v; changes[f] = v; }
      }
    }
    const fields = Object.keys(changes);
    if (fields.length) out.push({ id: t.id, changes, before: Object.fromEntries(fields.map(f => [f, t[f]])) });
  }
  return out;
}

/** Find & replace in one field. */
function previewReplace(tracks, { field, find, replace = '', caseSensitive = false, wholeValue = false }) {
  if (!find) return [];
  const out = [];
  for (const t of tracks) {
    const v = String(t[field] ?? ''); let nv;
    if (wholeValue) nv = (caseSensitive ? v === find : v.toLowerCase() === find.toLowerCase()) ? replace : v;
    else { const re = new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), caseSensitive ? 'g' : 'gi'); nv = v.replace(re, replace); }
    if (nv !== v) out.push({ id: t.id, changes: { [field]: nv }, before: { [field]: v } });
  }
  return out;
}

/** Rename / merge genres: mapping { "old genre": "New Genre" } matched against the exact whole value. */
function previewGenreRename(tracks, mapping) {
  // Exact match: the genre list shows each spelling separately, so "house" and "House" can be unified.
  const m = new Map(Object.entries(mapping));
  const out = [];
  for (const t of tracks) { const g = String(t.genre || ''); const nv = m.get(g); if (nv !== undefined && nv !== g) out.push({ id: t.id, changes: { genre: nv }, before: { genre: g } }); }
  return out;
}

const FIX_LIST = [...Object.entries(FIXES), ...Object.entries(TRACK_FIXES)].map(([id, f]) => ({ id, label: f.label }));
module.exports = { findDuplicates, previewFixes, previewReplace, previewGenreRename, FIX_LIST, titleCase, norm };
