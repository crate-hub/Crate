'use strict';
// Renames music files to "Artist - Title.ext" from their tags, in the folder they're already in.
const fs = require('fs');
const path = require('path');

const MAX_BYTES = 240; // macOS allows 255 bytes per name; leave room for " (2)" and the extension

/** Makes text safe as a file name on macOS, Windows and USB sticks (FAT/exFAT). */
function sanitize(s) {
  let out = String(s || '').normalize('NFC')
    .replace(/[\u0000-\u001f\u007f]/g, '')
    .replace(/\s*[/\\]\s*/g, ' - ')        // AC/DC -> AC - DC (a slash would make a folder)
    .replace(/\s*:\s*/g, ' - ')            // "Title: Sub" -> "Title - Sub"
    .replace(/[*?<>|]/g, '')
    .replace(/"/g, "'")
    .replace(/\s+/g, ' ')
    .replace(/( - )+/g, ' - ')
    .trim()
    .replace(/[. ]+$/, '');                // no trailing dots or spaces (Windows, FAT)
  while (Buffer.byteLength(out) > MAX_BYTES) out = out.slice(0, -1);
  return out.trim();
}

/** The new base name ("Artist - Title") for a track, or null when artist or title is missing. */
function baseName(t) {
  const artist = sanitize(t.artist), title = sanitize(t.title);
  if (!artist || !title) return null;
  return `${artist} - ${title}`;
}

const sameFile = (a, b) => { try { const x = fs.statSync(a), y = fs.statSync(b); return x.ino === y.ino && x.dev === y.dev; } catch { return false; } };

/**
 * Works out every rename without touching the disk.
 * Returns [{ id, from, to, status }] where status is 'rename', 'same' (already named so),
 * 'missing' (file not found) or 'noTags' (artist or title empty).
 */
function plan(tracks) {
  const taken = new Set(); const out = [];
  for (const t of tracks) {
    const ext = path.extname(t.path); const dir = path.dirname(t.path);
    const base = baseName(t);
    if (!base) { out.push({ id: t.id, from: t.path, to: null, status: 'noTags' }); continue; }
    if (t.missing || !fs.existsSync(t.path)) { out.push({ id: t.id, from: t.path, to: null, status: 'missing' }); continue; }
    if (path.basename(t.path, ext) === base) { out.push({ id: t.id, from: t.path, to: t.path, status: 'same' }); taken.add(t.path.toLowerCase()); continue; }
    let to, n = 1;
    for (;;) {
      to = path.join(dir, (n === 1 ? base : `${base} (${n})`) + ext);
      const key = to.toLowerCase();
      // Free if no other file has the name (a case-only change of the same file is fine) and no other track in this batch claimed it.
      if (!taken.has(key) && (!fs.existsSync(to) || sameFile(to, t.path))) break;
      n++;
    }
    taken.add(to.toLowerCase());
    out.push({ id: t.id, from: t.path, to, status: to === t.path ? 'same' : 'rename' });
  }
  return out;
}

module.exports = { sanitize, baseName, plan };
