'use strict';
// FLAC: STREAMINFO + VORBIS_COMMENT read/write. Unknown comment fields (e.g. SERATO_*) are preserved.

const MAP = { // field -> [primary key, ...aliases]
  title: ['TITLE'], artist: ['ARTIST'], album: ['ALBUM'], genre: ['GENRE'], comment: ['COMMENT', 'DESCRIPTION'],
  bpm: ['BPM', 'TEMPO'], key: ['INITIALKEY', 'KEY'], year: ['DATE', 'YEAR'], label: ['LABEL', 'ORGANIZATION', 'PUBLISHER'],
  remixer: ['REMIXER', 'MIXARTIST'], composer: ['COMPOSER'], grouping: ['GROUPING', 'CONTENTGROUP'],
  trackNumber: ['TRACKNUMBER'], rating: ['RATING'], mix: ['SUBTITLE'],
};

/** Returns { blocks:[{type,data,start,end}], audioStart } or null. */
function parseBlocks(buf) {
  let p = buf.toString('latin1', 0, 3) === 'ID3' ? require('./id3').parse(buf, 0).size : 0;
  if (buf.toString('latin1', p, p + 4) !== 'fLaC') return null;
  const metaStart = p; p += 4;
  const blocks = [];
  let complete = false;
  for (;;) {
    if (p + 4 > buf.length) break;
    const last = buf[p] & 0x80, type = buf[p] & 0x7f, len = buf.readUIntBE(p + 1, 3);
    blocks.push({ type, data: buf.subarray(p + 4, p + 4 + len), start: p, end: p + 4 + len });
    p += 4 + len;
    if (last) { complete = p <= buf.length; break; }
  }
  // When the head buffer is too short, ask the caller for more (at least past the current position).
  return { blocks, audioStart: complete ? p : Math.max(p, buf.length) + 65536, metaStart, complete };
}

function readComments(data) {
  let p = 0; const vlen = data.readUInt32LE(p); p += 4;
  const vendor = data.toString('utf8', p, p + vlen); p += vlen;
  const n = data.readUInt32LE(p); p += 4; const items = [];
  for (let i = 0; i < n && p + 4 <= data.length; i++) {
    const l = data.readUInt32LE(p); p += 4; const s = data.toString('utf8', p, p + l); p += l;
    const eq = s.indexOf('='); if (eq > 0) items.push([s.slice(0, eq), s.slice(eq + 1)]);
  }
  return { vendor, items };
}
function writeComments(vendor, items) {
  const parts = []; const v = Buffer.from(vendor, 'utf8');
  const h = Buffer.alloc(4); h.writeUInt32LE(v.length); parts.push(h, v);
  const c = Buffer.alloc(4); c.writeUInt32LE(items.length); parts.push(c);
  for (const [k, val] of items) { const s = Buffer.from(`${k}=${val}`, 'utf8'); const l = Buffer.alloc(4); l.writeUInt32LE(s.length); parts.push(l, s); }
  return Buffer.concat(parts);
}

function ratingFrom(v) { const n = parseFloat(v); if (!(n > 0)) return 0; if (n <= 5) return Math.round(n); return Math.max(1, Math.min(5, Math.round(n / 20))); }

function read(buf) {
  const pb = parseBlocks(buf); if (!pb) return null;
  if (!pb.complete) return { needBytes: pb.audioStart };
  const si = pb.blocks.find(b => b.type === 0);
  let duration = 0, sampleRate = 0;
  if (si) {
    const d = si.data; sampleRate = (d[10] << 12) | (d[11] << 4) | (d[12] >> 4);
    const totalSamples = (d[13] & 0x0f) * 2 ** 32 + d.readUInt32BE(14);
    if (sampleRate) duration = totalSamples / sampleRate;
  }
  const fields = {};
  const vc = pb.blocks.find(b => b.type === 4);
  if (vc) {
    const { items } = readComments(vc.data);
    const serato = items.find(([k]) => k.toUpperCase() === 'SERATO_MARKERS_V2'); if (serato) fields.__serato = serato[1];
    const upper = new Map(); for (const [k, v] of items) { const K = k.toUpperCase(); if (!upper.has(K)) upper.set(K, []); upper.get(K).push(v); }
    for (const [field, keys] of Object.entries(MAP)) {
      const k = keys.find(k => upper.has(k)); if (!k) continue;
      const vals = upper.get(k); let v = vals.join(', ');
      if (field === 'bpm') { const n = parseFloat(v); if (n > 0) fields.bpm = n; }
      else if (field === 'year') { const y = parseInt(v, 10); if (y > 0) fields.year = y; }
      else if (field === 'trackNumber') { const n = parseInt(v, 10); if (n > 0) fields.trackNumber = n; }
      else if (field === 'rating') { const r = ratingFrom(vals[0]); if (r) fields.rating = r; }
      else if (field === 'comment') fields.comment = vals[0];
      else fields[field] = v;
    }
  }
  return { fields, duration, sampleRate };
}

/** Returns { inPlace: Buffer, at } when it fits in the existing metadata area, else { segments } (Buffers + {from} file ranges). */
function write(buf, fields) {
  const pb = parseBlocks(buf); if (!pb) throw new Error('Not a FLAC file');
  if (!pb.complete) return { needBytes: pb.audioStart };
  const vcBlock = pb.blocks.find(b => b.type === 4);
  const { vendor, items } = vcBlock ? readComments(vcBlock.data) : { vendor: 'crate', items: [] };
  // Drop managed keys only for the fields we are setting; keep everything else.
  const touched = new Set(); for (const f of Object.keys(fields)) if (MAP[f]) MAP[f].forEach(k => touched.add(k));
  const kept = items.filter(([k]) => !touched.has(k.toUpperCase()));
  for (const [field, val] of Object.entries(fields)) {
    if (!MAP[field] || val === undefined || val === null || val === '' || (typeof val === 'number' && !(val > 0))) continue;
    const key = MAP[field][0];
    const s = field === 'rating' ? String(Math.round(val) * 20) : String(val);
    kept.push([key, s]);
  }
  const newVc = writeComments(vendor, kept);
  // Rebuild metadata: all blocks except VORBIS_COMMENT and PADDING, then VC, then padding.
  const others = pb.blocks.filter(b => b.type !== 4 && b.type !== 1);
  const oldMetaLen = pb.audioStart - (pb.metaStart + 4);
  const fixedLen = others.reduce((s, b) => s + 4 + b.data.length, 0) + 4 + newVc.length;
  let padLen;
  if (fixedLen + 4 <= oldMetaLen) padLen = oldMetaLen - fixedLen - 4; // fits: reuse space
  else padLen = 4096;
  const ordered = [...others.filter(b => b.type === 0), ...others.filter(b => b.type !== 0)];
  const out = [];
  const pushBlock = (type, data, last) => { const h = Buffer.alloc(4); h[0] = (last ? 0x80 : 0) | type; h.writeUIntBE(data.length, 1, 3); out.push(h, data); };
  ordered.forEach(b => pushBlock(b.type, b.data, false));
  pushBlock(4, newVc, false);
  pushBlock(1, Buffer.alloc(padLen), true);
  const meta = Buffer.concat(out);
  if (meta.length === oldMetaLen) return { inPlace: meta, at: pb.metaStart + 4 };
  return { segments: [buf.subarray(0, pb.metaStart + 4), meta, { from: pb.audioStart }] };
}

module.exports = { read, write };
