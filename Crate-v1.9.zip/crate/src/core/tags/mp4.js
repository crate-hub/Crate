'use strict';
// MP4 / M4A (iTunes-style ilst) reader and writer.
// Unknown ilst items (artwork, Serato/Mixed In Key freeform atoms, ...) are preserved.
// When moov is rewritten and sits before mdat, stco/co64 chunk offsets are shifted.

const CONTAINERS = new Set(['moov', 'trak', 'mdia', 'minf', 'stbl', 'udta', 'edts', 'dinf', 'ilst', 'meta']);
const ITEMS = { '\xa9nam': 'title', '\xa9ART': 'artist', '\xa9alb': 'album', '\xa9gen': 'genre', '\xa9cmt': 'comment',
  '\xa9day': 'year', '\xa9grp': 'grouping', '\xa9wrt': 'composer', tmpo: 'bpm', trkn: 'trackNumber' };
const FREEFORM = { key: ['initialkey', 'INITIALKEY', 'KEY'], label: ['LABEL', 'PUBLISHER'],
  remixer: ['REMIXER', 'MIXARTIST', 'REMIXEDBY'], mix: ['SUBTITLE'], rating: ['RATING'] };
const FREEFORM_WRITE = { key: 'initialkey', label: 'LABEL', remixer: 'REMIXER', mix: 'SUBTITLE', rating: 'RATING' };

/** Scan top-level atoms with a positional reader: readAt(pos, len) -> Buffer, size = file size. */
function scanTop(readAt, size) {
  const atoms = []; let p = 0;
  while (p + 8 <= size) {
    const h = readAt(p, 16); let len = h.readUInt32BE(0); const type = h.toString('latin1', 4, 8); let hdr = 8;
    if (len === 1) { len = Number(h.readBigUInt64BE(8)); hdr = 16; } else if (len === 0) len = size - p;
    if (len < hdr || p + len > size) break;
    atoms.push({ type, start: p, len, hdr }); p += len;
  }
  return atoms;
}

function parseChildren(buf, start, end) {
  const out = []; let p = start;
  while (p + 8 <= end) {
    let len = buf.readUInt32BE(p); const type = buf.toString('latin1', p + 4, p + 8); let hdr = 8;
    if (len === 1) { len = Number(buf.readBigUInt64BE(p + 8)); hdr = 16; } else if (len === 0) len = end - p;
    if (len < hdr || p + len > end) break;
    const node = { type };
    const bodyStart = p + hdr, bodyEnd = p + len;
    if (type === 'meta') {
      const full = buf.toString('latin1', bodyStart + 8, bodyStart + 12) === 'hdlr' || buf.readUInt32BE(bodyStart) === 0;
      node.prefix = full ? buf.subarray(bodyStart, bodyStart + 4) : Buffer.alloc(0);
      node.children = parseChildren(buf, bodyStart + node.prefix.length, bodyEnd);
    } else if (CONTAINERS.has(type)) node.children = parseChildren(buf, bodyStart, bodyEnd);
    else node.data = buf.subarray(bodyStart, bodyEnd);
    out.push(node); p += len;
  }
  return out;
}
function parseIlst(node) { // ilst items are containers of data/mean/name atoms
  for (const it of node.children) if (it.data) { it.children = parseChildren(it.data, 0, it.data.length); delete it.data; }
}
function serialize(node) {
  if (node.children) {
    const body = Buffer.concat([node.prefix || Buffer.alloc(0), ...node.children.map(serialize)]);
    const h = Buffer.alloc(8); h.writeUInt32BE(8 + body.length); h.write(node.type, 4, 'latin1'); return Buffer.concat([h, body]);
  }
  const h = Buffer.alloc(8); h.writeUInt32BE(8 + node.data.length); h.write(node.type, 4, 'latin1'); return Buffer.concat([h, node.data]);
}
const find = (nodes, type) => nodes && nodes.find(n => n.type === type);
function path(root, types) { let cur = root; for (const t of types) { cur = find(cur.children, t); if (!cur) return null; } return cur; }

function itemValue(item) {
  const d = find(item.children, 'data'); if (!d) return null;
  const typeCode = d.data.readUInt32BE(0) & 0xffffff, v = d.data.subarray(8);
  if (typeCode === 1) return v.toString('utf8');
  return v;
}
function freeformName(item) { const n = find(item.children, 'name'); return n ? n.data.subarray(4).toString('utf8') : null; }

function loadMoov(readAt, size) {
  const top = scanTop(readAt, size);
  const m = top.find(a => a.type === 'moov'); if (!m) return null;
  const buf = readAt(m.start, m.len);
  const moov = { type: 'moov', children: parseChildren(buf, m.hdr, m.len) };
  const ilst = path(moov, ['udta', 'meta', 'ilst']); if (ilst) parseIlst(ilst);
  return { top, moovAtom: m, moov, ilst };
}

function read(readAt, size) {
  const L = loadMoov(readAt, size); if (!L) return null;
  const fields = {};
  let duration = 0, sampleRate = 0;
  const mvhd = path(L.moov, ['mvhd']);
  if (mvhd) {
    const d = mvhd.data; const v1 = d[0] === 1;
    const ts = v1 ? d.readUInt32BE(20) : d.readUInt32BE(12);
    const du = v1 ? Number(d.readBigUInt64BE(24)) : d.readUInt32BE(16);
    if (ts) duration = du / ts;
  }
  for (const trak of L.moov.children.filter(n => n.type === 'trak')) {
    const hdlr = path(trak, ['mdia', 'hdlr']), mdhd = path(trak, ['mdia', 'mdhd']);
    if (hdlr && hdlr.data.toString('latin1', 8, 12) === 'soun' && mdhd) sampleRate = mdhd.data[0] === 1 ? mdhd.data.readUInt32BE(20) : mdhd.data.readUInt32BE(12);
  }
  const mdatBytes = L.top.filter(a => a.type === 'mdat').reduce((s, a) => s + a.len - a.hdr, 0);
  const bitrate = duration ? Math.round(mdatBytes * 8 / duration / 1000) : 0;
  if (L.ilst) {
    for (const it of L.ilst.children) {
      if (it.type === '----') {
        const name = freeformName(it); const v = itemValue(it);
        if (name === 'markersv2' && v) { fields.__serato = Buffer.isBuffer(v) ? v.toString('latin1') : String(v); continue; }
        for (const [field, names] of Object.entries(FREEFORM)) {
          if (name && names.includes(name) && typeof v === 'string') {
            if (field === 'rating') { const n = parseFloat(v); if (n > 0) fields.rating = n <= 5 ? Math.round(n) : Math.max(1, Math.min(5, Math.round(n / 20))); }
            else if (!fields[field]) fields[field] = v;
          }
        }
        continue;
      }
      const field = ITEMS[it.type]; const v = itemValue(it);
      if (it.type === 'gnre' && Buffer.isBuffer(v) && v.length >= 2 && !fields.genre) { fields.genre = require('./id3').GENRES[v.readUInt16BE(0) - 1] || ''; continue; }
      if (!field || v === null) continue;
      if (field === 'bpm') { const n = Buffer.isBuffer(v) ? v.readUIntBE(0, Math.min(2, v.length)) : parseFloat(v); if (n > 0) fields.bpm = n; }
      else if (field === 'trackNumber') { if (Buffer.isBuffer(v) && v.length >= 4) { const n = v.readUInt16BE(2); if (n) fields.trackNumber = n; } }
      else if (field === 'year') { const y = parseInt(v, 10); if (y > 0) fields.year = y; }
      else if (typeof v === 'string') fields[field] = v;
    }
  }
  return { fields, duration, sampleRate, bitrate };
}

function dataAtom(typeCode, value) {
  const h = Buffer.alloc(8); h.writeUInt32BE(typeCode); // 4 bytes type, 4 bytes locale (0)
  return { type: 'data', data: Buffer.concat([h, value]) };
}
function textItem(type, str) { return { type, children: [dataAtom(1, Buffer.from(str, 'utf8'))] }; }
function freeformItem(name, str) {
  const pre = Buffer.alloc(4);
  return { type: '----', children: [{ type: 'mean', data: Buffer.concat([pre, Buffer.from('com.apple.iTunes')]) },
    { type: 'name', data: Buffer.concat([pre, Buffer.from(name, 'utf8')]) }, dataAtom(1, Buffer.from(str, 'utf8'))] };
}

function shiftChunkOffsets(node, delta, after) {
  if (node.type === 'stco') {
    const d = Buffer.from(node.data); const n = d.readUInt32BE(4);
    for (let i = 0; i < n; i++) { const o = d.readUInt32BE(8 + i * 4); if (o >= after) d.writeUInt32BE(o + delta, 8 + i * 4); }
    node.data = d;
  } else if (node.type === 'co64') {
    const d = Buffer.from(node.data); const n = d.readUInt32BE(4);
    for (let i = 0; i < n; i++) { const o = d.readBigUInt64BE(8 + i * 8); if (o >= BigInt(after)) d.writeBigUInt64BE(o + BigInt(delta), 8 + i * 8); }
    node.data = d;
  }
  if (node.children && node.type !== 'ilst') node.children.forEach(c => shiftChunkOffsets(c, delta, after));
}

/** Returns { segments } describing the new file. */
function write(readAt, size, fields) {
  const L = loadMoov(readAt, size); if (!L) throw new Error('No moov atom');
  if (L.top.some(a => a.type === 'moof')) throw new Error('Fragmented MP4 files are not supported for tag writing');
  const moov = L.moov;
  let udta = find(moov.children, 'udta'); if (!udta) { udta = { type: 'udta', children: [] }; moov.children.push(udta); }
  let meta = find(udta.children, 'meta');
  if (!meta) {
    const hd = Buffer.alloc(25); hd.write('mdir', 8, 'latin1'); hd.write('appl', 12, 'latin1');
    meta = { type: 'meta', prefix: Buffer.alloc(4), children: [{ type: 'hdlr', data: hd }] }; udta.children.push(meta);
  }
  let ilst = find(meta.children, 'ilst'); if (!ilst) { ilst = { type: 'ilst', children: [] }; meta.children.push(ilst); }
  const managedTypes = new Set(); const managedFree = new Set();
  for (const f of Object.keys(fields)) {
    for (const [t, name] of Object.entries(ITEMS)) if (name === f) managedTypes.add(t);
    if (f === 'genre') managedTypes.add('gnre');
    if (FREEFORM[f]) FREEFORM[f].forEach(n => managedFree.add(n));
  }
  ilst.children = ilst.children.filter(it => it.type === '----' ? !managedFree.has(freeformName(it)) : !managedTypes.has(it.type));
  const ok = v => !(v === undefined || v === null || v === '' || (typeof v === 'number' && !(v > 0)));
  for (const [t, f] of Object.entries(ITEMS)) {
    const v = fields[f]; if (!ok(v)) continue;
    if (f === 'bpm') { const b = Buffer.alloc(2); b.writeUInt16BE(Math.min(65535, Math.round(v))); ilst.children.push({ type: t, children: [dataAtom(21, b)] }); }
    else if (f === 'trackNumber') { const b = Buffer.alloc(8); b.writeUInt16BE(v, 2); ilst.children.push({ type: t, children: [dataAtom(0, b)] }); }
    else ilst.children.push(textItem(t, String(v)));
  }
  for (const [f, name] of Object.entries(FREEFORM_WRITE)) {
    const v = fields[f]; if (!ok(v)) continue;
    ilst.children.push(freeformItem(name, f === 'rating' ? String(Math.round(v) * 20) : String(v)));
  }
  const oldLen = L.moovAtom.len;
  let newMoov = serialize(moov);
  const delta = newMoov.length - oldLen;
  const mdatAfter = L.top.some(a => a.type === 'mdat' && a.start > L.moovAtom.start);
  if (delta !== 0 && mdatAfter) { moov.children.forEach(c => shiftChunkOffsets(c, delta, L.moovAtom.start + oldLen)); newMoov = serialize(moov); }
  const mEnd = L.moovAtom.start + L.moovAtom.len;
  const segments = [{ from: 0, to: L.moovAtom.start }, newMoov];
  if (mEnd < size) segments.push({ from: mEnd });
  return { segments };
}

module.exports = { read, write };
