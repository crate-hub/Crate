'use strict';
// MPEG audio (MP3) stream info: duration, bitrate, sample rate. Handles Xing/Info and VBRI headers.

const BITRATES = { // [versionKey][layer] -> kbps table index 1..14
  V1L1: [32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448],
  V1L2: [32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384],
  V1L3: [32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320],
  V2L1: [32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256],
  V2L23: [8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160],
};
const RATES = { 3: [44100, 48000, 32000], 2: [22050, 24000, 16000], 0: [11025, 12000, 8000] };

function parseHeader(b, o) {
  if (o + 4 > b.length || b[o] !== 0xff || (b[o + 1] & 0xe0) !== 0xe0) return null;
  const ver = (b[o + 1] >> 3) & 3, layerBits = (b[o + 1] >> 1) & 3;
  const brIdx = (b[o + 2] >> 4) & 15, srIdx = (b[o + 2] >> 2) & 3, pad = (b[o + 2] >> 1) & 1;
  const chMode = (b[o + 3] >> 6) & 3;
  if (ver === 1 || layerBits === 0 || brIdx === 0 || brIdx === 15 || srIdx === 3) return null;
  const layer = 4 - layerBits;
  const table = ver === 3 ? BITRATES['V1L' + layer] : (layer === 1 ? BITRATES.V2L1 : BITRATES.V2L23);
  const bitrate = table[brIdx - 1], sampleRate = RATES[ver][srIdx];
  const samples = layer === 1 ? 384 : (layer === 3 && ver !== 3 ? 576 : 1152);
  const len = layer === 1 ? (Math.floor(12 * bitrate * 1000 / sampleRate) + pad) * 4
    : Math.floor((samples / 8) * bitrate * 1000 / sampleRate) + pad;
  return { ver, layer, bitrate, sampleRate, samples, len, mono: chMode === 3 };
}

/** @param buf whole file (or a large head chunk), @param start offset after ID3v2, @param fileSize total bytes */
function info(buf, start, fileSize) {
  let o = start, h = null;
  const limit = Math.min(buf.length - 4, start + 256 * 1024);
  for (; o < limit; o++) {
    h = parseHeader(buf, o);
    if (h && parseHeader(buf, o + h.len)) break; // require a second frame to confirm sync
    h = null;
  }
  if (!h) return { duration: 0, bitrate: 0, sampleRate: 0 };
  const sideInfo = h.ver === 3 ? (h.mono ? 17 : 32) : (h.mono ? 9 : 17);
  const x = o + 4 + sideInfo;
  const tag = buf.toString('latin1', x, x + 4);
  let audioBytes = fileSize - o;
  if (buf.length >= 128 && fileSize === buf.length && buf.toString('latin1', fileSize - 128, fileSize - 125) === 'TAG') audioBytes -= 128;
  if (tag === 'Xing' || tag === 'Info') {
    const flags = buf.readUInt32BE(x + 4); let p = x + 8, frames = 0, bytes = 0;
    if (flags & 1) { frames = buf.readUInt32BE(p); p += 4; }
    if (flags & 2) { bytes = buf.readUInt32BE(p); p += 4; }
    if (frames) {
      const duration = frames * h.samples / h.sampleRate;
      const vbr = tag === 'Xing';
      return { duration, bitrate: vbr ? Math.round((bytes || audioBytes) * 8 / duration / 1000) : h.bitrate, sampleRate: h.sampleRate, vbr };
    }
  }
  if (buf.toString('latin1', o + 36, o + 40) === 'VBRI') {
    const bytes = buf.readUInt32BE(o + 36 + 10), frames = buf.readUInt32BE(o + 36 + 14);
    const duration = frames * h.samples / h.sampleRate;
    return { duration, bitrate: Math.round(bytes * 8 / duration / 1000), sampleRate: h.sampleRate, vbr: true };
  }
  return { duration: audioBytes * 8 / (h.bitrate * 1000), bitrate: h.bitrate, sampleRate: h.sampleRate, vbr: false };
}

module.exports = { info, parseHeader };
