'use strict';
// Format dispatch + safe file writing for tag edits.
const fs = require('fs');
const { fromSeratoMarkers2 } = require('../cues');
const path = require('path');
const id3 = require('./id3');
const mpeg = require('./mpeg');
const flac = require('./flac');
const mp4 = require('./mp4');
const riff = require('./riff');

const AUDIO_EXT = new Set(['.mp3', '.flac', '.m4a', '.mp4', '.aac', '.alac', '.aif', '.aiff', '.wav']);
const FIELDS = ['title', 'artist', 'album', 'genre', 'comment', 'bpm', 'key', 'year', 'rating', 'label', 'remixer', 'composer', 'grouping', 'trackNumber', 'mix'];

function openReader(file) {
  const fd = fs.openSync(file, 'r'); const size = fs.fstatSync(fd).size;
  const readAt = (pos, len) => { len = Math.max(0, Math.min(len, size - pos)); const b = Buffer.alloc(len); let got = 0; while (got < len) { const n = fs.readSync(fd, b, got, len - got, pos + got); if (!n) break; got += n; } return b.subarray(0, got); };
  return { fd, size, readAt, close: () => fs.closeSync(fd) };
}

function detect(file, head) {
  const ext = path.extname(file).toLowerCase();
  if (head.toString('latin1', 0, 4) === 'fLaC') return 'flac';
  const r = riff.kind(head); if (r) return r;
  if (head.toString('latin1', 4, 8) === 'ftyp') return 'mp4';
  if (head.toString('latin1', 0, 3) === 'ID3') {
    // ID3 in front of FLAC happens; otherwise assume MPEG
    if (ext === '.flac') return 'flac';
    return 'mp3';
  }
  if (head[0] === 0xff && (head[1] & 0xe0) === 0xe0) return 'mp3';
  if (ext === '.mp3') return 'mp3';
  return null;
}

/** Read tags + stream info. Returns { format, fields, duration, bitrate, sampleRate, size }. */
function readTags(file) {
  const r = openReader(file);
  try {
    const head = r.readAt(0, 64); const format = detect(file, head);
    if (!format) throw new Error('Unsupported or unrecognised audio file');
    let res;
    if (format === 'mp3') {
      let tagSize = 0, fields = {};
      if (head.toString('latin1', 0, 3) === 'ID3') {
        tagSize = 10 + (((head[6] & 0x7f) << 21) | ((head[7] & 0x7f) << 14) | ((head[8] & 0x7f) << 7) | (head[9] & 0x7f)) + ((head[5] & 0x10) ? 10 : 0);
        const t = id3.parse(r.readAt(0, tagSize), 0); fields = id3.toFields(t);
      }
      const buf = r.readAt(0, tagSize + 128 * 1024);
      const inf = mpeg.info(buf, tagSize, r.size);
      res = { fields, ...inf };
    } else if (format === 'flac') {
      let n = 512 * 1024; let out;
      for (;;) { out = flac.read(r.readAt(0, n)); if (!out || !out.needBytes || n >= r.size) break; n = Math.max(out.needBytes, n * 2); }
      if (!out || out.needBytes) throw new Error('Could not read FLAC metadata');
      res = { ...out, bitrate: out.duration ? Math.round(r.size * 8 / out.duration / 1000) : 0 };
    } else if (format === 'mp4') res = mp4.read(r.readAt, r.size);
    else res = riff.read(r.readAt, r.size);
    if (!res) throw new Error('Could not read ' + format + ' file');
    const fields = {}; for (const k of FIELDS) if (res.fields[k] !== undefined && res.fields[k] !== '') fields[k] = res.fields[k];
    let cues = []; try { cues = res.fields.__serato ? fromSeratoMarkers2(res.fields.__serato) : []; } catch { cues = []; }
    return { format, fields, cues, duration: res.duration || 0, bitrate: res.bitrate || 0, sampleRate: res.sampleRate || 0, size: r.size };
  } finally { r.close(); }
}

/** Execute a write plan safely. */
function applyPlan(file, r, plan) {
  if (plan.inPlace) { // same-size overwrite
    const fd = fs.openSync(file, 'r+'); try { fs.writeSync(fd, plan.inPlace, 0, plan.inPlace.length, plan.at); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    return 'in-place';
  }
  const segs = plan.segments;
  const first = segs[0];
  if (first && !Buffer.isBuffer(first) && first.from === 0 && segs.slice(1).every(Buffer.isBuffer)) {
    // Only the tail changes: write after `first.to` and truncate.
    const tail = Buffer.concat(segs.slice(1));
    const fd = fs.openSync(file, 'r+');
    try {
      fs.writeSync(fd, tail, 0, tail.length, first.to); fs.ftruncateSync(fd, first.to + tail.length);
      for (const p of plan.patches || []) fs.writeSync(fd, p.buf, 0, p.buf.length, p.at);
      fs.fsyncSync(fd);
    } finally { fs.closeSync(fd); }
    return 'tail';
  }
  const tmp = path.join(path.dirname(file), `.${path.basename(file)}.crate-tmp`);
  const out = fs.openSync(tmp, 'w');
  try {
    let pos = 0; const CH = 1 << 20; const chunk = Buffer.alloc(CH);
    for (const s of segs) {
      if (Buffer.isBuffer(s)) { fs.writeSync(out, s, 0, s.length, pos); pos += s.length; continue; }
      const end = s.to === undefined ? r.size : s.to;
      for (let p = s.from; p < end; p += CH) {
        const n = fs.readSync(r.fd, chunk, 0, Math.min(CH, end - p), p);
        fs.writeSync(out, chunk, 0, n, pos); pos += n;
      }
    }
    for (const p of plan.patches || []) fs.writeSync(out, p.buf, 0, p.buf.length, p.at);
    fs.fsyncSync(out);
  } catch (e) { fs.closeSync(out); fs.rmSync(tmp, { force: true }); throw e; }
  fs.closeSync(out);
  try { fs.chmodSync(tmp, fs.statSync(file).mode); } catch { /* ignore */ }
  fs.renameSync(tmp, file);
  return 'rewrite';
}

/**
 * Write the given fields into the file's tags. Only keys present in `fields` are changed;
 * set a key to '' or 0 to clear it. Returns how the file was written.
 */
function writeTags(file, fields) {
  const clean = {}; for (const k of FIELDS) if (k in fields) clean[k] = fields[k];
  const r = openReader(file);
  try {
    const head = r.readAt(0, 64); const format = detect(file, head);
    if (!format) throw new Error('Unsupported or unrecognised audio file');
    let plan;
    if (format === 'mp3') {
      let existing = null, oldSize = 0;
      if (head.toString('latin1', 0, 3) === 'ID3') {
        oldSize = 10 + (((head[6] & 0x7f) << 21) | ((head[7] & 0x7f) << 14) | ((head[8] & 0x7f) << 7) | (head[9] & 0x7f)) + ((head[5] & 0x10) ? 10 : 0);
        existing = id3.parse(r.readAt(0, oldSize), 0);
        if (existing && existing.version === 4 && (existing.flags & 0x10)) existing = { ...existing, flags: existing.flags & ~0x10 };
      }
      const fitted = existing ? id3.build(existing, clean, oldSize) : null;
      if (fitted && fitted.length === oldSize) plan = { inPlace: fitted, at: 0 };
      else { // new tag + 2 KB padding so later edits can happen in place
        const bare = id3.build(existing, clean, 0);
        plan = { segments: [id3.build(existing, clean, bare.length + 2048), { from: oldSize }] };
      }
    } else if (format === 'flac') {
      let n = 512 * 1024; let w;
      for (;;) { w = flac.write(r.readAt(0, n), clean); if (!w.needBytes || n >= r.size) break; n = Math.max(w.needBytes, n * 2); }
      if (w.needBytes) throw new Error('Could not read FLAC metadata');
      plan = w;
    } else if (format === 'mp4') plan = mp4.write(r.readAt, r.size, clean);
    else plan = riff.write(r.readAt, r.size, clean);
    return applyPlan(file, r, plan);
  } finally { r.close(); }
}

module.exports = { readTags, writeTags, AUDIO_EXT, FIELDS };
