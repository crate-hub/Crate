'use strict';
// ID3v2.2 / 2.3 / 2.4 reader and writer (v2.3 or v2.4 output).
// Frames we don't manage (artwork, Serato GEOB data, PRIV, ...) are preserved byte-for-byte.

const GENRES = ['Blues', 'Classic Rock', 'Country', 'Dance', 'Disco', 'Funk', 'Grunge', 'Hip-Hop', 'Jazz', 'Metal',
  'New Age', 'Oldies', 'Other', 'Pop', 'R&B', 'Rap', 'Reggae', 'Rock', 'Techno', 'Industrial', 'Alternative', 'Ska',
  'Death Metal', 'Pranks', 'Soundtrack', 'Euro-Techno', 'Ambient', 'Trip-Hop', 'Vocal', 'Jazz+Funk', 'Fusion',
  'Trance', 'Classical', 'Instrumental', 'Acid', 'House', 'Game', 'Sound Clip', 'Gospel', 'Noise', 'AlternRock',
  'Bass', 'Soul', 'Punk', 'Space', 'Meditative', 'Instrumental Pop', 'Instrumental Rock', 'Ethnic', 'Gothic',
  'Darkwave', 'Techno-Industrial', 'Electronic', 'Pop-Folk', 'Eurodance', 'Dream', 'Southern Rock', 'Comedy',
  'Cult', 'Gangsta', 'Top 40', 'Christian Rap', 'Pop/Funk', 'Jungle', 'Native American', 'Cabaret', 'New Wave',
  'Psychadelic', 'Rave', 'Showtunes', 'Trailer', 'Lo-Fi', 'Tribal', 'Acid Punk', 'Acid Jazz', 'Polka', 'Retro',
  'Musical', 'Rock & Roll', 'Hard Rock'];

// Our field name -> frame id (v2.3/2.4). Year is TYER in 2.3, TDRC in 2.4.
const TEXT_FRAMES = {
  title: 'TIT2', artist: 'TPE1', album: 'TALB', genre: 'TCON', bpm: 'TBPM', key: 'TKEY',
  label: 'TPUB', remixer: 'TPE4', composer: 'TCOM', grouping: 'TIT1', trackNumber: 'TRCK', mix: 'TIT3',
};
const V22_MAP = { TT2: 'TIT2', TP1: 'TPE1', TAL: 'TALB', TCO: 'TCON', TBP: 'TBPM', TKE: 'TKEY', TPB: 'TPUB',
  TP4: 'TPE4', TCM: 'TCOM', TT1: 'TIT1', TRK: 'TRCK', TT3: 'TIT3', TYE: 'TYER', COM: 'COMM', POP: 'POPM' };
// TXXX descriptions other taggers use; read as fallbacks, removed when the field is written.
const TXXX_ALIASES = { COMMENT: 'comment', INITIALKEY: 'key', KEY: 'key', LABEL: 'label', PUBLISHER: 'label', REMIXER: 'remixer', MIXARTIST: 'remixer', BPM: 'bpm', GROUPING: 'grouping' };
const MANAGED = new Set([...Object.values(TEXT_FRAMES), 'TYER', 'TDRC', 'COMM', 'POPM', 'GRP1']);

function synchsafeRead(b, o) { return ((b[o] & 0x7f) << 21) | ((b[o + 1] & 0x7f) << 14) | ((b[o + 2] & 0x7f) << 7) | (b[o + 3] & 0x7f); }
function synchsafeBytes(n) { return Buffer.from([(n >> 21) & 0x7f, (n >> 14) & 0x7f, (n >> 7) & 0x7f, n & 0x7f]); }
function removeUnsync(buf) {
  const out = []; for (let i = 0; i < buf.length; i++) { out.push(buf[i]); if (buf[i] === 0xff && buf[i + 1] === 0x00) i++; }
  return Buffer.from(out);
}

function decodeText(enc, b) {
  let s;
  if (enc === 0) s = b.toString('latin1');
  else if (enc === 3) s = b.toString('utf8');
  else if (enc === 1 || enc === 2) {
    let le = enc === 1, o = 0;
    if (enc === 1 && b.length >= 2) { if (b[0] === 0xfe && b[1] === 0xff) { le = false; o = 2; } else if (b[0] === 0xff && b[1] === 0xfe) { le = true; o = 2; } }
    let body = b.subarray(o); if (body.length % 2) body = body.subarray(0, body.length - 1);
    if (!le) { body = Buffer.from(body); body.swap16(); }
    s = body.toString('utf16le');
    // UTF-16 multi-value: each value may restart with a BOM
    s = s.replace(/﻿/g, '');
  } else s = b.toString('latin1');
  return s;
}
function splitTerminated(enc, b) { // returns [first, rest]
  const wide = enc === 1 || enc === 2;
  if (!wide) { const i = b.indexOf(0); return i < 0 ? [b, Buffer.alloc(0)] : [b.subarray(0, i), b.subarray(i + 1)]; }
  for (let i = 0; i + 1 < b.length; i += 2) if (b[i] === 0 && b[i + 1] === 0) return [b.subarray(0, i), b.subarray(i + 2)];
  return [b, Buffer.alloc(0)];
}
function textValues(data) {
  const enc = data[0]; const s = decodeText(enc, data.subarray(1));
  return s.split('\u0000').map(v => v.trim()).filter(Boolean);
}
function encodeText(str, version) {
  if (version === 4) return Buffer.concat([Buffer.from([3]), Buffer.from(str, 'utf8')]);
  if (/^[\x00-\xff]*$/.test(str)) return Buffer.concat([Buffer.from([0]), Buffer.from(str, 'latin1')]);
  return Buffer.concat([Buffer.from([1, 0xff, 0xfe]), Buffer.from(str, 'utf16le')]);
}

function cleanGenre(g) {
  // "(17)", "(17)Rock", "17", "(RX)" forms from ID3v1-era taggers
  return g.replace(/^\((\d+)\)(.*)$/, (_, n, rest) => rest || GENRES[+n] || '')
    .replace(/^(\d+)$/, (_, n) => GENRES[+n] || n);
}
function popmToStars(r) { if (!r) return 0; if (r < 32) return 1; if (r < 96) return 2; if (r < 160) return 3; if (r < 224) return 4; return 5; }
const STARS_TO_POPM = [0, 1, 64, 128, 196, 255];

/** Parse an ID3v2 tag starting at `off` in `buf`. Returns null if none. */
function parse(buf, off = 0) {
  if (buf.length < off + 10 || buf.toString('latin1', off, off + 3) !== 'ID3') return null;
  const version = buf[off + 3], flags = buf[off + 5];
  const size = synchsafeRead(buf, off + 6);
  const total = 10 + size + (version === 4 && (flags & 0x10) ? 10 : 0);
  let body = buf.subarray(off + 10, off + 10 + size);
  if (version < 4 && (flags & 0x80)) body = removeUnsync(body);
  let p = 0;
  if (flags & 0x40) { // extended header
    p = version === 4 ? synchsafeRead(body, 0) : body.readUInt32BE(0) + 4;
  }
  const frames = [];
  const idLen = version === 2 ? 3 : 4, hdrLen = version === 2 ? 6 : 10;
  while (p + hdrLen <= body.length) {
    const id = body.toString('latin1', p, p + idLen);
    if (!/^[A-Z0-9]{3,4}$/.test(id)) break; // padding
    let fsize, fflags = 0;
    if (version === 2) fsize = body.readUIntBE(p + 3, 3);
    else if (version === 4) { fsize = synchsafeRead(body, p + 4); fflags = body.readUInt16BE(p + 8); }
    else { fsize = body.readUInt32BE(p + 4); fflags = body.readUInt16BE(p + 8); }
    // Some v2.4 writers wrongly use plain sizes; fall back if synchsafe size overruns.
    if (version === 4 && p + hdrLen + fsize > body.length) { const alt = body.readUInt32BE(p + 4); if (p + hdrLen + alt <= body.length) fsize = alt; }
    if (fsize <= 0 || p + hdrLen + fsize > body.length) break;
    frames.push({ id, flags: fflags, data: body.subarray(p + hdrLen, p + hdrLen + fsize) });
    p += hdrLen + fsize;
  }
  return { version, flags, size: total, frames };
}

/** Frame payload with v2.4 per-frame unsync / data-length indicator handled. */
function framePayload(f, version) {
  let d = f.data;
  if (version === 4) {
    if (f.flags & 0x0001) d = d.subarray(4);
    if (f.flags & 0x0002) d = removeUnsync(d);
    if (f.flags & 0x000c) return null; // compressed/encrypted: not readable
  } else if (version === 3 && (f.flags & 0x00c0)) return null;
  return d;
}

/** Tag object -> our field model. */
function toFields(tag) {
  const out = {}; const fallback = {};
  if (!tag) return out;
  const v = tag.version;
  for (const f of tag.frames) {
    const id = v === 2 ? V22_MAP[f.id] : f.id;
    if (!id) continue;
    const d = framePayload(f, v);
    if (!d || !d.length) continue;
    if (id === 'TXXX') {
      const enc = d[0]; const [desc, val] = splitTerminated(enc, d.subarray(1));
      const field = TXXX_ALIASES[decodeText(enc, desc).trim().toUpperCase()];
      if (field && !(field in fallback)) fallback[field] = decodeText(enc, val).replace(/\u0000+$/, '').trim();
      continue;
    }
    if (id === 'GEOB') { // general object: Serato keeps its cue points in "Serato Markers2"
      const enc = d[0]; const mimeEnd = d.indexOf(0, 1); if (mimeEnd < 0) continue;
      const [, afterFile] = splitTerminated(enc, d.subarray(mimeEnd + 1));
      const [desc, data] = splitTerminated(enc, afterFile);
      if (decodeText(enc, desc) === 'Serato Markers2') out.__serato = Buffer.from(data);
      continue;
    }
    if (id === 'COMM') {
      const enc = d[0]; const [desc, text] = splitTerminated(enc, d.subarray(4));
      const descS = decodeText(enc, desc);
      if (out.comment === undefined || descS === '') {
        if (!/^(iTun|ID3v1)/.test(descS)) out.comment = decodeText(enc, text).replace(/\u0000+$/, '').trim();
      }
    } else if (id === 'POPM') {
      const [, rest] = splitTerminated(0, d); if (rest.length) out.rating = popmToStars(rest[0]);
    } else if (id === 'TYER' || id === 'TDRC') {
      const y = parseInt(textValues(d)[0], 10); if (y > 0) out.year = y;
    } else if (id === 'GRP1') { out.grouping = out.grouping || textValues(d).join(', '); }
    else {
      const field = Object.keys(TEXT_FRAMES).find(k => TEXT_FRAMES[k] === id);
      if (!field) continue;
      let val = textValues(d).join(', ');
      if (field === 'genre') val = textValues(d).map(cleanGenre).filter(Boolean).join(', ');
      if (field === 'bpm') { const n = parseFloat(val); if (n > 0) out.bpm = n; continue; }
      if (field === 'trackNumber') { const n = parseInt(val, 10); if (n > 0) out.trackNumber = n; continue; }
      out[field] = val;
    }
  }
  for (const [field, val] of Object.entries(fallback)) {
    if (out[field] !== undefined || !val) continue;
    if (field === 'bpm') { const n = parseFloat(val); if (n > 0) out.bpm = n; } else out[field] = val;
  }
  return out;
}

function frameBytes(id, data, version, flags = 0) {
  const h = Buffer.alloc(10); h.write(id, 0, 'latin1');
  if (version === 4) synchsafeBytes(data.length).copy(h, 4); else h.writeUInt32BE(data.length, 4);
  h.writeUInt16BE(flags, 8);
  return Buffer.concat([h, data]);
}

/**
 * Build a new tag: existing unmanaged frames kept, managed frames rebuilt from `fields`
 * (fields not present in `fields` keep their current value).
 */
function build(existing, fields, padTo = 0) {
  const version = existing && (existing.version === 3 || existing.version === 4) ? existing.version : 3;
  const current = toFields(existing);
  const merged = { ...current, ...fields };
  const parts = [];
  if (existing && existing.version !== 2) {
    for (const f of existing.frames) {
      if (f.id === 'TXXX') {
        const d = framePayload(f, version);
        if (d) { const [desc] = splitTerminated(d[0], d.subarray(1)); const fld = TXXX_ALIASES[decodeText(d[0], desc).trim().toUpperCase()]; if (fld && fld in fields) continue; }
      }
      if (MANAGED.has(f.id)) {
        // keep COMM frames that carry a description (e.g. iTunNORM) and POPM from other players' emails? we own POPM.
        if (f.id === 'COMM') { const d = framePayload(f, version); if (d) { const [desc] = splitTerminated(d[0], d.subarray(4)); if (decodeText(d[0], desc) !== '') { parts.push(frameBytes(f.id, f.data, version, f.flags)); } } }
        continue;
      }
      parts.push(frameBytes(f.id, f.data, version, f.flags));
    }
  }
  for (const [field, id] of Object.entries(TEXT_FRAMES)) {
    const val = merged[field];
    if (val === undefined || val === null || val === '' || (typeof val === 'number' && !(val > 0))) continue;
    const s = field === 'bpm' ? String(Math.round(Number(val) * 100) / 100) : String(val);
    parts.push(frameBytes(id, encodeText(s, version), version));
  }
  if (merged.year > 0) parts.push(frameBytes(version === 4 ? 'TDRC' : 'TYER', encodeText(String(merged.year), version), version));
  if (merged.comment) {
    const t = encodeText(merged.comment, version);
    const term = t[0] === 1 || t[0] === 2 ? Buffer.from([0xff, 0xfe, 0, 0]) : Buffer.from([0]);
    parts.push(frameBytes('COMM', Buffer.concat([t.subarray(0, 1), Buffer.from('eng'), term, t.subarray(1)]), version));
  }
  if (merged.rating > 0) {
    parts.push(frameBytes('POPM', Buffer.concat([Buffer.from('Windows Media Player 9 Series\u0000', 'latin1'), Buffer.from([STARS_TO_POPM[Math.min(5, Math.round(merged.rating))]])]), version));
  }
  const body = Buffer.concat(parts);
  const size = Math.max(body.length, padTo - 10);
  const header = Buffer.from([0x49, 0x44, 0x33, version, 0, 0]);
  return Buffer.concat([header, synchsafeBytes(size), body, Buffer.alloc(size - body.length)]);
}

module.exports = { parse, toFields, build, GENRES };
