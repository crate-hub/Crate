'use strict';
// WAV (RIFF, little-endian) and AIFF/AIFC (IFF, big-endian): stream info + ID3 chunk read/write.
// WAV LIST/INFO tags are read as a fallback.
const id3 = require('./id3');

function kind(head) {
  const a = head.toString('latin1', 0, 4), b = head.toString('latin1', 8, 12);
  if (a === 'RIFF' && b === 'WAVE') return 'wav';
  if (a === 'FORM' && (b === 'AIFF' || b === 'AIFC')) return 'aiff';
  return null;
}

function chunks(readAt, size, le) {
  const out = []; let p = 12;
  while (p + 8 <= size) {
    const h = readAt(p, 8); const id = h.toString('latin1', 0, 4);
    const len = le ? h.readUInt32LE(4) : h.readUInt32BE(4);
    out.push({ id, start: p, dataStart: p + 8, len });
    p += 8 + len + (len & 1);
  }
  return out;
}

function ext80(b) { // IEEE 754 80-bit extended -> number
  const exp = ((b[0] & 0x7f) << 8) | b[1]; const hi = b.readUInt32BE(2), lo = b.readUInt32BE(6);
  if (!exp && !hi && !lo) return 0;
  return (hi * 2 ** 32 + lo) * 2 ** (exp - 16383 - 63) * (b[0] & 0x80 ? -1 : 1);
}

const INFO = { INAM: 'title', IART: 'artist', IPRD: 'album', IGNR: 'genre', ICMT: 'comment', ICRD: 'year', ITRK: 'trackNumber' };

function read(readAt, size) {
  const k = kind(readAt(0, 12)); if (!k) return null;
  const le = k === 'wav'; const cs = chunks(readAt, size, le);
  let duration = 0, sampleRate = 0, bitrate = 0, fields = {};
  if (le) {
    const fmt = cs.find(c => c.id === 'fmt '), data = cs.find(c => c.id === 'data');
    if (fmt) { const f = readAt(fmt.dataStart, 16); sampleRate = f.readUInt32LE(4); const byteRate = f.readUInt32LE(8); bitrate = Math.round(byteRate * 8 / 1000); if (data && byteRate) duration = data.len / byteRate; }
    const list = cs.find(c => c.id === 'LIST' && readAt(c.dataStart, 4).toString('latin1') === 'INFO');
    if (list) {
      const b = readAt(list.dataStart, list.len); let p = 4;
      while (p + 8 <= b.length) {
        const id = b.toString('latin1', p, p + 4), l = b.readUInt32LE(p + 4);
        const v = b.toString('utf8', p + 8, p + 8 + l).replace(/\u0000+$/, '').trim();
        const f = INFO[id];
        if (f && v) { if (f === 'year' || f === 'trackNumber') { const n = parseInt(v, 10); if (n > 0) fields[f] = n; } else fields[f] = v; }
        p += 8 + l + (l & 1);
      }
    }
  } else {
    const comm = cs.find(c => c.id === 'COMM');
    if (comm) { const c = readAt(comm.dataStart, 18); const ch = c.readInt16BE(0), frames = c.readUInt32BE(2), bits = c.readInt16BE(6); sampleRate = Math.round(ext80(c.subarray(8, 18))); if (sampleRate) { duration = frames / sampleRate; bitrate = Math.round(sampleRate * ch * bits / 1000); } }
  }
  // Once an ID3 chunk exists it is authoritative (our writer merges LIST/INFO into it on first write).
  const tagChunk = cs.find(c => c.id === 'id3 ' || c.id === 'ID3 ');
  if (tagChunk) { const t = id3.parse(readAt(tagChunk.dataStart, tagChunk.len), 0); if (t) fields = id3.toFields(t); }
  return { fields, duration, sampleRate, bitrate };
}

/** Returns a write plan: { segments, patches? } */
function write(readAt, size, fields) {
  const k = kind(readAt(0, 12)); if (!k) throw new Error('Not a WAV/AIFF file');
  const le = k === 'wav'; const cs = chunks(readAt, size, le);
  const old = cs.find(c => c.id === 'id3 ' || c.id === 'ID3 ');
  const existing = old ? id3.parse(readAt(old.dataStart, old.len), 0) : null;
  // First ID3 write on a WAV: carry LIST/INFO values over so nothing is lost.
  const base = !existing && le ? read(readAt, size).fields : {};
  const tag = id3.build(existing, { ...base, ...fields }, 0);
  const pad = tag.length & 1 ? Buffer.alloc(1) : Buffer.alloc(0);
  const hdr = Buffer.alloc(8); hdr.write(le ? 'id3 ' : 'ID3 ', 0, 'latin1');
  le ? hdr.writeUInt32LE(tag.length, 4) : hdr.writeUInt32BE(tag.length, 4);
  const chunk = Buffer.concat([hdr, tag, pad]);
  const sizeBuf = (n) => { const b = Buffer.alloc(4); le ? b.writeUInt32LE(n) : b.writeUInt32BE(n); return b; };
  const lastEnd = cs.length ? cs[cs.length - 1].start + 8 + cs[cs.length - 1].len + (cs[cs.length - 1].len & 1) : 12;
  if (!old || old === cs[cs.length - 1]) {
    // Tag chunk is last (or absent): rewrite the tail in place.
    const at = old ? old.start : Math.min(lastEnd, size);
    return { segments: [{ from: 0, to: at }, chunk], patches: [{ at: 4, buf: sizeBuf(at + chunk.length - 8) }] };
  }
  const oldEnd = old.start + 8 + old.len + (old.len & 1);
  const newSize = size - (oldEnd - old.start) + chunk.length;
  return { segments: [readAt(0, 4), sizeBuf(newSize - 8), { from: 8, to: old.start }, { from: oldEnd, to: size }, chunk] };
}

module.exports = { kind, read, write };
