'use strict';
// SQLCipher 4 decryption and encryption (rekordbox 6/7 master.db) using Node's built-in crypto.
// SQLCipher 4 defaults: 4096-byte pages, PBKDF2-HMAC-SHA512 (256,000 iterations) for the key,
// AES-256-CBC per page, 80 reserved bytes per page = 16-byte IV + 64-byte HMAC-SHA512.
// Page 1 begins with the 16-byte KDF salt instead of the "SQLite format 3" header.
const fs = require('fs');
const crypto = require('crypto');

const PAGE = 4096, RESERVE = 80, IV = 16, HMAC = 64, SALT = 16;
const SQLITE_HEADER = Buffer.from('SQLite format 3\u0000', 'latin1');

function isPlainSqlite(file) {
  const fd = fs.openSync(file, 'r'); const b = Buffer.alloc(16);
  try { fs.readSync(fd, b, 0, 16, 0); } finally { fs.closeSync(fd); }
  return b.equals(SQLITE_HEADER);
}

function deriveKeys(passphrase, salt) {
  const key = crypto.pbkdf2Sync(Buffer.from(passphrase, 'utf8'), salt, 256000, 32, 'sha512');
  const hmacSalt = Buffer.from(salt.map(b => b ^ 0x3a));
  const hmacKey = crypto.pbkdf2Sync(key, hmacSalt, 2, 32, 'sha512');
  return { key, hmacKey };
}

/** Decrypt `src` into a plain SQLite file at `dest`. Throws if the key is wrong or the file isn't SQLCipher 4. */
function decryptFile(src, dest, passphrase) {
  const data = fs.readFileSync(src);
  if (data.length < PAGE || data.length % PAGE) throw new Error('This file is not an encrypted rekordbox database (unexpected size).');
  const salt = data.subarray(0, SALT);
  const { key, hmacKey } = deriveKeys(passphrase, salt);
  const out = Buffer.alloc(data.length);
  const pages = data.length / PAGE;
  for (let n = 0; n < pages; n++) {
    const page = data.subarray(n * PAGE, (n + 1) * PAGE);
    const start = n === 0 ? SALT : 0;
    const cipherText = page.subarray(start, PAGE - RESERVE);
    const iv = page.subarray(PAGE - RESERVE, PAGE - RESERVE + IV);
    const mac = page.subarray(PAGE - RESERVE + IV, PAGE - RESERVE + IV + HMAC);
    if (n === 0) { // check the key once, on the first page
      const h = crypto.createHmac('sha512', hmacKey); h.update(page.subarray(start, PAGE - HMAC));
      const pg = Buffer.alloc(4); pg.writeUInt32LE(1); h.update(pg);
      if (!crypto.timingSafeEqual(h.digest(), mac)) throw new Error('Could not unlock the rekordbox database (key or format not recognised).');
    }
    const d = crypto.createDecipheriv('aes-256-cbc', key, iv); d.setAutoPadding(false);
    const plain = Buffer.concat([d.update(cipherText), d.final()]);
    const o = n * PAGE;
    if (n === 0) { SQLITE_HEADER.copy(out, 0); plain.copy(out, SALT); } else plain.copy(out, o);
    // reserved bytes stay zero; the header keeps "80 reserved bytes per page", which SQLite honours
  }
  fs.writeFileSync(dest, out);
  return dest;
}

/**
 * Encrypt the plain SQLite file `src` into `dest` as SQLCipher 4, using the KDF salt of
 * `saltFrom` (the original encrypted file) so the same passphrase opens it. Every page gets a
 * fresh random IV and its HMAC, exactly as SQLCipher writes them. The plain file must keep
 * 4096-byte pages with 80 reserved bytes (a file made by decryptFile does).
 */
function encryptFile(src, dest, passphrase, saltFrom) {
  const data = fs.readFileSync(src);
  if (!data.subarray(0, 16).equals(SQLITE_HEADER)) throw new Error('Not a plain SQLite file.');
  if (data.readUInt16BE(16) !== PAGE || data[20] !== RESERVE) throw new Error('The database must use 4096-byte pages with 80 reserved bytes.');
  if (data.length % PAGE) throw new Error('Unexpected database size.');
  const salt = Buffer.alloc(SALT);
  const fd = fs.openSync(saltFrom, 'r'); try { fs.readSync(fd, salt, 0, SALT, 0); } finally { fs.closeSync(fd); }
  const { key, hmacKey } = deriveKeys(passphrase, salt);
  const out = Buffer.alloc(data.length);
  for (let n = 0; n < data.length / PAGE; n++) {
    const o = n * PAGE; const start = n === 0 ? SALT : 0;
    const iv = crypto.randomBytes(IV);
    const c = crypto.createCipheriv('aes-256-cbc', key, iv); c.setAutoPadding(false);
    const cipherText = Buffer.concat([c.update(data.subarray(o + start, o + PAGE - RESERVE)), c.final()]);
    if (n === 0) salt.copy(out, 0);
    cipherText.copy(out, o + start); iv.copy(out, o + PAGE - RESERVE);
    const h = crypto.createHmac('sha512', hmacKey);
    h.update(out.subarray(o + start, o + PAGE - HMAC)); // ciphertext + IV
    const pg = Buffer.alloc(4); pg.writeUInt32LE(n + 1); h.update(pg);
    h.digest().copy(out, o + PAGE - HMAC);
  }
  fs.writeFileSync(dest, out);
  return dest;
}

module.exports = { decryptFile, encryptFile, isPlainSqlite };
