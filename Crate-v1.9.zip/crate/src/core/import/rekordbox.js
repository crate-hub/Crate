'use strict';
// rekordbox 6/7 library reader: master.db (SQLCipher-encrypted SQLite) + masterPlaylists6.xml.
// Produces a neutral { tracks, tree } description that Library.importExternal() merges.
const fs = require('fs');
const cues = require('../cues');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { decryptFile, isPlainSqlite } = require('./sqlcipher');
const { fromRekordbox } = require('../smartconvert');

// The passphrase rekordbox 6/7 uses for master.db (publicly documented by the open-source pyrekordbox project).
const RB_KEY = '402fd482c38817c35ffa8ffb8c7d93143b749e7d315df7a81732a1ff43608497';

const DEFAULT_DIR = process.platform === 'win32'
  ? path.join(process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming'), 'Pioneer', 'rekordbox')
  : path.join(os.homedir(), 'Library', 'Pioneer', 'rekordbox');

// rekordbox playlist Attribute: 0 = playlist, 1 = folder, 4 = smart playlist, negative = system entries
const ATTR = { PLAYLIST: 0, FOLDER: 1, SMART: 4 };

/** Parse masterPlaylists6.xml -> Map(decimal id string -> { parentId, attribute }) */
function readPlaylistsXml(file) {
  const xml = fs.readFileSync(file, 'utf8');
  const out = new Map();
  for (const m of xml.matchAll(/<NODE\b([^>]*)\/?>/g)) {
    const attrs = Object.fromEntries([...m[1].matchAll(/(\w+)="([^"]*)"/g)].map(a => [a[1], a[2]]));
    if (!attrs.Id) continue;
    const id = BigInt('0x' + attrs.Id).toString();
    out.set(id, { parentId: attrs.ParentId === '0' ? 'root' : BigInt('0x' + attrs.ParentId).toString(), attribute: Number(attrs.Attribute) });
  }
  return out;
}

/** Find master.db (and masterPlaylists6.xml) in a rekordbox folder. */
function locate(dir = DEFAULT_DIR) {
  const dbFile = path.join(dir, 'master.db');
  if (!fs.existsSync(dbFile)) return { ok: false, dir, reason: `No rekordbox library (master.db) found in ${dir}. Choose the folder that contains master.db.` };
  const xmlFile = path.join(dir, 'masterPlaylists6.xml');
  const wal = dbFile + '-wal';
  const running = fs.existsSync(wal) && fs.statSync(wal).size > 0;
  return { ok: true, dir, dbFile, xmlFile: fs.existsSync(xmlFile) ? xmlFile : null, unsavedChanges: running };
}

/** Open (decrypting to a temp copy) and return a read-only DatabaseSync plus a cleanup function. */
function open(dbFile) {
  const tmp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'crate-rb-')), 'master.db');
  if (isPlainSqlite(dbFile)) fs.copyFileSync(dbFile, tmp); else decryptFile(dbFile, tmp, RB_KEY);
  const db = new DatabaseSync(tmp, { readOnly: true });
  return { db, close: () => { try { db.close(); } finally { fs.rmSync(path.dirname(tmp), { recursive: true, force: true }); } } };
}

// Content that ships with rekordbox (sampler one-shots, demo tracks), skipped by default.
const isBundled = (p) => /[\\/]PioneerDJ[\\/](Sampler|Demo Tracks)[\\/]/i.test(p);
const notDeleted = (alias) => `IFNULL(${alias}.rb_local_deleted, 0) = 0`;

/**
 * Read the library. Returns { tracks: [{ sourceId, path, fields, duration, ... }], tree, stats }.
 * opts.includeBundled: also import rekordbox's own sampler sounds and demo tracks (off by default).
 */
function read({ dir = DEFAULT_DIR, includeBundled = false, skipFolders = [] } = {}) {
  const loc = locate(dir); if (!loc.ok) throw new Error(loc.reason);
  const xml = loc.xmlFile ? readPlaylistsXml(loc.xmlFile) : null;
  const { db, close } = open(loc.dbFile);
  try {
    const rows = db.prepare(`
      SELECT c.ID, c.FolderPath, c.Title, a.Name AS artist, al.Name AS album, g.Name AS genre, k.ScaleName AS keyName,
             l.Name AS label, r.Name AS remixer, cp.Name AS composer, c.BPM, c.Length, c.Rating, c.ReleaseYear, c.Commnt,
             c.TrackNo, c.BitRate, c.SampleRate, c.FileSize, c.Subtitle, c.StockDate, c.DateCreated, c.created_at
      FROM djmdContent c
      LEFT JOIN djmdArtist a ON a.ID = c.ArtistID
      LEFT JOIN djmdAlbum al ON al.ID = c.AlbumID
      LEFT JOIN djmdGenre g ON g.ID = c.GenreID
      LEFT JOIN djmdKey k ON k.ID = c.KeyID
      LEFT JOIN djmdLabel l ON l.ID = c.LabelID
      LEFT JOIN djmdArtist r ON r.ID = c.RemixerID
      LEFT JOIN djmdArtist cp ON cp.ID = c.ComposerID
      WHERE ${notDeleted('c')} AND IFNULL(c.FolderPath, '') != ''`).all();
    const stats = { tracks: 0, bundledSkipped: 0, playlists: 0, folders: 0, smartlists: 0, smartSkipped: 0, smartSkippedList: [], notInXml: 0, cueTracks: 0, cues: 0 };
    const tracks = [];
    // Cue points (hot cues, memory cues and loops) live in djmdCue.
    const cuesBy = new Map();
    if (db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'djmdCue'").get()) {
      const ccols = new Set(db.prepare('PRAGMA table_info(djmdCue)').all().map(c => c.name));
      const cc = (c) => ccols.has(c) ? c : `NULL AS ${c}`;
      for (const q of db.prepare(`SELECT ContentID, ${cc('InMsec')}, ${cc('OutMsec')}, ${cc('Kind')}, ${cc('Color')}, ${cc('ColorTableIndex')}, ${cc('Comment')}
          FROM djmdCue WHERE ${ccols.has('rb_local_deleted') ? 'IFNULL(rb_local_deleted, 0) = 0' : '1'} ORDER BY ContentID, InMsec`).all()) {
        const id = String(q.ContentID); if (!cuesBy.has(id)) cuesBy.set(id, []);
        cuesBy.get(id).push(cues.fromRekordboxRow(q));
      }
    }
    for (const r of rows) {
      if (!includeBundled && isBundled(r.FolderPath)) { stats.bundledSkipped++; continue; }
      const date = r.StockDate || r.DateCreated || r.created_at;
      tracks.push({
        sourceId: String(r.ID), path: r.FolderPath,
        fields: {
          title: r.Title || '', artist: r.artist || '', album: r.album || '', genre: r.genre || '', key: r.keyName || '',
          label: r.label || '', remixer: r.remixer || '', composer: r.composer || '', comment: r.Commnt || '', mix: r.Subtitle || '',
          bpm: r.BPM ? r.BPM / 100 : 0, rating: Math.max(0, Math.min(5, r.Rating || 0)), year: r.ReleaseYear || 0, trackNumber: r.TrackNo || 0,
        },
        duration: r.Length || 0, bitrate: r.BitRate || 0, sampleRate: r.SampleRate || 0, size: r.FileSize || 0,
        dateAdded: date && !Number.isNaN(Date.parse(date)) ? new Date(date).toISOString() : null,
        cues: cues.normalize(cuesBy.get(String(r.ID)) || []),
      });
      const n = tracks[tracks.length - 1].cues.length; if (n) { stats.cueTracks++; stats.cues += n; }
    }
    stats.tracks = tracks.length;
    const known = new Set(tracks.map(t => t.sourceId));

    // Playlists. masterPlaylists6.xml (when present) is rekordbox's own list of what exists;
    // master.db can still hold entries for deleted or cloud-only lists.
    const pls = db.prepare(`SELECT ID, Name, Attribute, ParentID, Seq, SmartList FROM djmdPlaylist p WHERE ${notDeleted('p')} ORDER BY Seq, ID`).all();
    const byParent = new Map();
    for (const p of pls) {
      const id = String(p.ID);
      if (p.Attribute < 0) continue; // system entries
      if (xml && !xml.has(id)) { stats.notInXml++; continue; }
      if (p.Attribute === ATTR.SMART) {
        const conv = fromRekordbox(p.SmartList);
        if (conv.error) { stats.smartSkipped++; stats.smartSkippedList.push({ name: p.Name, reason: conv.error }); continue; }
        p.rules = conv.rules;
      } else if (p.Attribute !== ATTR.PLAYLIST && p.Attribute !== ATTR.FOLDER) continue;
      const parent = String(p.ParentID || 'root');
      if (!byParent.has(parent)) byParent.set(parent, []);
      byParent.get(parent).push(p);
    }
    const songs = db.prepare(`SELECT ContentID FROM djmdSongPlaylist s WHERE s.PlaylistID = ? AND ${notDeleted('s')} ORDER BY TrackNo, ID`);
    const build = (parent) => (byParent.get(parent) || []).map(p => {
      if (p.Attribute === ATTR.FOLDER) { stats.folders++; return { name: p.Name || 'Untitled folder', type: 'folder', children: build(String(p.ID)) }; }
      if (p.Attribute === ATTR.SMART) { stats.smartlists++; return { name: p.Name || 'Untitled smart playlist', type: 'smart', rules: p.rules }; }
      stats.playlists++;
      return { name: p.Name || 'Untitled playlist', type: 'playlist', sourceIds: songs.all(p.ID).map(s => String(s.ContentID)).filter(id => known.has(id)) };
    });
    // Leave out the folder Crate exports into, so a round trip doesn't duplicate playlists.
    const skip = new Set(skipFolders.map(s => String(s).toLowerCase()));
    const top = (byParent.get('root') || []);
    stats.foldersSkipped = top.filter(p => p.Attribute === ATTR.FOLDER && skip.has(String(p.Name || '').toLowerCase())).length;
    byParent.set('root', top.filter(p => !(p.Attribute === ATTR.FOLDER && skip.has(String(p.Name || '').toLowerCase()))));
    const tree = build('root');
    return { source: 'rekordbox', tracks, tree, stats, location: loc };
  } finally { close(); }
}

/** Quick summary for the import dialog. */
function inspect(dir = DEFAULT_DIR, { skipFolders = [] } = {}) {
  const loc = locate(dir); if (!loc.ok) return loc;
  try {
    const r = read({ dir, skipFolders });
    const found = r.tracks.filter(t => fs.existsSync(t.path)).length;
    return { ...loc, ok: true, tracks: r.tracks.length, filesFound: found, playlists: r.stats.playlists, folders: r.stats.folders, smartlists: r.stats.smartlists, smartSkipped: r.stats.smartSkipped, smartSkippedList: r.stats.smartSkippedList, foldersSkipped: r.stats.foldersSkipped, cueTracks: r.stats.cueTracks, cues: r.stats.cues, samplePaths: r.tracks.filter(t => !fs.existsSync(t.path)).slice(0, 3).map(t => t.path) };
  } catch (e) { return { ...loc, ok: false, reason: e.message }; }
}

module.exports = { read, inspect, locate, readPlaylistsXml, DEFAULT_DIR };
