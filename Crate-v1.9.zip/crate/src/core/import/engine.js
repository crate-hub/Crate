'use strict';
// Engine DJ library reader: Engine Library/Database2/m.db.
// Works on a temporary copy, so it's safe even while Engine DJ is open.
const fs = require('fs');
const cues = require('../cues');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const keys = require('../keys');
const { fromEngine } = require('../smartconvert');

const DEFAULT_LIBRARY = path.join(os.homedir(), 'Music', 'Engine Library');

function locate(libraryDir = DEFAULT_LIBRARY) {
  const dbFile = path.join(libraryDir, 'Database2', 'm.db');
  if (!fs.existsSync(dbFile)) return { ok: false, dir: libraryDir, reason: `No Engine Library found in ${libraryDir}. Choose the "Engine Library" folder (the one that contains "Database2").` };
  return { ok: true, dir: libraryDir, dbFile };
}

function open(dbFile) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'crate-engine-'));
  const tmp = path.join(dir, 'm.db');
  fs.copyFileSync(dbFile, tmp);
  for (const ext of ['-wal', '-shm', '-journal']) if (fs.existsSync(dbFile + ext)) fs.copyFileSync(dbFile + ext, tmp + ext);
  const db = new DatabaseSync(tmp); // not read-only: SQLite may need to replay the copied WAL
  return { db, close: () => { try { db.close(); } finally { fs.rmSync(dir, { recursive: true, force: true }); } } };
}

/** Engine key index 0-23 -> Camelot ("8A"). Index = 2*(OpenKey-1) + (minor ? 1 : 0). */
function keyFromEngine(k) {
  if (k === null || k === undefined || k < 0 || k > 23) return '';
  return keys.format(`${Math.floor(k / 2) + 1}${k % 2 ? 'm' : 'd'}`, 'camelot');
}

/** Order rows that form a linked list via `nextField` (0 = last). Unlinked leftovers are appended. */
function chain(rows, nextField) {
  const byId = new Map(rows.map(r => [r.id, r]));
  const pointed = new Set(rows.map(r => r[nextField]).filter(Boolean));
  const out = []; const seen = new Set();
  let cur = rows.find(r => !pointed.has(r.id));
  while (cur && !seen.has(cur.id)) { out.push(cur); seen.add(cur.id); cur = byId.get(cur[nextField]); }
  for (const r of rows) if (!seen.has(r.id)) out.push(r); // tolerate broken chains
  return out;
}

/**
 * Read the library. opts.skipFolders: top-level Engine playlist folder names to leave out
 * (e.g. the folder Crate exports into, so a round trip doesn't duplicate it).
 */
function read({ dir = DEFAULT_LIBRARY, skipFolders = [] } = {}) {
  const loc = locate(dir); if (!loc.ok) throw new Error(loc.reason);
  const { db, close } = open(loc.dbFile);
  try {
    const info = db.prepare('SELECT uuid, schemaVersionMajor AS major, schemaVersionMinor AS minor FROM Information LIMIT 1').get();
    if (!info || info.major < 2) throw new Error('This Engine database is too old (needs Engine DJ 2 or later).');
    const cols = new Set(db.prepare('PRAGMA table_info(Track)').all().map(c => c.name));
    const col = (c, alias = c) => cols.has(c) ? `${c} AS ${alias}` : `NULL AS ${alias}`;
    const rows = db.prepare(`SELECT id, path, ${col('title')}, ${col('artist')}, ${col('album')}, ${col('genre')}, ${col('comment')}, ${col('label')},
      ${col('composer')}, ${col('remixer')}, ${col('key')}, ${col('rating')}, ${col('bpmAnalyzed')}, ${col('bpm')}, ${col('year')}, ${col('length')},
      ${col('bitrate')}, ${col('fileBytes')}, ${col('dateAdded')}, ${col('originDatabaseUuid')} FROM Track`).all();
    const stats = { tracks: 0, streamingSkipped: 0, playlists: 0, folders: 0, foldersSkipped: 0, smartlists: 0, smartSkipped: 0, smartSkippedList: [], cueTracks: 0, cues: 0 };
    const tracks = [];
    // Cue points: quick cues, saved loops and the main cue, in PerformanceData.
    const perf = db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'PerformanceData'").get()
      ? db.prepare('SELECT trackData, quickCues, loops FROM PerformanceData WHERE trackId = ?') : null;
    for (const r of rows) {
      if (!r.path) { stats.streamingSkipped++; continue; } // streaming-only tracks have no file
      const abs = path.resolve(dir, r.path);
      tracks.push({
        sourceId: String(r.id), path: abs,
        fields: {
          title: r.title || path.basename(abs, path.extname(abs)), artist: r.artist || '', album: r.album || '', genre: r.genre || '',
          comment: r.comment || '', label: r.label || '', composer: r.composer || '', remixer: r.remixer || '', key: keyFromEngine(r.key),
          rating: r.rating ? Math.max(0, Math.min(5, Math.round(r.rating / 20))) : 0,
          bpm: r.bpmAnalyzed ? Math.round(r.bpmAnalyzed * 100) / 100 : (r.bpm || 0), year: r.year || 0,
        },
        duration: r.length || 0, bitrate: r.bitrate || 0, size: r.fileBytes || 0,
        dateAdded: r.dateAdded ? new Date(r.dateAdded * 1000).toISOString() : null,
        cues: [],
      });
      if (perf) {
        const t = tracks[tracks.length - 1];
        try { const p = perf.get(r.id); if (p) t.cues = cues.fromEngine(p); } catch { /* damaged blob: no cues */ }
        if (t.cues.length) { stats.cueTracks++; stats.cues += t.cues.length; }
      }
    }
    stats.tracks = tracks.length;
    const known = new Set(tracks.map(t => t.sourceId));

    const pls = db.prepare('SELECT id, title, parentListId, nextListId FROM Playlist').all();
    const children = new Map();
    for (const p of pls) { const k = p.parentListId || 0; if (!children.has(k)) children.set(k, []); children.get(k).push(p); }
    const entities = db.prepare('SELECT id, trackId, nextEntityId, databaseUuid FROM PlaylistEntity WHERE listId = ?');
    // Smartlists (Engine 2.21+) live in their own table, placed by parent path ("Folder;Sub;") and
    // ordered through nextListUuid.
    const smartByPath = new Map();
    const hasSmart = db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'Smartlist'").get();
    if (hasSmart) {
      const rows = db.prepare('SELECT listUuid AS id, title, parentPlaylistPath AS parent, nextListUuid AS next, rules FROM Smartlist').all();
      const byParent = new Map();
      for (const r of rows) { const k = r.parent || ''; if (!byParent.has(k)) byParent.set(k, []); byParent.get(k).push(r); }
      for (const [k, list] of byParent) smartByPath.set(k, chain(list, 'next'));
    }
    const smartNodes = (pathKey) => (smartByPath.get(pathKey) || []).flatMap(r => {
      const conv = fromEngine(r.rules);
      if (conv.error) { stats.smartSkipped++; stats.smartSkippedList.push({ name: r.title, reason: conv.error }); return []; }
      stats.smartlists++; return [{ name: r.title, type: 'smart', rules: conv.rules }];
    });
    const skip = new Set(skipFolders.map(s => s.toLowerCase()));
    const build = (parentId, depth, pathKey) => [...chain(children.get(parentId) || [], 'nextListId').flatMap(p => {
      if (depth === 0 && skip.has(String(p.title).toLowerCase())) { stats.foldersSkipped++; return []; }
      const myPath = `${pathKey}${p.title};`;
      const kids = children.get(p.id) || [];
      // Engine playlists can hold tracks and sub-lists at once; a list with children becomes a folder,
      // and its own tracks (if any) go into a playlist of the same name inside it.
      const own = chain(entities.all(p.id), 'nextEntityId').filter(e => !e.databaseUuid || e.databaseUuid === info.uuid).map(e => String(e.trackId)).filter(id => known.has(id));
      if (kids.length || smartByPath.has(myPath)) {
        stats.folders++;
        const sub = build(p.id, depth + 1, myPath);
        if (own.length) { stats.playlists++; sub.unshift({ name: p.title, type: 'playlist', sourceIds: own }); }
        return [{ name: p.title, type: 'folder', children: sub }];
      }
      stats.playlists++;
      return [{ name: p.title, type: 'playlist', sourceIds: own }];
    }), ...smartNodes(pathKey)];
    const tree = build(0, 0, '');
    return { source: 'engine', tracks, tree, stats, location: loc, version: `${info.major}.${info.minor}` };
  } finally { close(); }
}

function inspect(dir = DEFAULT_LIBRARY, opts = {}) {
  const loc = locate(dir); if (!loc.ok) return loc;
  try {
    const r = read({ dir, ...opts });
    const found = r.tracks.filter(t => fs.existsSync(t.path)).length;
    return { ...loc, ok: true, version: r.version, tracks: r.tracks.length, filesFound: found, playlists: r.stats.playlists, folders: r.stats.folders, foldersSkipped: r.stats.foldersSkipped, smartlists: r.stats.smartlists, smartSkipped: r.stats.smartSkipped, smartSkippedList: r.stats.smartSkippedList, cueTracks: r.stats.cueTracks, cues: r.stats.cues, samplePaths: r.tracks.filter(t => !fs.existsSync(t.path)).slice(0, 3).map(t => t.path) };
  } catch (e) { return { ...loc, ok: false, reason: e.message }; }
}

module.exports = { read, inspect, locate, keyFromEngine, DEFAULT_LIBRARY };
