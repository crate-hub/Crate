'use strict';
// Smart playlist rule conversion between Crate, rekordbox (master.db SmartList XML) and Engine DJ (Smartlist.rules JSON).
// Each converter returns { rules } on success or { error } describing the first rule that can't be expressed.
// A list is converted whole or not at all, so a smart playlist never silently changes meaning.
const keys = require('./keys');

const DAY = 86400;
const isoDay = (d) => new Date(d).toISOString().slice(0, 10);
const addDays = (d, n) => isoDay(new Date(Date.parse(d) + n * DAY * 1000));

// ---------------------------------------------------------------- rekordbox -> Crate
// rekordbox operators: 1 =, 2 !=, 3 >, 4 <, 5 in range, 6 in last, 7 not in last, 8 contains, 9 not contains, 10 starts, 11 ends
const RB_TEXT = { artist: 'artist', originalArtist: 'artist', albumArtist: 'artist', album: 'album', comments: 'comment', producer: 'composer',
  genre: 'genre', label: 'label', mixName: 'mix', remixedBy: 'remixer', name: 'title' };
const RB_NUM = { bpm: 'bpm', rating: 'rating', duration: 'duration', year: 'year' };
const RB_DATE = { stockDate: 'dateAdded', dateCreated: 'dateAdded' };
const TEXT_OPS = { 1: 'is', 2: 'is_not', 8: 'contains', 9: 'not_contains', 10: 'starts_with', 11: 'ends_with' };

function xmlAttrs(s) {
  const unesc = (v) => v.replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  return Object.fromEntries([...s.matchAll(/(\w+)="([^"]*)"/g)].map(m => [m[1], unesc(m[2])]));
}

function fromRekordbox(xml) {
  const node = /<NODE\b([^>]*)>/.exec(xml || '');
  if (!node) return { error: 'no rules found' };
  const root = xmlAttrs(node[1]);
  const conds = [...String(xml).matchAll(/<CONDITION\b([^>]*?)\/?>/g)].map(m => xmlAttrs(m[1]));
  const match = root.LogicalOperator === '2' ? 'any' : 'all';
  const out = [];
  for (const c of conds) {
    const prop = c.PropertyName, op = Number(c.Operator), L = c.ValueLeft ?? '', R = c.ValueRight ?? '';
    const fail = (why) => ({ error: `rekordbox rule “${prop}” ${why}` });
    if (RB_TEXT[prop]) {
      if (!TEXT_OPS[op]) return fail('uses an unsupported condition');
      out.push({ field: RB_TEXT[prop], op: TEXT_OPS[op], value: L });
    } else if (prop === 'key') {
      if (op !== 1 && op !== 2) return fail('only “is” / “is not” can be converted for keys');
      if (!keys.parse(L)) return fail(`has a key Crate can't read (${L})`);
      out.push({ field: 'key', op: op === 1 ? 'is' : 'is_not', value: L });
    } else if (prop === 'fileName') {
      const m = { 8: 'contains', 9: 'not_contains', 11: 'ends_with' }[op];
      if (!m) return fail('uses a file-name condition Crate can’t match exactly');
      out.push({ field: 'path', op: m, value: L });
    } else if (RB_NUM[prop]) {
      const scale = prop === 'bpm' ? 100 : 1; // rekordbox stores BPM x100
      const a = Number(L) / scale, b = Number(R) / scale;
      if (Number.isNaN(a)) return fail('has a value that isn’t a number');
      const m = { 1: 'eq', 2: 'ne', 3: 'gt', 4: 'lt' }[op];
      if (m) out.push({ field: RB_NUM[prop], op: m, value: a });
      else if (op === 5 && !Number.isNaN(b)) out.push({ field: RB_NUM[prop], op: 'between', value: a, value2: b });
      else return fail('uses an unsupported condition');
    } else if (RB_DATE[prop]) {
      if (op === 6 || op === 7) {
        const n = Number(L) * (c.ValueUnit === 'month' ? 30 : 1);
        if (!(n > 0)) return fail('has an invalid period');
        out.push({ field: 'dateAdded', op: op === 6 ? 'in_last_days' : 'not_in_last_days', value: n });
      } else if (op === 3) out.push({ field: 'dateAdded', op: 'after', value: addDays(L, 1) });
      else if (op === 4) out.push({ field: 'dateAdded', op: 'before', value: L });
      else if (op === 5 && match === 'all') out.push({ field: 'dateAdded', op: 'after', value: L }, { field: 'dateAdded', op: 'before', value: addDays(R, 1) });
      else if (op === 1 && match === 'all') out.push({ field: 'dateAdded', op: 'after', value: L }, { field: 'dateAdded', op: 'before', value: addDays(L, 1) });
      else return fail('uses a date condition Crate can’t express here');
    } else if (prop === 'dateReleased' && (op === 1 || op === 3 || op === 4 || op === 5)) {
      const y = (s) => Number(String(s).slice(0, 4));
      if (op === 1) out.push({ field: 'year', op: 'eq', value: y(L) });
      else if (op === 3) out.push({ field: 'year', op: 'gte', value: y(L) });
      else if (op === 4) out.push({ field: 'year', op: 'lte', value: y(L) });
      else out.push({ field: 'year', op: 'between', value: y(L), value2: y(R) });
    } else if (prop === 'myTag') return fail('uses My Tags, which Crate doesn’t have');
    else if (prop === 'grouping') return fail('uses track colours, which Crate doesn’t have');
    else if (prop === 'counter') return fail('uses play counts, which Crate doesn’t track');
    else return fail('isn’t supported');
  }
  if (!out.length) return { error: 'no rules found' };
  return { rules: { match, conditions: out } };
}

// ---------------------------------------------------------------- Crate -> rekordbox
// Builds master.db SmartList XML. `playlistId` is the djmdPlaylist ID; rekordbox stores it in the
// XML as ID - 2^32. Key rules aren't converted: rekordbox may match keys by its own key IDs.
const CRATE_TO_RB_TEXT = { title: 'name', artist: 'artist', album: 'album', genre: 'genre', label: 'label', comment: 'comments',
  remixer: 'remixedBy', composer: 'producer', mix: 'mixName' };
const TO_RB_TEXT_OPS = { is: 1, is_not: 2, contains: 8, not_contains: 9, starts_with: 10, ends_with: 11 };
const xmlEsc = (v) => String(v).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
function toRekordbox(rules, playlistId) {
  const r = rules || {}; const conds = r.conditions || [];
  if (!conds.length) return { error: 'it has no rules' };
  if (r.limit) return { error: 'rekordbox smart playlists can’t limit the number of tracks' };
  const out = [];
  const add = (prop, op, left, right = '', unit = '') => out.push({ prop, op, left: String(left), right: String(right), unit });
  for (const c of conds) {
    const v = c.value;
    if (CRATE_TO_RB_TEXT[c.field]) {
      if (!TO_RB_TEXT_OPS[c.op]) return { error: `rekordbox can’t express “${c.field} ${c.op.replace(/_/g, ' ')}”` };
      add(CRATE_TO_RB_TEXT[c.field], TO_RB_TEXT_OPS[c.op], v ?? '');
    } else if (c.field === 'path' && ['contains', 'not_contains', 'ends_with'].includes(c.op)) {
      add('fileName', { contains: 8, not_contains: 9, ends_with: 11 }[c.op], v ?? '');
    } else if (['bpm', 'rating', 'duration', 'year'].includes(c.field)) {
      const k = c.field === 'bpm' ? 100 : 1; const n = (x) => Math.round(Number(x) * k);
      if (Number.isNaN(Number(v))) return { error: `the ${c.field} rule has no number` };
      if (c.op === 'eq') add(c.field, 1, n(v)); else if (c.op === 'ne') add(c.field, 2, n(v));
      else if (c.op === 'gt') add(c.field, 3, n(v)); else if (c.op === 'lt') add(c.field, 4, n(v));
      else if (c.op === 'gte') add(c.field, 3, n(v) - 1); else if (c.op === 'lte') add(c.field, 4, n(v) + 1); // whole numbers, so exact
      else if (c.op === 'between') add(c.field, 5, n(v), n(c.value2));
      else return { error: `rekordbox can’t express this ${c.field} rule` };
    } else if (c.field === 'dateAdded') {
      if (c.op === 'in_last_days') add('stockDate', 6, Math.round(Number(v)), '', 'day');
      else if (c.op === 'not_in_last_days') add('stockDate', 7, Math.round(Number(v)), '', 'day');
      else if (c.op === 'after') add('stockDate', 3, addDays(v, -1));
      else if (c.op === 'before') add('stockDate', 4, isoDay(v));
      else return { error: 'rekordbox can’t express this date rule' };
    } else if (c.field === 'key') return { error: 'key rules aren’t converted for rekordbox' };
    else if (c.field === 'playlist') return { error: 'rekordbox smart playlists can’t check playlist membership' };
    else return { error: `rekordbox smart playlists can’t filter on ${c.field}` };
  }
  const id = Number(playlistId) - 2 ** 32;
  const xml = `<NODE Id="${id}" LogicalOperator="${r.match === 'any' ? 2 : 1}" AutomaticUpdate="1">` +
    out.map(c => `<CONDITION PropertyName="${c.prop}" Operator="${c.op}" ValueUnit="${c.unit}" ValueLeft="${xmlEsc(c.left)}" ValueRight="${xmlEsc(c.right)}"/>`).join('') + '</NODE>';
  return { xml };
}

// ---------------------------------------------------------------- Engine DJ <-> Crate
const EN_TEXT = { artist: 'artist', album: 'album', comment: 'comment', genre: 'genre', label: 'label', title: 'title' };
const EN_NUM = { 'ROUND(bpmAnalyzed)': 'bpm', length: 'duration', year: 'year', 'IFNULL(rating, 0)': 'rating' };
const CRATE_TO_EN_NUM = { bpm: 'ROUND(bpmAnalyzed)', duration: 'length', year: 'year', rating: 'IFNULL(rating, 0)' };
const sq = (s) => `'${String(s).replace(/'/g, "''")}'`;
const unq = (s) => { const m = /^'(.*)'$/s.exec(String(s).trim()); return m ? m[1].replace(/''/g, "'") : String(s); };
const EXT_TO_FORMAT = { m4a: 'mp4', mp4: 'mp4', aif: 'aiff', aiff: 'aiff' };

function fromEngine(json) {
  let r; try { r = JSON.parse(json); } catch { return { error: 'rules can’t be read' }; }
  const match = r.match === 'all' ? 'all' : 'any';
  const out = [];
  for (const rule of r.rules || []) {
    const { col, con } = rule; const p = String(rule.param ?? '');
    const fail = (why) => ({ error: `Engine rule on “${col}” ${why}` });
    if (EN_TEXT[col]) {
      const v = unq(p); const field = EN_TEXT[col];
      if (con === '=') out.push({ field, op: 'is', value: v });
      else if (con === '!=') out.push({ field, op: 'is_not', value: v });
      else if (con === 'LIKE' || con === 'NOT LIKE') out.push({ field, op: con === 'LIKE' ? 'contains' : 'not_contains', value: v.replace(/^%|%$/g, '') });
      else if (con === 'BEGINSWITH') out.push({ field, op: 'starts_with', value: v.replace(/%$/, '') });
      else if (con === 'ENDSWITH') out.push({ field, op: 'ends_with', value: v.replace(/^%/, '') });
      else if (con === 'IS' || con === 'IS NOT') out.push({ field, op: (con === 'IS') === (unq(p) === 'true') ? 'not_empty' : 'is_empty' });
      else return fail('uses an unsupported condition');
    } else if (EN_NUM[col]) {
      const field = EN_NUM[col]; const scale = field === 'rating' ? 20 : 1;
      if (con === 'BETWEEN') { const [a, b] = p.split(/\s+AND\s+/i).map(Number); out.push({ field, op: 'between', value: a / scale, value2: b / scale }); }
      else { const m = { '=': 'eq', '>': 'gt', '<': 'lt' }[con]; if (!m) return fail('uses an unsupported condition'); out.push({ field, op: m, value: Number(p) / scale }); }
    } else if (col === 'key') {
      if (con === '=') out.push({ field: 'key', op: 'is', value: keyFromIndex(Number(p)) });
      else if (con === 'IN') { const first = Number(p.replace(/[()]/g, '').split(',')[0]); out.push({ field: 'key', op: 'compatible_with', value: keyFromIndex(first % 24) }); }
      else return fail('uses an unsupported key condition');
    } else if (col === 'dateAdded') {
      if (con === '>') out.push({ field: 'dateAdded', op: 'after', value: isoDay((Number(p) + 1) * 1000) }); // "> t" = on or after t + 1s
      else if (con === '<') out.push({ field: 'dateAdded', op: 'before', value: isoDay(Number(p) * 1000) });
      else if (con === 'BETWEEN' && match === 'all') { const [a, b] = p.split(/\s+AND\s+/i).map(Number); out.push({ field: 'dateAdded', op: 'after', value: isoDay(a * 1000) }, { field: 'dateAdded', op: 'before', value: isoDay(b * 1000) }); }
      else return fail('uses an unsupported date condition');
    } else if (col === 'fileType') {
      const ext = unq(p).replace(/%/g, '').toLowerCase();
      out.push({ field: 'format', op: con === '!=' || con === 'NOT LIKE' ? 'is_not' : 'is', value: EXT_TO_FORMAT[ext] || ext });
    } else return fail('isn’t supported');
  }
  if (!out.length) return { error: 'no rules found' };
  return { rules: { match, conditions: out } };
}
function keyFromIndex(k) { return keys.format(`${Math.floor(k / 2) + 1}${k % 2 ? 'm' : 'd'}`, 'camelot'); }

/** Crate rules -> Engine rules JSON string, or { error } when Engine can't express them. */
function toEngine(rules) {
  if (rules.limit || rules.sort) return { error: 'Engine smartlists have no limit or sort order' };
  const conds = rules.conditions || [];
  if (!conds.length) return { error: 'no rules' };
  const out = [];
  for (const c of conds) {
    const fail = (why) => ({ error: `rule on ${c.field} ${why}` });
    const push = (col, con, param) => out.push({ col, con, param: String(param), v: '2.20.0' });
    if (EN_TEXT[c.field] !== undefined || Object.values(EN_TEXT).includes(c.field)) {
      const col = c.field; const v = String(c.value ?? '');
      const m = { is: ['=', sq(v)], is_not: ['!=', sq(v)], contains: ['LIKE', sq(`%${v}%`)], not_contains: ['NOT LIKE', sq(`%${v}%`)],
        starts_with: ['BEGINSWITH', sq(`${v}%`)], ends_with: ['ENDSWITH', sq(`%${v}`)] }[c.op];
      if (!m) return fail(`(“${c.op}”) has no Engine equivalent`);
      push(col, m[0], m[1]);
    } else if (CRATE_TO_EN_NUM[c.field]) {
      const col = CRATE_TO_EN_NUM[c.field]; const s = c.field === 'rating' ? 20 : 1;
      const v = Number(c.value) * s, v2 = Number(c.value2) * s;
      if (c.op === 'between') push(col, 'BETWEEN', `${Math.min(v, v2)} AND ${Math.max(v, v2)}`);
      else { const m = { eq: '=', gt: '>', lt: '<' }[c.op]; if (!m) return fail(`(“${c.op}”) has no Engine equivalent`); push(col, m, v); }
    } else if (c.field === 'key') {
      const idx = keys.toEngine(c.value);
      if (idx === null) return fail('has an unreadable key');
      if (c.op === 'is') push('key', '=', idx);
      else if (c.op === 'compatible_with') {
        // same key, relative major/minor, one step either way on the wheel (Engine key indexes 0-23)
        const offs = idx % 2 === 0 ? [0, 1, -2, 2] : [0, -1, -2, 2];
        push('key', 'IN', `(${offs.map(o => ((idx + o) % 24 + 24) % 24).join(',')})`);
      } else return fail(`(“${c.op}”) has no Engine equivalent`);
    } else if (c.field === 'dateAdded' && (c.op === 'before' || c.op === 'after')) {
      push('dateAdded', c.op === 'before' ? '<' : '>', Math.floor(Date.parse(c.value) / 1000) - (c.op === 'after' ? 1 : 0));
    } else if (c.field === 'format' && (c.op === 'is' || c.op === 'is_not')) {
      const ext = ({ mp4: 'm4a' })[c.value] || c.value; push('fileType', c.op === 'is' ? 'LIKE' : 'NOT LIKE', sq(`%${ext}%`));
    } else return fail('has no Engine equivalent');
  }
  return { json: JSON.stringify({ match: rules.match === 'any' ? 'one' : 'all', rules: out, rv: 1 }) };
}

module.exports = { fromRekordbox, toRekordbox, fromEngine, toEngine };
