'use strict';
// Remembers the window's size, position and maximised/full-screen state between launches, in
// window-state.json next to the library. A saved position that's no longer on any screen (say a
// monitor was unplugged) falls back to the default size, centred on the main screen.
const fs = require('fs');
const path = require('path');

const DEFAULTS = { width: 1440, height: 900 };
const MIN = { width: 1100, height: 640 };

function load(file) {
  try {
    const s = JSON.parse(fs.readFileSync(file, 'utf8'));
    const n = (v) => (Number.isFinite(v) ? Math.round(v) : undefined);
    return { x: n(s.x), y: n(s.y), width: n(s.width), height: n(s.height), maximized: !!s.maximized, fullScreen: !!s.fullScreen };
  } catch { return null; }
}

function save(file, state) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(state)); fs.renameSync(tmp, file);
  } catch { /* not worth interrupting anything for */ }
}

/**
 * Bounds to open the window with. `displays` are the screens' work areas ({ x, y, width, height }).
 * The window must fit (it's shrunk to the largest screen if needed) and at least its top-left
 * corner area must be on a screen, so the title bar can always be grabbed.
 */
function fit(saved, displays) {
  const out = { ...DEFAULTS };
  if (!saved || !(saved.width > 0) || !(saved.height > 0)) return out;
  const maxW = Math.max(...displays.map(d => d.width), MIN.width), maxH = Math.max(...displays.map(d => d.height), MIN.height);
  out.width = Math.max(MIN.width, Math.min(saved.width, maxW));
  out.height = Math.max(MIN.height, Math.min(saved.height, maxH));
  if (Number.isFinite(saved.x) && Number.isFinite(saved.y)) {
    // The top 40px strip of the window (its title bar), at least 100px of it, has to land on a screen.
    const visible = displays.some(d => {
      const left = Math.max(saved.x, d.x), right = Math.min(saved.x + out.width, d.x + d.width);
      const top = Math.max(saved.y, d.y), bottom = Math.min(saved.y + 40, d.y + d.height);
      return right - left >= 100 && bottom - top >= 20;
    });
    if (visible) { out.x = saved.x; out.y = saved.y; }
  }
  return out;
}

/** Keeps `file` up to date for a BrowserWindow (on resize/move, debounced, and on close). */
function track(win, file) {
  let timer = null;
  const snapshot = () => {
    if (win.isDestroyed()) return;
    const fullScreen = win.isFullScreen(), maximized = win.isMaximized();
    // While maximised or full screen, keep the size it had before, to come back to.
    const b = (fullScreen || maximized) && win.getNormalBounds ? win.getNormalBounds() : win.getBounds();
    save(file, { ...b, maximized, fullScreen });
  };
  const later = () => { clearTimeout(timer); timer = setTimeout(snapshot, 500); };
  for (const ev of ['resize', 'move', 'maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen']) win.on(ev, later);
  win.on('close', () => { clearTimeout(timer); snapshot(); });
}

module.exports = { load, save, fit, track, DEFAULTS, MIN };
