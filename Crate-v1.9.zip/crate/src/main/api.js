'use strict';
// The API the window may call. Every method the renderer can reach is listed here, nothing else.
// Platform specifics (dialogs, Finder, Engine-running check) are injected so this file is testable without Electron.
const path = require('path');
const fs = require('fs');
const cleanup = require('../core/cleanup');
const smart = require('../core/smartlist');
const rekordbox = require('../core/export/rekordbox');
const m3u = require('../core/export/m3u');
const engine = require('../core/export/engine');
const rbImport = require('../core/import/rekordbox');
const rekordboxDb = require('../core/export/rekordboxdb');
const engineImport = require('../core/import/engine');

/**
 * @param lib Library
 * @param env { chooseImport(), chooseSave(opts), chooseFolder(opts), chooseFile(opts), reveal(p), trash(p), isEngineRunning(), send(event, data) }
 */
function createApi(lib, env) {
  const scopeTracks = (scope = {}) => scope.ids && scope.ids.length ? lib.getTracks(scope.ids) : lib.listTracks(scope.view || {});
  let importing = false;
  const runImport = async (paths) => {
    if (!paths || !paths.length) return null;
    if (importing) throw new Error('An import is already running');
    importing = true;
    try { return await lib.importPaths(paths, p => env.send('import-progress', p)); } finally { importing = false; env.send('library-changed'); }
  };

  const runExternal = async (readFn, rootName, opts, settingKey) => {
    if (importing) throw new Error('An import is already running');
    importing = true;
    try {
      const src = readFn();
      if (opts.dir) lib.setSetting(settingKey, opts.dir);
      // Playlists go to the top level; the ones the last import from this app made are replaced.
      const key = `import.created.${settingKey}`;
      const res = await lib.importExternal(src, { mode: opts.mode, writeFiles: !!opts.writeFiles, pathMap: opts.pathMap || [], rootName,
        replace: lib.getSetting(key, []), onProgress: p => env.send('import-progress', p) });
      lib.setSetting(key, res.created);
      return { ...res, stats: src.stats };
    } finally { importing = false; env.send('library-changed'); }
  };

  let lastRenames = null;
  // Exports write Crate's playlists at the top level. The folders imports create ("From rekordbox",
  // "From Engine DJ") aren't exported as folders: what's inside them moves up a level.
  const IMPORT_ROOTS = new Set(['from rekordbox', 'from engine dj']);
  const exportTree = () => lib.playlistTree({ withTracks: true }).flatMap(n => n.type === 'folder' && IMPORT_ROOTS.has(String(n.name).toLowerCase()) ? (n.children || []) : [n]);
  // Until a new-style export has run, older exports left a top-level folder (e.g. "Crate") that imports skip.
  const legacySkip = (key) => lib.getSetting(key) ? [lib.getSetting(key)] : [];
  const api = {
    // Shown with one decimal place (0.9); package.json keeps npm's three-part form (0.9.0).
    'app.version': () => require('../../package.json').version.split('.').slice(0, 2).join('.'),
    // settings
    'settings.get': (key, def) => lib.getSetting(key, def),
    'settings.set': (key, value) => { lib.setSetting(key, value); return true; },

    // tracks
    'tracks.list': (view) => lib.listTracks(view || {}),
    'tracks.count': () => lib.countTracks(),
    'tracks.get': (ids) => lib.getTracks(ids || []),
    'tracks.update': (ids, changes, opts) => lib.updateTracks(ids, changes, opts),
    'tracks.remove': (ids) => { lib.removeTracks(ids); return true; },
    'tracks.cues': (id) => lib.getCues(Number(id)),
    'tracks.writeTags': async (ids) => lib.writeTagsToFiles((ids || []).map(Number), p => env.send('write-progress', p)),
    'files.previewRename': (ids) => lib.previewRenames(Array.isArray(ids) ? ids.map(Number) : lib.listTracks().map(t => t.id)),
    // The last batch is kept here (not sent back by the window), so undo can only reverse Crate's own renames.
    'files.rename': (ids) => { const r = lib.renameFiles(Array.isArray(ids) ? ids.map(Number) : lib.listTracks().map(t => t.id)); lastRenames = r.renamed; env.send('library-changed'); return { ...r, renamed: r.renamed.length }; },
    'files.undoRename': () => { const r = lib.undoRenames(lastRenames || []); lastRenames = null; env.send('library-changed'); return r; },
    'tracks.reveal': (id) => { const t = lib.getTracks([id])[0]; if (t) env.reveal(t.path); return !!t; },
    'tracks.checkMissing': () => lib.checkMissing(),
    'tracks.relocate': async (id) => {
      const t = lib.getTracks([id])[0]; if (!t) return null;
      const f = await env.chooseFile({ title: `Locate "${t.title}"`, defaultPath: path.dirname(t.path) }); if (!f) return null;
      lib.relocate(id, f); return lib.getTracks([id])[0];
    },
    'tracks.distinct': (field) => lib.distinct(field),
    'tracks.audioUrl': (id) => `crate-audio://track/${Number(id)}`,

    // import
    'import.choose': async () => runImport(await env.chooseImport()),
    'import.paths': (paths) => runImport((paths || []).filter(p => typeof p === 'string')),

    // import from other DJ apps
    'import.rekordboxInspect': (dir) => rbImport.inspect(dir || lib.getSetting('import.rekordboxDir') || rbImport.DEFAULT_DIR, { skipFolders: legacySkip('export.rekordboxRoot') }),
    'import.engineInspect': (dir) => engineImport.inspect(dir || lib.getSetting('import.engineDir') || engineImport.DEFAULT_LIBRARY, { skipFolders: legacySkip('export.engineRoot') }),
    'import.chooseFolder': async (title, defaultPath) => env.chooseFolder({ title, defaultPath }),
    /** opts: { dir, mode: 'fill'|'overwrite', writeFiles, pathMap: [{from,to}], includeBundled } */
    'import.rekordbox': async (opts = {}) => runExternal(() => rbImport.read({ dir: opts.dir || rbImport.DEFAULT_DIR, includeBundled: !!opts.includeBundled, skipFolders: legacySkip('export.rekordboxRoot') }), 'From rekordbox', opts, 'import.rekordboxDir'),
    'import.engine': async (opts = {}) => runExternal(() => engineImport.read({ dir: opts.dir || engineImport.DEFAULT_LIBRARY, skipFolders: legacySkip('export.engineRoot') }), 'From Engine DJ', opts, 'import.engineDir'),

    // playlists
    'playlists.list': () => lib.listPlaylists(),
    'playlists.create': (opts) => lib.createPlaylist(opts),
    'playlists.update': (id, opts) => { lib.updatePlaylist(id, opts); return true; },
    'playlists.delete': (id) => { lib.deletePlaylist(id); return true; },
    'playlists.move': (id, parentId, index) => { lib.movePlaylist(id, parentId || null, index); return true; },
    'playlists.add': (id, trackIds) => lib.addToPlaylist(id, trackIds),
    'playlists.remove': (id, trackIds) => { lib.removeFromPlaylist(id, trackIds); return true; },
    'playlists.reorder': (id, trackIds) => { lib.reorderPlaylist(id, trackIds); return true; },
    'playlists.smartMeta': () => ({ fields: smart.FIELDS, ops: smart.OPS }),
    'playlists.previewSmart': (rules) => lib.listTracks({ rules }).length,

    // clean-up
    'cleanup.fixList': () => cleanup.FIX_LIST,
    'cleanup.previewFixes': (scope, fixes) => cleanup.previewFixes(scopeTracks(scope), fixes),
    'cleanup.previewReplace': (scope, opts) => cleanup.previewReplace(scopeTracks(scope), opts),
    'cleanup.previewGenres': (mapping) => cleanup.previewGenreRename(lib.listTracks(), mapping),
    'cleanup.duplicates': (scope, opts) => cleanup.findDuplicates(scopeTracks(scope), opts),
    'cleanup.apply': (edits, opts) => { const r = lib.applyEdits(edits, opts); env.send('library-changed'); return r; },
    /** Resolve duplicates: remove the given tracks from the library; optionally move their files to the Trash. */
    'cleanup.removeDuplicates': async (ids, { trashFiles = false } = {}) => {
      const tracks = lib.getTracks(ids); const errors = [];
      if (trashFiles) for (const t of tracks) { try { await env.trash(t.path); } catch (e) { errors.push({ path: t.path, error: e.message }); } }
      lib.removeTracks(tracks.map(t => t.id)); env.send('library-changed');
      return { removed: tracks.length, errors };
    },

    // export
    'export.rekordbox': async (opts = {}) => {
      const file = opts.file || await env.chooseSave({ title: 'Export rekordbox XML', defaultPath: lib.getSetting('export.rekordboxPath') || 'rekordbox.xml', filters: [{ name: 'rekordbox XML', extensions: ['xml'] }] });
      if (!file) return null; lib.setSetting('export.rekordboxPath', file);
      const tracks = lib.listTracks();
      return rekordbox.write(file, tracks, exportTree(), { keyNotation: opts.keyNotation || 'musical',
        cues: opts.cues === false ? null : lib.cuesByTrack(tracks.filter(t => t.cues).map(t => t.id)) });
    },
    'export.m3u': async (opts = {}) => {
      const dir = opts.dir || await env.chooseFolder({ title: 'Choose a folder for the playlists' });
      if (!dir) return null;
      return { dir, files: m3u.write(dir, exportTree(), ids => lib.getTracks(ids)).length };
    },
    'export.rekordboxDbInspect': async (dir) => {
      const d = dir || lib.getSetting('export.rekordboxDir') || rekordboxDb.DEFAULT_DIR;
      const r = rekordboxDb.inspect(d);
      return { ...r, dir: r.dir || d, running: await env.isRekordboxRunning() };
    },
    'export.rekordboxDbChooseDir': async () => env.chooseFolder({ title: 'Choose the folder that contains rekordbox’s master.db', defaultPath: lib.getSetting('export.rekordboxDir') || rekordboxDb.DEFAULT_DIR }),
    'export.rekordboxDb': async (opts = {}) => {
      if (await env.isRekordboxRunning()) throw new Error('rekordbox is open. Quit rekordbox first, then export again.');
      const dir = opts.dir || lib.getSetting('export.rekordboxDir') || rekordboxDb.DEFAULT_DIR;
      const tracks = lib.listTracks();
      const res = rekordboxDb.exportTo(tracks, exportTree(), { dir, keyNotation: opts.keyNotation || 'musical',
        cues: opts.cues === false ? null : lib.cuesByTrack(tracks.filter(t => t.cues).map(t => t.id)), previousPaths: lib.previousPaths(tracks.map(t => t.id)) });
      lib.setSetting('export.rekordboxDir', dir); lib.setSetting('export.rekordboxRoot', null);
      return res;
    },
    'export.engineInspect': (libraryDir) => engine.inspect(libraryDir || lib.getSetting('export.engineDir') || engine.DEFAULT_LIBRARY),
    'export.engineChooseDir': async () => env.chooseFolder({ title: 'Choose your "Engine Library" folder', defaultPath: lib.getSetting('export.engineDir') || engine.DEFAULT_LIBRARY }),
    'export.engine': async (opts = {}) => {
      if (await env.isEngineRunning()) throw new Error('Engine DJ is open. Quit Engine DJ first, then export again.');
      const libraryDir = opts.libraryDir || lib.getSetting('export.engineDir') || engine.DEFAULT_LIBRARY;
      const tracks = lib.listTracks();
      const res = engine.exportTo(tracks, exportTree(), { libraryDir,
        cues: opts.cues === false ? null : lib.cuesByTrack(tracks.filter(t => t.cues).map(t => t.id)), previousPaths: lib.previousPaths(tracks.map(t => t.id)) });
      lib.setSetting('export.engineDir', libraryDir); lib.setSetting('export.engineRoot', null);
      return res;
    },
  };
  return {
    methods: Object.keys(api),
    async call(method, args) {
      if (!Object.prototype.hasOwnProperty.call(api, method)) throw new Error(`Unknown API method: ${method}`);
      if (!Array.isArray(args)) throw new Error('Bad arguments');
      return api[method](...args);
    },
    /** Resolve an audio URL to a library file path (only library tracks can be streamed). */
    audioPath(id) { const t = lib.getTracks([Number(id)])[0]; return t && fs.existsSync(t.path) ? t.path : null; },
  };
}

module.exports = { createApi };
