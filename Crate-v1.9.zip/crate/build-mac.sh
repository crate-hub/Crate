#!/usr/bin/env bash
# Build Crate.app on macOS using Homebrew.
#
#   ./build-mac.sh              build dist/Crate-darwin-<arch>/Crate.app
#   ./build-mac.sh --install    ...and copy it to /Applications
#   ./build-mac.sh --skip-tests skip the test run
#
set -euo pipefail
cd "$(dirname "$0")"

INSTALL=0
RUN_TESTS=1
for arg in "$@"; do
  case "$arg" in
    --install) INSTALL=1 ;;
    --skip-tests) RUN_TESTS=0 ;;
    -h|--help) sed -n '2,8p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown option: $arg (try --help)"; exit 1 ;;
  esac
done

step() { printf '\n\033[1;33m==>\033[0m \033[1m%s\033[0m\n' "$1"; }
fail() { printf '\n\033[1;31mError:\033[0m %s\n' "$1" >&2; exit 1; }

[[ "$(uname -s)" == "Darwin" ]] || fail "This script builds the macOS app. Run it on a Mac."

# 1. Homebrew
step "Checking Homebrew"
if ! command -v brew >/dev/null 2>&1; then
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [[ -x "$b" ]] && eval "$("$b" shellenv)" && break; done
fi
command -v brew >/dev/null 2>&1 || fail "Homebrew isn't installed. Install it from https://brew.sh with:
  /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"
then run this script again."
echo "Homebrew $(brew --version | head -1 | awk '{print $2}') at $(brew --prefix)"

# 2. Node.js 22.13+ (Crate uses Node's built-in SQLite)
node_ok() { command -v node >/dev/null 2>&1 && node -e 'const [a,b]=process.versions.node.split(".").map(Number);process.exit(a>22||(a===22&&b>=13)?0:1)'; }
step "Checking Node.js"
export PATH="$(brew --prefix)/bin:$PATH"   # prefer Homebrew's node over any older copy
if ! node_ok; then
  if brew list --formula node >/dev/null 2>&1; then echo "Upgrading Homebrew's node…"; brew upgrade node
  else echo "Installing node with Homebrew…"; brew install node; fi
  hash -r
fi
node_ok || fail "Node.js 22.13 or newer is needed, found $(node --version 2>/dev/null || echo none)."
echo "Node $(node --version), npm $(npm --version)"

# 3. Dependencies
step "Installing dependencies"
npm install --no-audit --no-fund

# 4. Tests
if [[ $RUN_TESTS -eq 1 ]]; then
  step "Running tests"
  command -v ffprobe >/dev/null 2>&1 || echo "(tip: 'brew install ffmpeg' lets the tag tests double-check files with ffprobe)"
  npm test --silent
fi

# 5. Electron itself
# Electron's npm installer (and @electron/packager) unzip with a library that silently stops
# part-way on recent Node versions, leaving no Electron.app. So: fetch the official zip and
# unpack it with macOS's own `ditto` instead.
ARCH="$(uname -m)"; [[ "$ARCH" == "x86_64" ]] && ARCH="x64"
EVER="$(node -p "require('./node_modules/electron/package.json').version")"
ZIPNAME="electron-v$EVER-darwin-$ARCH.zip"
step "Getting Electron $EVER for $ARCH"
CACHE="$HOME/Library/Caches/electron"
ZIP="$(find "$CACHE" -name "$ZIPNAME" -size +20M 2>/dev/null | head -1 || true)"
if [[ -n "$ZIP" ]]; then
  echo "Using downloaded copy: $ZIP"
else
  mkdir -p "$CACHE/crate"; ZIP="$CACHE/crate/$ZIPNAME"
  BASE="https://github.com/electron/electron/releases/download/v$EVER"
  curl -fL --progress-bar -o "$ZIP.part" "$BASE/$ZIPNAME" || fail "Couldn't download Electron from $BASE/$ZIPNAME"
  EXPECTED="$(curl -fsL "$BASE/SHASUMS256.txt" | grep -F "*$ZIPNAME" | awk '{print $1}')"
  ACTUAL="$(shasum -a 256 "$ZIP.part" | awk '{print $1}')"
  if [[ -z "$EXPECTED" || "$EXPECTED" != "$ACTUAL" ]]; then rm -f "$ZIP.part"; fail "Electron download failed its checksum check. Run the script again."; fi
  mv "$ZIP.part" "$ZIP"
fi
EDIST="node_modules/electron/dist"
rm -rf "$EDIST"; mkdir -p "$EDIST"
ditto -x -k "$ZIP" "$EDIST" || fail "Couldn't unpack $ZIP"
[[ -x "$EDIST/Electron.app/Contents/MacOS/Electron" ]] || fail "Electron.app is missing after unpacking $ZIP"
printf 'Electron.app/Contents/MacOS/Electron' > node_modules/electron/path.txt   # makes 'npm start' work too

# 6. Assemble Crate.app = Electron.app + Crate's code + Crate's name
step "Building Crate.app"
OUT="dist/Crate-darwin-$ARCH"; APP="$OUT/Crate.app"
rm -rf "$OUT" dist/darwin-*-template-* dist/.last-build
mkdir -p "$OUT"
ditto "$EDIST/Electron.app" "$APP"
RES="$APP/Contents/Resources"
rm -rf "$RES/default_app.asar" "$RES/default_app"
mkdir -p "$RES/app"
cp main.js preload.js package.json "$RES/app/"
cp -R src "$RES/app/src"
PLIST="$APP/Contents/Info.plist"; PB=/usr/libexec/PlistBuddy
plist_set() { "$PB" -c "Set :$1 $3" "$PLIST" 2>/dev/null || "$PB" -c "Add :$1 $2 $3" "$PLIST"; }
# Versions are shown with one decimal place (0.9, 1.0, …); package.json keeps npm's three-part form (0.9.0).
FULL_VERSION="$(node -p "require('./package.json').version")"
VERSION="$(node -p "require('./package.json').version.split('.').slice(0, 2).join('.')")"
plist_set CFBundleName string Crate
plist_set CFBundleDisplayName string Crate
plist_set CFBundleIdentifier string app.crate.desktop
plist_set CFBundleShortVersionString string "$VERSION"
plist_set CFBundleVersion string "$FULL_VERSION"
plist_set LSApplicationCategoryType string public.app-category.music
[[ -f "$RES/app/main.js" ]] || fail "Crate's code wasn't copied into the app."
echo "Built Crate $VERSION at $APP"

# Ad-hoc sign so macOS (especially Apple Silicon) accepts the modified bundle, and clear download flags.
step "Signing (ad-hoc, for this Mac)"
xattr -cr "$APP" || true
codesign --force --deep --sign - "$APP"
codesign --verify --deep "$APP" && echo "Signature OK"

# 7. Install
if [[ $INSTALL -eq 1 ]]; then
  step "Installing to /Applications"
  if pgrep -x Crate >/dev/null 2>&1; then fail "Crate is running. Quit it first, then run again with --install."; fi
  rm -rf "/Applications/Crate.app"
  cp -R "$APP" /Applications/
  APP="/Applications/Crate.app"
fi

printf '\n\033[1;32mDone.\033[0m Crate is at: %s\nOpen it with:  open "%s"\n' "$APP" "$APP"
