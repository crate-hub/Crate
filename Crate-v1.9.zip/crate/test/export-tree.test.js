'use strict';
// Exports write Crate's playlists at the top level: no wrapper folder, and the "From rekordbox" /
// "From Engine DJ" folders made by imports are flattened into the top level.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Library } = require('../src/core/library');
const { createApi } = require('../src/main/api');

test('every export flattens import folders and adds no wrapper folder', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'crate-flat-'));
  const music = path.join(dir, 'Music'); fs.mkdirSync(music);
  fs.copyFileSync(path.join(__dirname, 'fixtures', 't_v23.mp3'), path.join(music, 'a.mp3'));
  const lib = new Library(path.join(dir, 'lib.db')); await lib.importPaths([music]);
  const id = lib.listTracks()[0].id;
  const fromEngine = lib.createPlaylist({ name: 'From Engine DJ', type: 'folder' });
  const genres = lib.createPlaylist({ name: 'GENRES', type: 'folder', parentId: fromEngine });
  lib.addToPlaylist(lib.createPlaylist({ name: 'Rollers', parentId: genres }), [id]);
  lib.addToPlaylist(lib.createPlaylist({ name: 'Warm-up', parentId: fromEngine }), [id]);
  lib.addToPlaylist(lib.createPlaylist({ name: 'Mine' }), [id]);
  const api = createApi(lib, { send: () => {}, chooseSave: async () => null, chooseFolder: async () => null });
  const call = (m, ...a) => api.call(m, a);

  const xmlFile = path.join(dir, 'out.xml');
  await call('export.rekordbox', { file: xmlFile });
  const xml = fs.readFileSync(xmlFile, 'utf8');
  const root = xml.slice(xml.indexOf('<NODE Type="0" Name="ROOT"'));
  assert.match(root, /^<NODE Type="0" Name="ROOT" Count="3">/, 'ROOT holds GENRES, Warm-up and Mine directly');
  assert.ok(!/<NODE[^>]*Name="(From Engine DJ|Crate)"/.test(xml), 'no import or wrapper folder');

  const m3uDir = path.join(dir, 'm3u');
  await call('export.m3u', { dir: m3uDir });
  assert.deepStrictEqual(fs.readdirSync(m3uDir).sort(), ['GENRES', 'Mine.m3u8', 'Warm-up.m3u8'], 'written straight into the chosen folder');
  assert.deepStrictEqual(fs.readdirSync(path.join(m3uDir, 'GENRES')), ['Rollers.m3u8']);
  lib.close();
});
