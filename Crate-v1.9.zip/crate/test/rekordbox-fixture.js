'use strict';
// Builds a realistic rekordbox 6 library for tests: the real master.db schema (pyrekordbox test data, MIT)
// with our own tracks, playlists and a masterPlaylists6.xml added.
const fs = require('fs');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

const DATA = process.env.CRATE_TESTDATA || path.join(__dirname, '..', '..', 'crate-testdata');
const RB = path.join(DATA, 'rekordbox6');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'crate-rbfix-'));
const hex = (id) => BigInt(id).toString(16).toUpperCase();

/** A realistic rekordbox library: the real master.db schema with our own rows added. */
function makeRekordbox(musicDir) {
  const dir = tmp(); const dbFile = path.join(dir, 'master.db');
  // Decrypted from the real encrypted file, so pages keep SQLCipher's layout (80 reserved bytes), like a real master.db.
  require('../src/core/import/sqlcipher').decryptFile(path.join(RB, 'master_locked.db'), dbFile, '402fd482c38817c35ffa8ffb8c7d93143b749e7d315df7a81732a1ff43608497');
  const db = new DatabaseSync(dbFile);
  const now = '2024-05-01 10:00:00.000 +00:00';
  const ins = (table, row) => db.prepare(`INSERT INTO ${table} (${Object.keys(row).join(',')}, created_at, updated_at) VALUES (${Object.keys(row).map(() => '?').join(',')}, ?, ?)`).run(...Object.values(row), now, now);
  ins('djmdArtist', { ID: '901', Name: 'Eric Prydz' }); ins('djmdArtist', { ID: '902', Name: 'Daft Punk' }); ins('djmdArtist', { ID: '903', Name: 'Todd Edwards' });
  ins('djmdKey', { ID: '801', ScaleName: 'Am' }); ins('djmdKey', { ID: '802', ScaleName: '10B' });
  ins('djmdGenre', { ID: '701', Name: 'Progressive House' }); ins('djmdGenre', { ID: '702', Name: 'French House' });
  ins('djmdLabel', { ID: '601', Name: 'Virgin' }); ins('djmdAlbum', { ID: '501', Name: 'Discovery' });
  const content = (id, file, title, artist, extra = {}) => ins('djmdContent', { ID: id, FolderPath: file, Title: title, ArtistID: artist, rb_local_deleted: 0, ...extra });
  content('1001', path.join(musicDir, 'Opus.mp3'), 'Opus', '901', { BPM: 12600, Length: 6, Rating: 5, ReleaseYear: 2015, GenreID: '701', KeyID: '801', LabelID: '601', Commnt: 'Closer', StockDate: '2023-01-02' });
  content('1002', path.join(musicDir, 'OMT.flac'), 'One More Time', '902', { BPM: 12300, Length: 6, Rating: 4, GenreID: '702', KeyID: '802', AlbumID: '501', RemixerID: '903', Subtitle: 'Radio Edit' });
  content('1003', 'C:/Users/dj/Music/Gone/Lost Track.mp3', 'Lost Track', '902', { BPM: 12800, Length: 300, Rating: 3 });
  content('1004', path.join(musicDir, 'Deleted.mp3'), 'Deleted in rekordbox', '902', { rb_local_deleted: 1 });
  // Cue points on Opus: hot A, hot loop C, hot D (Kind 5), a memory cue, a memory loop, and a deleted cue.
  const cue = (id, content, kind, inMs, outMs, extra = {}) => ins('djmdCue', { ID: id, ContentID: content, Kind: kind, InMsec: inMs, InFrame: Math.floor(inMs * 0.15),
    OutMsec: outMs, OutFrame: outMs > 0 ? Math.floor(outMs * 0.15) : 0, Color: -1, ColorTableIndex: 0, Comment: '', rb_local_deleted: 0, ...extra });
  cue('4001', '1001', 1, 1500, -1, { ColorTableIndex: 22, Comment: 'Intro' }); cue('4002', '1001', 3, 2000, 4000);
  cue('4003', '1001', 5, 3250, -1, { ColorTableIndex: 42, Comment: 'Drop' }); cue('4004', '1001', 0, 250, -1, { Color: 1 });
  cue('4005', '1001', 0, 4500, 5500); cue('4006', '1001', 2, 100, -1, { rb_local_deleted: 1 });
  const pl = (id, name, attr, parent, seq, extra = {}) => ins('djmdPlaylist', { ID: id, Name: name, Attribute: attr, ParentID: parent, Seq: seq, rb_local_deleted: 0, ...extra });
  pl('2001', 'Gigs', 1, 'root', 3); pl('2002', 'Warm-up', 0, '2001', 1); pl('2003', 'Peak', 0, '2001', 2);
  pl('2004', 'Prog 125-130', 4, 'root', 4, { SmartList: '<NODE Id="-1692717240" LogicalOperator="1" AutomaticUpdate="0"><CONDITION PropertyName="genre" Operator="8" ValueUnit="" ValueLeft="Progressive" ValueRight=""/><CONDITION PropertyName="bpm" Operator="5" ValueUnit="" ValueLeft="12500" ValueRight="13000"/></NODE>' });
  pl('2007', 'Tagged peak', 4, 'root', 7, { SmartList: '<NODE Id="-1692717239" LogicalOperator="1" AutomaticUpdate="0"><CONDITION PropertyName="myTag" Operator="8" ValueUnit="" ValueLeft="-12345" ValueRight=""/></NODE>' }); pl('2005', 'Bin', 0, 'root', 5, { rb_local_deleted: 1 }); pl('2006', 'Orphan', 0, 'root', 6);
  const song = (id, plId, contentId, no) => ins('djmdSongPlaylist', { ID: id, PlaylistID: plId, ContentID: contentId, TrackNo: no, rb_local_deleted: 0 });
  song('3001', '2002', '1002', 1); song('3002', '2002', '1001', 2); song('3003', '2002', '1003', 3); song('3004', '2002', '1004', 4);
  song('3005', '2003', '1001', 1);
  db.close();
  // masterPlaylists6.xml lists what exists; "Orphan" (2006) is left out on purpose.
  const nodes = [['100000', '0', -128], ['2602250856', '0', 0], ['2001', '0', 1], ['2002', '2001', 0], ['2003', '2001', 0], ['2004', '0', 4], ['2007', '0', 4]]
    .map(([id, p, a]) => `    <NODE Id="${hex(id)}" ParentId="${p === '0' ? '0' : hex(p)}" Attribute="${a}" Timestamp="0" Lib_Type="0" CheckType="0"/>`);
  fs.writeFileSync(path.join(dir, 'masterPlaylists6.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<MASTER_PLAYLIST Version="3.0.0" AutomaticSync="0">\n  <PRODUCT Name="rekordbox" Version="6.6.2" Company="Pioneer DJ"/>\n  <PLAYLISTS>\n${nodes.join('\n')}\n  </PLAYLISTS>\n</MASTER_PLAYLIST>\n`);
  return dir;
}


module.exports = { makeRekordbox, RB, available: () => fs.existsSync(path.join(RB, 'master_unlocked.db')) };
