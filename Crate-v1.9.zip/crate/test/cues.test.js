'use strict';
// Cue points: conversion to and from rekordbox, Engine DJ and Serato tags.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const cues = require('../src/core/cues');
const id3 = require('../src/core/tags/id3');
const { readTags } = require('../src/core/tags');
const rekordboxXml = require('../src/core/export/rekordbox');
const { Library } = require('../src/core/library');

const FIX = path.join(__dirname, 'fixtures');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'crate-cues-'));

const SAMPLE = [
  { kind: 'hot', num: 0, start: 1.5, end: null, name: 'Intro', color: '#28e214' },
  { kind: 'hot', num: 3, start: 33.488367, end: null, name: '', color: '#ce3232' },
  { kind: 'hot', num: 5, start: 60, end: 64, name: 'Hot loop', color: null },
  { kind: 'loop', num: 7, start: 122.84, end: 145.16, name: 'Break', color: '#ef8130' },
  { kind: 'memory', num: null, start: 0.25, end: null, name: 'Load here', color: null },
];

test('normalize: drops bad cues and duplicates, sorts', () => {
  const out = cues.normalize([...SAMPLE, { kind: 'hot', num: 0, start: 9 }, { kind: 'hot', num: 8, start: 1 }, { kind: 'loop', num: 1, start: 4 },
    { kind: 'bogus', start: 1 }, { kind: 'memory', start: -1 }, { kind: 'memory', start: 5, end: 4, color: 'red' }]);
  assert.deepStrictEqual(out.map(c => [c.kind, c.num, c.start, c.end, c.color]), [
    ['hot', 0, 1.5, null, '#28e214'], ['hot', 3, 33.488367, null, '#ce3232'], ['hot', 5, 60, 64, null], ['loop', 7, 122.84, 145.16, '#ef8130'],
    ['memory', null, 0.25, null, null], ['memory', null, 5, null, null]]);
  assert.deepStrictEqual(SAMPLE.map(cues.label), ['A', 'D', 'F', 'Loop 8', 'Memory']);
});

test('Engine DJ: blobs match the layout Engine itself writes, and round-trip', () => {
  const rate = 44100;
  // Engine's own blob for 8 unnamed default hot cues is 169 bytes; loops with one "Loop 8" is 198 (from a real library).
  const eight = Array.from({ length: 8 }, (_, i) => ({ kind: 'hot', num: i, start: i * 10 + 1 }));
  const e8 = cues.toEngine(eight, rate);
  assert.strictEqual(cues.qUncompress(e8.quickCues).length, 169);
  assert.strictEqual(e8.quickCues.readUInt32BE(0), 169, 'qCompress length prefix');
  const one = cues.toEngine([{ kind: 'loop', num: 7, start: 1, end: 2 }], rate);
  assert.strictEqual(one.loops.length, 198);
  const empty = cues.toEngine([], rate);
  assert.strictEqual(empty.loops.subarray(8, 31).toString('hex'), '00' + '000000000000f0bf'.repeat(2) + '0000' + 'ff000000', 'empty loop slot as Engine writes it');

  const enc = cues.toEngine(SAMPLE, rate);
  const back = cues.fromEngine({ trackData: cues.makeEngineTrackData(rate, 300 * rate), quickCues: enc.quickCues, loops: enc.loops });
  const want = cues.normalize([
    ...SAMPLE.filter(c => c.kind === 'hot').map(c => ({ ...c, end: null, color: c.color || ['#4b88e2', '#1ebc61', '#f4d345', '#ce3232'][c.num % 4] })),
    { ...SAMPLE[3] }, { kind: 'loop', num: 0, start: 60, end: 64, name: 'Hot loop', color: '#ef8130' },
    { kind: 'memory', num: null, start: 0.25, end: null, name: '', color: null }]);
  const inSamples = (l) => l.map(c => ({ ...c, start: Math.round(c.start * rate), end: c.end == null ? null : Math.round(c.end * rate) }));
  assert.deepStrictEqual(inSamples(back), inSamples(want), 'hot cues, saved loop, hot loop in a free loop pad, memory cue as the main cue (same sample)');
  assert.strictEqual(enc.dropped, 0);
  // Positions are exact to the sample: hot cue D (written as "Cue 4") sits after A ("Intro") and two empty pads.
  const q = cues.qUncompress(enc.quickCues); assert.strictEqual(q.readDoubleBE(8 + (1 + 5 + 12) + 2 * (1 + 12) + 1 + 5), Math.round(33.488367 * rate));
  assert.strictEqual(q.subarray(8 + 1 + 5 + 8, 8 + 1 + 5 + 12).toString('hex'), 'ff28e214', 'set pad: ARGB colour');
  assert.strictEqual(q.subarray(8 + 18 + 9, 8 + 18 + 13).toString('hex'), '00000000', 'empty pad colour as Engine writes it');
  // Engine's default main cue is kept when Crate has no memory cue.
  const withDefault = cues.qUncompress(enc.quickCues); withDefault.writeDoubleBE(12345, withDefault.length - 8);
  const keep = cues.qUncompress(cues.toEngine([eight[0]], rate, cues.qCompress(withDefault)).quickCues);
  assert.deepStrictEqual([keep.readDoubleBE(keep.length - 17), keep[keep.length - 9], keep.readDoubleBE(keep.length - 8)], [12345, 0, 12345]);
});

test('rekordbox: djmdCue rows and XML position marks', () => {
  const rows = [
    { Kind: 1, InMsec: 1500, OutMsec: -1, ColorTableIndex: 22, Color: -1, Comment: 'A' },
    { Kind: 3, InMsec: 2000, OutMsec: 4000, ColorTableIndex: 0, Color: -1, Comment: '' },
    { Kind: 5, InMsec: 9000, OutMsec: -1, ColorTableIndex: 1, Color: -1, Comment: 'D' },
    { Kind: 9, InMsec: 9500, OutMsec: -1, ColorTableIndex: 62, Color: -1, Comment: 'H' },
    { Kind: 0, InMsec: 250, OutMsec: -1, ColorTableIndex: null, Color: 1, Comment: 'mem' },
    { Kind: 0, InMsec: 30000, OutMsec: 38000, ColorTableIndex: null, Color: -1, Comment: '' },
  ];
  assert.deepStrictEqual(rows.map(cues.fromRekordboxRow).map(c => [c.kind, c.num, c.start, c.end, c.color]), [
    ['hot', 0, 1.5, null, '#28e214'], ['hot', 2, 2, 4, null], ['hot', 3, 9, null, '#305aff'], ['hot', 7, 9.5, null, '#6473ff'],
    ['memory', null, 0.25, null, '#e62828'], ['memory', null, 30, 38, null]]);
  const marks = cues.toRekordboxMarks(SAMPLE);
  assert.deepStrictEqual(marks, [
    { Name: 'Intro', Type: 0, Start: '1.500', Num: 0, Red: 40, Green: 226, Blue: 20 },
    { Name: '', Type: 0, Start: '33.488', Num: 3, Red: 206, Green: 50, Blue: 50 },
    { Name: 'Hot loop', Type: 4, Start: '60.000', Num: 5, End: '64.000' },
    { Name: 'Break', Type: 4, Start: '122.840', Num: -1, End: '145.160' },
    { Name: 'Load here', Type: 0, Start: '0.250', Num: -1 }]);
  const xml = rekordboxXml.build([{ id: 7, title: 'T', path: '/m/t.mp3', duration: 300 }, { id: 8, title: 'U', path: '/m/u.mp3', duration: 300 }], [],
    { cues: new Map([[7, SAMPLE]]) });
  assert.match(xml, /<TRACK TrackID="7"[^>]*>\n      <POSITION_MARK Name="Intro" Type="0" Start="1.500" Num="0" Red="40" Green="226" Blue="20"\/>/);
  assert.match(xml, /<TRACK TrackID="8"[^>]*\/>/, 'tracks without cues stay self-closing');
  assert.strictEqual((xml.match(/<POSITION_MARK/g) || []).length, 5);
});

// Builds Serato's "Serato Markers2" GEOB payload the way Serato DJ and Mixed In Key write it.
function seratoMarkers2(entries) {
  const parts = [Buffer.from([1, 1])];
  for (const e of entries) {
    let p;
    if (e.type === 'CUE') {
      const name = Buffer.from(e.name + '\0', 'utf8'); p = Buffer.alloc(12 + name.length);
      p[1] = e.index; p.writeUInt32BE(e.ms, 2); p[7] = e.rgb[0]; p[8] = e.rgb[1]; p[9] = e.rgb[2]; name.copy(p, 12);
    } else if (e.type === 'LOOP') {
      const name = Buffer.from(e.name + '\0', 'utf8'); p = Buffer.alloc(19 + name.length);
      p[1] = e.index; p.writeUInt32BE(e.start, 2); p.writeUInt32BE(e.end, 6); p.fill(0xff, 10, 14); p.set([0, 0x27, 0xaa, 0xe1], 14); name.copy(p, 19);
    } else p = Buffer.from([0, 0xcc, 0, 0]); // COLOR
    const len = Buffer.alloc(4); len.writeUInt32BE(p.length);
    parts.push(Buffer.from(e.type + '\0', 'latin1'), len, p);
  }
  parts.push(Buffer.from([0]));
  const b64 = Buffer.concat(parts).toString('base64').replace(/=+$/, '').replace(/(.{72})/g, '$1\n');
  return Buffer.concat([Buffer.from([1, 1]), Buffer.from(b64, 'latin1'), Buffer.alloc(470 - b64.length > 0 ? 470 - b64.length : 1)]);
}
const ENTRIES = [{ type: 'COLOR' }, { type: 'CUE', index: 0, ms: 1234, rgb: [0xcc, 0, 0], name: 'Drop' }, { type: 'CUE', index: 2, ms: 60500, rgb: [0, 0xcc, 0], name: '' },
  { type: 'LOOP', index: 1, start: 30000, end: 37500, name: 'Groove' }];
const WANT = [['hot', 0, 1.234, null, 'Drop', '#cc0000'], ['hot', 2, 60.5, null, '', '#00cc00'], ['loop', 1, 30, 37.5, 'Groove', null]];
const flat = (l) => l.map(c => [c.kind, c.num, c.start, c.end, c.name, c.color]);

test('Serato Markers2: GEOB payload and the FLAC/MP4 base64 form', () => {
  const geob = seratoMarkers2(ENTRIES);
  assert.deepStrictEqual(flat(cues.fromSeratoMarkers2(geob)), WANT);
  const wrapped = Buffer.concat([Buffer.from('application/octet-stream\0\0Serato Markers2\0', 'latin1'), geob]).toString('base64');
  assert.deepStrictEqual(flat(cues.fromSeratoMarkers2(wrapped)), WANT, 'FLAC/MP4 form');
  assert.deepStrictEqual(cues.fromSeratoMarkers2(Buffer.from('garbage')), []);
});

test('Serato cues are read from an MP3 on import, and never replace imported cues', async () => {
  const dir = tmp(); const file = path.join(dir, 'serato.mp3');
  const geobData = Buffer.concat([Buffer.from([0]), Buffer.from('application/octet-stream\0', 'latin1'), Buffer.from('\0', 'latin1'), Buffer.from('Serato Markers2\0', 'latin1'), seratoMarkers2(ENTRIES)]);
  const tag = id3.build({ version: 4, flags: 0, frames: [{ id: 'GEOB', flags: 0, data: geobData }] }, { title: 'Serato track' }, 0);
  fs.writeFileSync(file, Buffer.concat([tag, fs.readFileSync(path.join(FIX, 't_notag_cbr.mp3'))]));
  assert.deepStrictEqual(flat(readTags(file).cues), WANT);
  const lib = new Library(path.join(dir, 'lib.db'));
  await lib.importPaths([dir]);
  const t = lib.listTracks()[0]; assert.strictEqual(t.cues, 3, 'cue count in the track list');
  assert.deepStrictEqual(flat(lib.getCues(t.id)), WANT);
  // Cues imported from a DJ app win over the file's Serato cues, even when the file changes later.
  lib.setCues(t.id, [{ kind: 'hot', num: 4, start: 9 }], 'engine');
  fs.utimesSync(file, new Date(), new Date(Date.now() + 5000)); await lib.importPaths([dir]);
  assert.deepStrictEqual(lib.getCues(t.id).map(c => [c.num, c.source]), [[4, 'engine']]);
  lib.close();
});
