'use strict';
// The window reopens at its last size and position, but never off-screen.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const ws = require('../src/main/windowstate');

const MAIN = { x: 0, y: 25, width: 1512, height: 920 };      // a MacBook screen's work area
const EXTERNAL = { x: 1512, y: 0, width: 2560, height: 1415 }; // a monitor to its right

test('saves and loads the state', () => {
  const f = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'crate-ws-')), 'window-state.json');
  assert.strictEqual(ws.load(f), null, 'nothing saved yet');
  ws.save(f, { x: 100, y: 80, width: 1300, height: 800, maximized: true, fullScreen: false });
  assert.deepStrictEqual(ws.load(f), { x: 100, y: 80, width: 1300, height: 800, maximized: true, fullScreen: false });
  fs.writeFileSync(f, 'not json'); assert.strictEqual(ws.load(f), null, 'a damaged file is ignored');
});

test('fit: restores, shrinks to the screen, and never opens off-screen', () => {
  assert.deepStrictEqual(ws.fit(null, [MAIN]), ws.DEFAULTS, 'first launch: default size, centred');
  assert.deepStrictEqual(ws.fit({ x: 120, y: 60, width: 1300, height: 820 }, [MAIN]), { x: 120, y: 60, width: 1300, height: 820 }, 'same size and place');
  assert.deepStrictEqual(ws.fit({ x: 1800, y: 100, width: 2200, height: 1300 }, [MAIN, EXTERNAL]), { x: 1800, y: 100, width: 2200, height: 1300 }, 'on the external monitor');
  assert.deepStrictEqual(ws.fit({ x: 1800, y: 100, width: 2200, height: 1300 }, [MAIN]), { width: 1512, height: 920 }, 'monitor unplugged: shrunk to fit and centred');
  assert.deepStrictEqual(ws.fit({ x: 50, y: 40, width: 600, height: 300 }, [MAIN]), { x: 50, y: 40, width: 1100, height: 640 }, 'never smaller than the minimum');
  assert.deepStrictEqual(ws.fit({ x: 10, y: -500, width: 1200, height: 700 }, [MAIN]), { width: 1200, height: 700 }, 'title bar above the screen: centred instead');
});
