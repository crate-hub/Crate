'use strict';
// Renaming files to "Artist - Title".
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { sanitize, plan } = require('../src/core/rename');
const { Library } = require('../src/core/library');
const { writeTags } = require('../src/core/tags');
const engineExport = require('../src/core/export/engine');

const FIX = path.join(__dirname, 'fixtures');
const DATA = process.env.CRATE_TESTDATA || path.join(__dirname, '..', '..', 'crate-testdata');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'crate-ren-'));

test('sanitize: safe on macOS, Windows and USB sticks', () => {
  assert.strictEqual(sanitize('AC/DC'), 'AC - DC');
  assert.strictEqual(sanitize('Title: The Remix'), 'Title - The Remix');
  assert.strictEqual(sanitize('What? <Live> | "Edit"*'), "What Live 'Edit'");
  assert.strictEqual(sanitize('  Spaced   out ... '), 'Spaced out');
  assert.strictEqual(sanitize('Café'.normalize('NFD')), 'Café'.normalize('NFC'));
  assert.ok(Buffer.byteLength(sanitize('é'.repeat(400))) <= 240);
});

test('plan: names, clashes, case-only changes and skips', () => {
  const dir = tmp(); const f = (n) => { const p = path.join(dir, n); fs.writeFileSync(p, n); return p; };
  const a = f('01 track.mp3'), b = f('other.mp3'), c = f('noise - opus.aiff'), d = f('x.flac');
  f('Daft Punk - One More Time.mp3'); // someone else already has the name
  const out = plan([
    { id: 1, path: a, artist: 'Daft Punk', title: 'One More Time' },
    { id: 2, path: b, artist: 'Daft Punk', title: 'One More Time' },
    { id: 3, path: c, artist: 'Noise', title: 'Opus' },
    { id: 4, path: d, artist: '', title: 'No Artist' },
    { id: 5, path: path.join(dir, 'gone.mp3'), artist: 'A', title: 'B' },
    { id: 6, path: path.join(dir, 'Daft Punk - One More Time.mp3'), artist: 'Daft Punk', title: 'One More Time' },
  ]);
  assert.deepStrictEqual(out.map(p => [p.id, p.status, p.to && path.basename(p.to)]), [
    [1, 'rename', 'Daft Punk - One More Time (2).mp3'], [2, 'rename', 'Daft Punk - One More Time (3).mp3'],
    [3, 'rename', 'Noise - Opus.aiff'], [4, 'noTags', null], [5, 'missing', null], [6, 'same', 'Daft Punk - One More Time.mp3']]);
});

test('rename files, undo, and Engine keeps the renamed track and its cues', { skip: !fs.existsSync(path.join(DATA, 'engine_schema.sql')) }, async () => {
  const work = tmp(); const music = path.join(work, 'Engine Library', 'Music'); fs.mkdirSync(music, { recursive: true });
  const file = path.join(music, '03 opus_final.mp3'); fs.copyFileSync(path.join(FIX, 't_v23.mp3'), file);
  writeTags(file, { title: 'Opus', artist: 'Eric Prydz' });
  const lib = new Library(path.join(work, 'lib.db')); await lib.importPaths([music]);
  const t = lib.listTracks()[0];
  lib.setCues(t.id, [{ kind: 'hot', num: 0, start: 1 }], 'engine');
  const engLib = path.join(work, 'Engine Library'); fs.mkdirSync(path.join(engLib, 'Database2'));
  const e = new DatabaseSync(path.join(engLib, 'Database2', 'm.db')); e.exec(fs.readFileSync(path.join(DATA, 'engine_schema.sql'), 'utf8'));
  e.prepare("INSERT INTO Information (uuid, schemaVersionMajor, schemaVersionMinor, schemaVersionPatch) VALUES ('u1', 3, 0, 1)").run(); e.close();
  const exp = () => engineExport.exportTo(lib.listTracks(), [], { libraryDir: engLib, cues: lib.cuesByTrack([t.id]), previousPaths: lib.previousPaths([t.id]) });
  exp();
  const engineRow = () => { const d = new DatabaseSync(path.join(engLib, 'Database2', 'm.db'), { readOnly: true }); try { return d.prepare('SELECT t.id, t.path, t.filename, p.quickCues IS NOT NULL AS cues FROM Track t JOIN PerformanceData p ON p.trackId = t.id').all(); } finally { d.close(); } };
  const before = engineRow(); assert.strictEqual(before.length, 1);

  const r = lib.renameFiles([t.id]);
  const want = path.join(music, 'Eric Prydz - Opus.mp3');
  assert.deepStrictEqual([r.renamed.length, r.errors.length], [1, 0]);
  assert.ok(fs.existsSync(want) && !fs.existsSync(file), 'renamed on disk');
  assert.strictEqual(lib.getTracks([t.id])[0].path, want, 'and in the library');
  assert.strictEqual(lib.getCues(t.id).length, 1, 'cues stay with the track');
  assert.deepStrictEqual(lib.previewRenames([t.id]).map(p => p.status), ['same'], 'nothing left to do');

  const res = exp();
  assert.strictEqual(res.moved, 1);
  const after = engineRow();
  assert.deepStrictEqual(after.map(x => [x.id, x.path, x.filename, x.cues]), [[before[0].id, 'Music/Eric Prydz - Opus.mp3', 'Eric Prydz - Opus.mp3', 1]], "Engine's track moved, not duplicated");

  const u = lib.undoRenames(r.renamed);
  assert.deepStrictEqual([u.restored, u.errors.length], [1, 0]);
  assert.ok(fs.existsSync(file) && !fs.existsSync(want));
  assert.strictEqual(lib.getTracks([t.id])[0].path, file);
  lib.close();
});
