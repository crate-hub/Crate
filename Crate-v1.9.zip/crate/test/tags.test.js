'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { readTags, writeTags } = require('../src/core/tags');

const FIX = path.join(__dirname, 'fixtures');
const has = (bin) => { try { execFileSync(bin, ['-version'], { stdio: 'ignore' }); return true; } catch { return false; } };
const FF = has('ffprobe');

function probe(file) {
  const out = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration:format_tags:stream=codec_type', '-of', 'json', file]).toString());
  const tags = {}; for (const [k, v] of Object.entries(out.format.tags || {})) tags[k.toLowerCase()] = v;
  return { tags, duration: +out.format.duration, streams: out.streams.map(s => s.codec_type) };
}
function decodesCleanly(file) {
  const r = require('child_process').spawnSync('ffmpeg', ['-v', 'error', '-i', file, '-f', 'null', '-'], { encoding: 'utf8' });
  return r.status === 0 && !r.stderr.trim();
}
function tmpCopy(name) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'crate-')); const p = path.join(dir, name);
  fs.copyFileSync(path.join(FIX, name), p); return p;
}

const files = ['t_v23.mp3', 't_v24_vbr.mp3', 't_notag_cbr.mp3', 't.flac', 't.m4a', 't_faststart.m4a', 't.aiff', 't.wav', 't_art.mp3', 't_art.m4a', 't_art.flac'];

test('reads ffmpeg-written tags and stream info', () => {
  for (const f of files) {
    const r = readTags(path.join(FIX, f));
    assert.ok(Math.abs(r.duration - 6) < 0.1, `${f} duration ${r.duration}`);
    assert.ok(r.sampleRate === 44100, `${f} sampleRate ${r.sampleRate}`);
    if (f === 't_notag_cbr.mp3') { assert.deepStrictEqual(r.fields, {}); assert.strictEqual(r.bitrate, 128); continue; }
    assert.strictEqual(r.fields.title, 'Strobe', f);
    assert.strictEqual(r.fields.artist, 'deadmau5', f);
    assert.strictEqual(r.fields.genre, 'Progressive_House', f);
    assert.strictEqual(r.fields.year, 2009, f);
    if (!f.endsWith('.wav')) assert.strictEqual(r.fields.album, 'For_Lack', f);
    if (/mp3|flac|aiff/.test(f)) { assert.strictEqual(r.fields.bpm, 128, f); assert.strictEqual(r.fields.label, 'mau5trap', f); }
    if (/mp3|flac/.test(f)) assert.strictEqual(r.fields.key, 'Am', f);
    assert.strictEqual(r.fields.comment, 'Peak_time', f);
  }
  assert.strictEqual(readTags(path.join(FIX, 't_v23.mp3')).bitrate, 192);
});

const NEW = { title: 'Café del Mar (Björk ☕ Remix)', artist: 'Energy 52', bpm: 124, key: '8A', rating: 4,
  label: 'Superstition', remixer: 'Björk', comment: 'Energy 7 — opener', genre: 'Trance', year: 1993, grouping: 'Classics' };

for (const f of files) {
  test(`write + re-read: ${f}`, () => {
    const p = tmpCopy(f);
    const before = FF ? probe(p) : null;
    const origAlbum = readTags(p).fields.album;
    const how1 = writeTags(p, NEW);
    const r = readTags(p);
    for (const [k, v] of Object.entries(NEW)) assert.deepStrictEqual(r.fields[k], v, `${f}: ${k} (written ${how1})`);
    assert.strictEqual(r.fields.album, origAlbum, `${f}: untouched album kept`);
    assert.ok(Math.abs(r.duration - 6) < 0.1, `${f}: duration after write`);
    // second, small edit should usually be in place
    const how2 = writeTags(p, { rating: 5, title: 'Short' });
    const r2 = readTags(p);
    assert.strictEqual(r2.fields.rating, 5); assert.strictEqual(r2.fields.title, 'Short'); assert.strictEqual(r2.fields.artist, 'Energy 52');
    if (/\.(mp3|flac)$/.test(f)) assert.strictEqual(how2, 'in-place', `${f}: second write mode`);
    // clearing a field
    writeTags(p, { comment: '' });
    assert.strictEqual(readTags(p).fields.comment, undefined, `${f}: comment cleared`);
    if (FF) {
      const after = probe(p);
      assert.ok(decodesCleanly(p), `${f}: ffmpeg decodes without errors`);
      assert.ok(Math.abs(after.duration - before.duration) < 0.05, `${f}: ffprobe duration ${before.duration} -> ${after.duration}`);
      assert.deepStrictEqual(after.streams, before.streams, `${f}: streams (artwork) preserved`);
      assert.strictEqual(after.tags.title, 'Short', `${f}: ffprobe sees new title`);
      assert.strictEqual(after.tags.artist, 'Energy 52', `${f}: ffprobe sees artist`);
    }
    fs.rmSync(path.dirname(p), { recursive: true, force: true });
  });
}

test('mp4: chunk offsets shift correctly when moov precedes mdat (faststart)', () => {
  const p = tmpCopy('t_faststart.m4a');
  writeTags(p, { comment: 'x'.repeat(5000) }); // grows moov by ~5 KB
  assert.ok(decodesCleanly(p));
  writeTags(p, { comment: 'short' }); // shrinks it again
  assert.ok(decodesCleanly(p));
  assert.strictEqual(readTags(p).fields.comment, 'short');
});

test('mp3: big edit forces rewrite and keeps audio intact', () => {
  const p = tmpCopy('t_v23.mp3');
  const how = writeTags(p, { comment: 'y'.repeat(20000) });
  assert.strictEqual(how, 'rewrite');
  assert.ok(decodesCleanly(p));
  assert.strictEqual(readTags(p).fields.comment.length, 20000);
  assert.ok(!fs.readdirSync(path.dirname(p)).some(n => n.includes('crate-tmp')), 'temp file cleaned up');
});
