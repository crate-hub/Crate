'use strict';
// AIFF -> WAV streaming for the player (Chromium can't decode AIFF).
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { probe, wavStream } = require('../src/core/aiffstream');

const collect = async (s) => { const parts = []; for await (const c of s) parts.push(c); return Buffer.concat(parts); };
const hasFfmpeg = (() => { try { execFileSync('ffmpeg', ['-version'], { stdio: 'ignore' }); return true; } catch { return false; } })();

test('fixture AIFF becomes a valid WAV with the same samples', async () => {
  const file = path.join(__dirname, 'fixtures', 't.aiff');
  const p = probe(file); assert.ok(p, 'probed');
  assert.strictEqual(p.channels, 2); assert.strictEqual(p.rate, 44100); assert.strictEqual(p.bits, 16);
  const wav = await collect(wavStream(file, p));
  assert.strictEqual(wav.length, p.size);
  assert.strictEqual(wav.toString('latin1', 0, 4), 'RIFF'); assert.strictEqual(wav.readUInt32LE(40), p.dataLen);
  const src = fs.readFileSync(file).subarray(p.dataStart, p.dataStart + p.dataLen);
  for (let i = 0; i < src.length; i += 2) if (src.readInt16BE(i) !== wav.readInt16LE(44 + i)) assert.fail(`sample ${i / 2} differs`);
});

test('any byte range matches the same slice of the whole WAV', async () => {
  const file = path.join(__dirname, 'fixtures', 't.aiff'); const p = probe(file);
  const whole = await collect(wavStream(file, p));
  const ranges = [[0, 0], [0, 43], [10, 50], [44, 44], [45, 46], [43, 1000], [p.size - 1, p.size - 1], [p.size - 7, p.size - 1]];
  for (let k = 0; k < 40; k++) { const a = Math.floor(Math.random() * p.size); ranges.push([a, Math.min(p.size - 1, a + Math.floor(Math.random() * 300000))]); }
  for (const [a, b] of ranges) assert.ok((await collect(wavStream(file, p, a, b))).equals(whole.subarray(a, b + 1)), `range ${a}-${b}`);
});

test('bit depths and AIFF-C variants match ffmpeg\'s decoding', { skip: !hasFfmpeg && 'ffmpeg not installed' }, async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'crate-aiff-'));
  const variants = [['s8', 'pcm_s8', 'aiff'], ['s16', 'pcm_s16be', 'aiff'], ['s24', 'pcm_s24be', 'aiff'], ['s32', 'pcm_s32be', 'aiff'],
    ['sowt', 'pcm_s16le', 'aiff'], ['f32', 'pcm_f32be', 'aiff'], ['mono24', 'pcm_s24be', 'aiff', 1]];
  for (const [name, codec, fmt, ch = 2] of variants) {
    const aif = path.join(dir, `${name}.aif`);
    execFileSync('ffmpeg', ['-v', 'error', '-f', 'lavfi', '-i', `sine=frequency=440:duration=1.3:sample_rate=48000`, '-ac', String(ch), '-c:a', codec, '-f', fmt, aif, '-y']);
    const p = probe(aif); assert.ok(p, `${name} probed`);
    const ours = path.join(dir, `${name}.ours.wav`); fs.writeFileSync(ours, await collect(wavStream(aif, p)));
    const raw = (f) => execFileSync('ffmpeg', ['-v', 'error', '-i', f, '-f', 'f64le', '-ac', String(ch), '-']);
    assert.ok(raw(ours).equals(raw(aif)), `${name}: same audio as ffmpeg decodes from the AIFF`);
  }
});

test('non-AIFF files are left alone', () => {
  assert.strictEqual(probe(path.join(__dirname, 'fixtures', 't.wav')), null);
  assert.strictEqual(probe(path.join(__dirname, 'fixtures', 't.flac')), null);
});
