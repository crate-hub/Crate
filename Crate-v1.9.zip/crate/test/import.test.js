'use strict';
// Importers: rekordbox (master.db + masterPlaylists6.xml) and Engine DJ (m.db).
// The rekordbox tests use real rekordbox 6 databases from the pyrekordbox project (MIT), kept in
// ../crate-testdata/rekordbox6 (not shipped); they are skipped when that folder is absent.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { Library } = require('../src/core/library');
const { writeTags, readTags } = require('../src/core/tags');
const { decryptFile } = require('../src/core/import/sqlcipher');
const rbImport = require('../src/core/import/rekordbox');
const engineImport = require('../src/core/import/engine');
const engineExport = require('../src/core/export/engine');
const keys = require('../src/core/keys');

const FIX = path.join(__dirname, 'fixtures');
const DATA = process.env.CRATE_TESTDATA || path.join(__dirname, '..', '..', 'crate-testdata');
const RB = path.join(DATA, 'rekordbox6');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'crate-imp-'));

test('sqlcipher: decrypts a real rekordbox 6 master.db', { skip: !fs.existsSync(RB) }, () => {
  const out = path.join(tmp(), 'plain.db');
  decryptFile(path.join(RB, 'master_locked.db'), out, '402fd482c38817c35ffa8ffb8c7d93143b749e7d315df7a81732a1ff43608497');
  const a = new DatabaseSync(out, { readOnly: true }), b = new DatabaseSync(path.join(RB, 'master_unlocked.db'), { readOnly: true });
  assert.strictEqual(a.prepare('PRAGMA integrity_check').get().integrity_check, 'ok');
  for (const t of ['djmdContent', 'djmdPlaylist', 'djmdArtist', 'djmdAlbum']) {
    const q = `SELECT * FROM ${t} ORDER BY ID`;
    assert.deepStrictEqual(a.prepare(q).all(), b.prepare(q).all(), `${t} identical to the reference`);
  }
  assert.throws(() => decryptFile(path.join(RB, 'master_locked.db'), out, 'wrong'), /Could not unlock/);
});

test('rekordbox: reads the real encrypted library', { skip: !fs.existsSync(RB) }, () => {
  const dir = tmp(); fs.copyFileSync(path.join(RB, 'master_locked.db'), path.join(dir, 'master.db')); fs.copyFileSync(path.join(RB, 'masterPlaylists6.xml'), path.join(dir, 'masterPlaylists6.xml'));
  const r = rbImport.read({ dir });
  assert.strictEqual(r.stats.bundledSkipped, 6, 'sampler sounds + demo tracks skipped');
  assert.strictEqual(r.tracks.length, 0);
  const all = rbImport.read({ dir, includeBundled: true });
  assert.deepStrictEqual(all.tracks.filter(t => /Demo Track/.test(t.fields.title)).map(t => [t.fields.title, t.fields.artist, t.fields.bpm, t.duration]),
    [['Demo Track 1', 'Loopmasters', 128, 172], ['Demo Track 2', 'Loopmasters', 120, 128]]);
  assert.deepStrictEqual(all.tree.map(n => n.name), ['Trial playlist - Cloud Library Sync'], 'system (-128) entry skipped');
});

const { makeRekordbox } = require('./rekordbox-fixture');

test('rekordbox: import into Crate (fill/overwrite, missing files, path fix, playlists)', { skip: !fs.existsSync(RB) }, async () => {
  const work = tmp(); const music = path.join(work, 'Music'); fs.mkdirSync(music);
  fs.copyFileSync(path.join(FIX, 't_v23.mp3'), path.join(music, 'Opus.mp3'));
  fs.copyFileSync(path.join(FIX, 't.flac'), path.join(music, 'OMT.flac'));
  writeTags(path.join(music, 'Opus.mp3'), { title: 'Opus (file tag)', comment: '' });
  writeTags(path.join(music, 'OMT.flac'), { title: '', artist: '', album: '', genre: '', comment: '', bpm: 0, key: '', label: '', composer: '', year: 0 }); // untagged file
  const rbDir = makeRekordbox(music);
  const lib = new Library(path.join(work, 'lib.db'));
  await lib.importPaths([path.join(music, 'Opus.mp3')]); // already in Crate before the import

  const src = rbImport.read({ dir: rbDir });
  assert.deepStrictEqual([src.stats.smartlists, src.stats.smartSkipped, src.stats.notInXml], [1, 1, 1], 'one smart list converted, the My Tag one skipped; Orphan not in masterPlaylists6.xml');
  assert.match(src.stats.smartSkippedList[0].reason, /My Tags/);
  assert.deepStrictEqual([src.stats.cueTracks, src.stats.cues], [1, 5], 'cue points read from djmdCue; the deleted one skipped');
  const r = await lib.importExternal(src, { rootName: 'From rekordbox' });
  assert.deepStrictEqual([r.added, r.updated, r.missing, r.failed.length], [1, 1, 1, 0]);
  const by = (title) => lib.listTracks().find(t => t.title === title);
  const opus = lib.listTracks().find(t => t.path.endsWith('Opus.mp3'));
  assert.strictEqual(opus.title, 'Opus (file tag)', "fill mode keeps Crate's title");
  assert.deepStrictEqual([opus.comment, opus.label, opus.rating], ['Closer', 'mau5trap', 5], 'empty fields filled from rekordbox; the file\'s own label kept');
  const omt = by('One More Time');
  assert.deepStrictEqual([omt.artist, omt.remixer, omt.mix, omt.album, omt.key, omt.bpm, omt.genre], ['Daft Punk', 'Todd Edwards', 'Radio Edit', 'Discovery', '10B', 123, 'French House']);
  assert.strictEqual(readTags(omt.path).fields.remixer, undefined, 'files untouched unless asked');
  assert.deepStrictEqual(lib.getCues(opus.id).map(c => [c.kind, c.num, c.start, c.end, c.name, c.color]), [
    ['hot', 0, 1.5, null, 'Intro', '#28e214'], ['hot', 2, 2, 4, '', null], ['hot', 3, 3.25, null, 'Drop', '#e62828'],
    ['memory', null, 0.25, null, '', '#e62828'], ['memory', null, 4.5, 5.5, '', null]], 'hot cues A/C/D, hot loop, memory cue and loop');
  assert.strictEqual(r.cueTracks, 1);
  const lost = by('Lost Track'); assert.strictEqual(lost.missing, 1); assert.strictEqual(lost.bpm, 128);
  assert.ok(!by('Deleted in rekordbox'), 'deleted rows skipped');
  // Playlist tree under one folder, order kept, deleted/missing entries handled
  const tree = lib.playlistTree({ withTracks: true });
  assert.ok(!tree.some(n => n.name === 'From rekordbox'), 'no "From rekordbox" folder: playlists go straight to the top level');
  const root = { children: tree };
  assert.deepStrictEqual(root.children.map(n => [n.name, n.type]), [['Trial playlist - Cloud Library Sync', 'playlist'], ['Gigs', 'folder'], ['Prog 125-130', 'smart']], 'rekordbox order (Seq); deleted, orphan and unconvertible lists left out');
  const prog = lib.listPlaylists().find(p => p.name === 'Prog 125-130');
  assert.deepStrictEqual(prog.rules, { match: 'all', conditions: [{ field: 'genre', op: 'contains', value: 'Progressive' }, { field: 'bpm', op: 'between', value: 125, value2: 130 }] }, 'BPM x100 converted');
  assert.deepStrictEqual(lib.listTracks({ playlistId: prog.id }).map(t => t.path.split('/').pop()), ['Opus.mp3'], 'live smartlist evaluates in Crate');
  const warm = root.children[1].children.find(n => n.name === 'Warm-up');
  assert.deepStrictEqual(lib.getTracks(warm.trackIds).map(t => t.title), ['One More Time', 'Opus (file tag)', 'Lost Track']);

  // Re-import with overwrite + path fix: replaces the folder, takes rekordbox's values, finds the moved file.
  fs.mkdirSync(path.join(work, 'Moved')); fs.copyFileSync(path.join(FIX, 't_v23.mp3'), path.join(work, 'Moved', 'Lost Track.mp3'));
  const r2 = await lib.importExternal(rbImport.read({ dir: rbDir }), { rootName: 'From rekordbox', replace: r.created, mode: 'overwrite', writeFiles: true,
    pathMap: [{ from: 'C:\\Users\\dj\\Music\\Gone', to: path.join(work, 'Moved') }] });
  assert.strictEqual(r2.added, 1, 'the relocated file is found');
  assert.strictEqual(lib.listTracks().find(t => t.path.endsWith('Opus.mp3')).title, 'Opus', 'overwrite mode');
  assert.strictEqual(readTags(path.join(music, 'Opus.mp3')).fields.title, 'Opus', 'written into the file');
  assert.deepStrictEqual(lib.playlistTree().map(n => n.name), ['Trial playlist - Cloud Library Sync', 'Gigs', 'Prog 125-130'], 'the previous import’s playlists replaced, not duplicated');
  lib.close();
});

test('rekordbox: plain-text master.db and missing masterPlaylists6.xml', { skip: !fs.existsSync(RB) }, () => {
  const work = tmp(); const rbDir = makeRekordbox(path.join(work, 'Music'));
  fs.rmSync(path.join(rbDir, 'masterPlaylists6.xml'));
  const r = rbImport.read({ dir: rbDir });
  assert.strictEqual(r.stats.notInXml, 0);
  assert.ok(r.tree.some(n => n.name === 'Orphan'), 'without the XML every live playlist is used');
  assert.ok(rbImport.inspect(rbDir).ok);
});

test('engine: round trip Crate -> Engine DJ -> Crate', { skip: !fs.existsSync(path.join(DATA, 'engine_schema.sql')) }, async () => {
  const work = tmp(); const music = path.join(work, 'Music'); fs.mkdirSync(music);
  const specs = [['a.mp3', 't_v23.mp3', { title: 'Alpha', artist: 'A', key: 'F#m', bpm: 174.5, rating: 4, genre: 'D&B', label: 'Hospital' }],
    ['b.flac', 't.flac', { title: 'Bravo', artist: 'B', key: '8B', bpm: 128, rating: 2 }], ['c.m4a', 't.m4a', { title: 'Charlie', artist: 'C', key: '', bpm: 0, rating: 0 }]];
  for (const [n, s, t] of specs) { fs.copyFileSync(path.join(FIX, s), path.join(music, n)); writeTags(path.join(music, n), t); }
  const a = new Library(path.join(work, 'a.db')); await a.importPaths([music]);
  const f = a.createPlaylist({ name: 'Sets', type: 'folder' }); const p1 = a.createPlaylist({ name: 'Rollers', parentId: f }); const p2 = a.createPlaylist({ name: 'Openers' });
  const ids = Object.fromEntries(a.listTracks().map(t => [t.title, t.id]));
  a.addToPlaylist(p1, [ids.Charlie, ids.Alpha, ids.Bravo]); a.addToPlaylist(p2, [ids.Bravo]);
  a.createPlaylist({ name: 'Fast', type: 'smart', parentId: f, rules: { match: 'all', conditions: [{ field: 'bpm', op: 'gt', value: 170 }, { field: 'genre', op: 'is', value: 'D&B' }] } });
  a.createPlaylist({ name: 'Top 1', type: 'smart', rules: { conditions: [{ field: 'rating', op: 'gt', value: 0 }], limit: 1 } });
  const alphaCues = [{ kind: 'hot', num: 0, start: 1.25, name: 'In', color: '#cc0000' }, { kind: 'hot', num: 7, start: 4.5 }, { kind: 'loop', num: 2, start: 2, end: 3, name: 'Roll', color: '#00aaff' },
    { kind: 'memory', start: 0.5 }];
  a.setCues(ids.Alpha, alphaCues, 'rekordbox');
  // Engine Library with an extra Engine-only playlist that has both tracks and a child list
  const engLib = path.join(work, 'Engine Library'); fs.mkdirSync(path.join(engLib, 'Database2'), { recursive: true });
  const e = new DatabaseSync(path.join(engLib, 'Database2', 'm.db')); e.exec(fs.readFileSync(path.join(DATA, 'engine_schema.sql'), 'utf8'));
  e.prepare("INSERT INTO Information (uuid, schemaVersionMajor, schemaVersionMinor, schemaVersionPatch) VALUES ('u1', 3, 0, 1)").run(); e.close();
  const ex = engineExport.exportTo(a.listTracks(), a.playlistTree({ withTracks: true }), { libraryDir: engLib, cues: a.cuesByTrack(a.listTracks().map(t => t.id)) });
  assert.strictEqual(ex.cueTracks, 1, 'only the track with cues gets cue data');
  const e2 = new DatabaseSync(path.join(engLib, 'Database2', 'm.db'));
  const mixed = Number(e2.prepare("INSERT INTO Playlist (title, parentListId, isPersisted, nextListId, lastEditTime, isExplicitlyExported) VALUES ('Mixed', 0, 1, 0, 'x', 0)").run().lastInsertRowid);
  e2.prepare("INSERT INTO Playlist (title, parentListId, isPersisted, nextListId, lastEditTime, isExplicitlyExported) VALUES ('Child', ?, 1, 0, 'x', 0)").run(mixed);
  const tid = e2.prepare("SELECT id FROM Track WHERE title = 'Alpha'").get().id;
  e2.prepare("INSERT INTO PlaylistEntity (listId, trackId, databaseUuid, nextEntityId, membershipReference) VALUES (?, ?, 'u1', 0, 0)").run(mixed, tid);
  e2.close();

  const skip = engineImport.read({ dir: engLib, skipFolders: ['Sets'] });
  assert.ok(!skip.tree.some(n => n.name === 'Sets'), 'a top-level folder can be skipped (used for exports made by older versions)');
  assert.deepStrictEqual(skip.tree.find(n => n.name === 'Mixed').children.map(n => [n.name, n.type]), [['Mixed', 'playlist'], ['Child', 'playlist']], 'list with tracks + children becomes a folder');

  const src = engineImport.read({ dir: engLib });
  const b = new Library(path.join(work, 'b.db'));
  const r = await b.importExternal(src, { rootName: 'From Engine DJ' });
  assert.deepStrictEqual([r.added, r.missing, r.failed.length], [3, 0, 0]);
  const got = Object.fromEntries(b.listTracks().map(t => [t.title, t]));
  assert.strictEqual(keys.format(got.Alpha.key, 'camelot'), keys.format('F#m', 'camelot'), 'key round-trips through Engine');
  b.createPlaylist({ name: 'Made in Crate' }); // a playlist of your own survives re-imports
  const r2 = await b.importExternal(src, { rootName: 'From Engine DJ', replace: r.created, mode: 'overwrite' });
  assert.strictEqual(b.listTracks().find(t => t.title === 'Alpha').key, 'F#m', "overwrite doesn't churn a key that only differs in notation");
  assert.strictEqual(r2.updated, 0);
  assert.deepStrictEqual([got.Alpha.rating, got.Bravo.key, got.Bravo.rating, got.Charlie.key], [4, '8B', 2, '']);
  assert.strictEqual(got.Alpha.bpm, 174.5);
  assert.deepStrictEqual(b.getCues(got.Alpha.id).map(c => [c.kind, c.num, c.start, c.end, c.name, c.color]), [
    ['hot', 0, 1.25, null, 'In', '#cc0000'], ['hot', 7, 4.5, null, '', '#ce3232'], ['loop', 2, 2, 3, 'Roll', '#00aaff'], ['memory', null, 0.5, null, '', null]],
    'cue points survive Crate -> Engine -> Crate (unnamed pads get Engine default colours)');
  assert.deepStrictEqual(b.getCues(got.Bravo.id), [], 'no cues invented');
  const pdb = new DatabaseSync(path.join(engLib, 'Database2', 'm.db'), { readOnly: true });
  const pd = pdb.prepare("SELECT p.trackData, p.quickCues FROM PerformanceData p JOIN Track t ON t.id = p.trackId WHERE t.title = 'Bravo'").get(); pdb.close();
  assert.deepStrictEqual([pd.trackData, pd.quickCues], [null, null], "a track without cues keeps Engine's empty row");
  const topTree = b.playlistTree({ withTracks: true });
  assert.ok(!topTree.some(n => n.name === 'From Engine DJ'), 'no "From Engine DJ" folder');
  assert.deepStrictEqual(topTree.map(n => n.name), ['Made in Crate', 'Sets', 'Openers', 'Top 1', 'Mixed'], 're-import replaced its own playlists only (they come after yours)');
  const crate = { children: topTree.filter(n => n.name !== 'Made in Crate') };
  const rollers = crate.children.find(n => n.name === 'Sets').children.find(n => n.name === 'Rollers');
  assert.deepStrictEqual(b.getTracks(rollers.trackIds).map(t => t.title), ['Charlie', 'Alpha', 'Bravo'], 'playlist order kept');
  assert.deepStrictEqual(crate.children.map(n => [n.name, n.type]), [['Sets', 'folder'], ['Openers', 'playlist'], ['Top 1', 'playlist'], ['Mixed', 'folder']], 'top-level order kept; the limited smartlist went as a normal playlist');
  const fast = b.listPlaylists().find(p => p.name === 'Fast');
  assert.strictEqual(fast.type, 'smart', 'smartlist survives Crate -> Engine -> Crate');
  assert.deepStrictEqual(fast.rules.conditions, [{ field: 'bpm', op: 'gt', value: 170 }, { field: 'genre', op: 'is', value: 'D&B' }]);
  assert.deepStrictEqual(b.listTracks({ playlistId: fast.id }).map(t => t.title), ['Alpha'], 'and still evaluates live');
  a.close(); b.close();
});

test('engine: key index mapping', () => {
  assert.strictEqual(engineImport.keyFromEngine(0), '8B'); // C
  assert.strictEqual(engineImport.keyFromEngine(1), '8A'); // Am
  for (let k = 0; k < 24; k++) assert.strictEqual(keys.toEngine(engineImport.keyFromEngine(k)), k);
  assert.strictEqual(engineImport.keyFromEngine(null), '');
});

const conv = require('../src/core/smartconvert');
test('smart conversion: rekordbox XML -> Crate', () => {
  const x = (conds, op = 1) => `<NODE Id="-1" LogicalOperator="${op}" AutomaticUpdate="0">${conds.map(([p, o, l, r = '', u = '']) => `<CONDITION PropertyName="${p}" Operator="${o}" ValueUnit="${u}" ValueLeft="${l}" ValueRight="${r}"/>`).join('')}</NODE>`;
  assert.deepStrictEqual(conv.fromRekordbox(x([['artist', 1, 'Daft Punk'], ['bpm', 3, '12000']], 2)).rules,
    { match: 'any', conditions: [{ field: 'artist', op: 'is', value: 'Daft Punk' }, { field: 'bpm', op: 'gt', value: 120 }] });
  assert.deepStrictEqual(conv.fromRekordbox(x([['stockDate', 6, '2', '', 'month']])).rules.conditions, [{ field: 'dateAdded', op: 'in_last_days', value: 60 }]);
  assert.deepStrictEqual(conv.fromRekordbox(x([['key', 1, 'Am'], ['rating', 5, '3', '5'], ['remixedBy', 8, 'Nero'], ['name', 10, 'Intro']])).rules.conditions,
    [{ field: 'key', op: 'is', value: 'Am' }, { field: 'rating', op: 'between', value: 3, value2: 5 }, { field: 'remixer', op: 'contains', value: 'Nero' }, { field: 'title', op: 'starts_with', value: 'Intro' }]);
  assert.deepStrictEqual(conv.fromRekordbox(x([['stockDate', 5, '2024-01-01', '2024-01-31']])).rules.conditions,
    [{ field: 'dateAdded', op: 'after', value: '2024-01-01' }, { field: 'dateAdded', op: 'before', value: '2024-02-01' }]);
  assert.match(conv.fromRekordbox(x([['stockDate', 5, '2024-01-01', '2024-01-31']], 2)).error, /date/, 'a date range can’t be split under "any"');
  assert.match(conv.fromRekordbox(x([['counter', 3, '5']])).error, /play counts/);
  assert.match(conv.fromRekordbox(x([['key', 8, 'm']])).error, /is not/);
  assert.deepStrictEqual(conv.fromRekordbox(x([['genre', 1, 'R&amp;B &quot;Classics&quot;']])).rules.conditions[0].value, 'R&B "Classics"', 'XML entities decoded');
});
test('smart conversion: Engine <-> Crate', () => {
  // the exact format found in a real Engine DJ 3.0 library
  const real = `{"match":"all","rules":[{"col":"genre","con":"=","param":"'D&B - LIQUID'","v":"2.20.0"}],"rv":1}`;
  assert.deepStrictEqual(conv.fromEngine(real).rules, { match: 'all', conditions: [{ field: 'genre', op: 'is', value: 'D&B - LIQUID' }] });
  const crate = { match: 'any', conditions: [
    { field: 'genre', op: 'contains', value: "Rock 'n' Roll" }, { field: 'bpm', op: 'between', value: 170, value2: 176 }, { field: 'rating', op: 'gt', value: 3 },
    { field: 'key', op: 'compatible_with', value: '8A' }, { field: 'key', op: 'is', value: 'C' }, { field: 'dateAdded', op: 'after', value: '2025-06-01' },
    { field: 'title', op: 'ends_with', value: 'VIP' }, { field: 'format', op: 'is', value: 'mp4' }] };
  const e = conv.toEngine(crate); assert.ok(!e.error, e.error);
  const parsed = JSON.parse(e.json);
  assert.strictEqual(parsed.match, 'one');
  assert.deepStrictEqual(parsed.rules.find(r => r.col === 'key' && r.con === 'IN').param, '(1,0,23,3)', 'Am, C (relative major), Dm and Em as Engine key indexes');
  assert.strictEqual(parsed.rules.find(r => r.col === 'genre').param, "'%Rock ''n'' Roll%'", 'quotes escaped');
  assert.strictEqual(parsed.rules.find(r => r.col === 'IFNULL(rating, 0)').param, '60', 'rating x20');
  const back = conv.fromEngine(e.json).rules;
  assert.strictEqual(back.match, 'any');
  assert.deepStrictEqual(back.conditions.map(c => [c.field, c.op]), crate.conditions.map(c => [c.field, c.op]), 'round trip keeps every rule');
  assert.strictEqual(back.conditions[0].value, "Rock 'n' Roll");
  assert.strictEqual(back.conditions[3].value, '8A'); assert.strictEqual(back.conditions[4].value, '8B');
  assert.strictEqual(back.conditions[5].value, '2025-06-01');
  assert.match(conv.toEngine({ conditions: [{ field: 'dateAdded', op: 'in_last_days', value: 30 }] }).error, /no Engine equivalent/);
  assert.match(conv.toEngine({ conditions: [{ field: 'genre', op: 'is', value: 'x' }], limit: 20 }).error, /limit/);
  assert.match(conv.toEngine({ conditions: [{ field: 'remixer', op: 'is', value: 'x' }] }).error, /remixer/);
});
