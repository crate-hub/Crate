'use strict';
// UI test harness: serves the real renderer in Chromium (Playwright) and connects window.crate
// straight to the real API/core in this process. Only the Electron shell and native dialogs are stubbed.
// Usage: node test/ui-harness.js <outDir>
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
const { Library } = require('../src/core/library');
const { createApi } = require('../src/main/api');
const { readTags } = require('../src/core/tags');
const { build } = require('./make-demo-library');
const rbFixture = require('./rekordbox-fixture');

const OUT = path.resolve(process.argv[2] || 'ui-shots'); fs.mkdirSync(OUT, { recursive: true });
const work = fs.mkdtempSync(path.join(os.tmpdir(), 'crate-ui-'));
const music = build(path.join(work, 'Music'));
const lib = new Library(path.join(work, 'library.db'));
const engineLib = path.join(work, 'Engine Library');
const schema = path.join(__dirname, '..', '..', 'crate-testdata', 'engine_schema.sql');
if (fs.existsSync(schema)) {
  fs.mkdirSync(path.join(engineLib, 'Database2'), { recursive: true });
  const e = new DatabaseSync(path.join(engineLib, 'Database2', 'm.db')); e.exec(fs.readFileSync(schema, 'utf8'));
  e.prepare("INSERT INTO Information (uuid, schemaVersionMajor, schemaVersionMinor, schemaVersionPatch) VALUES ('demo', 3, 0, 1)").run(); e.close();
}

let page; const events = [];
const api = createApi(lib, {
  chooseImport: async () => [music], chooseSave: async (o) => path.join(work, 'out', path.basename(o.defaultPath || 'export.xml')),
  chooseFolder: async () => path.join(work, 'out'), chooseFile: async () => null,
  reveal: () => {}, trash: async (p) => fs.rmSync(p), isEngineRunning: async () => false, isRekordboxRunning: async () => false,
  send: (event, data) => { events.push(event); page && page.evaluate(([e, d]) => window.__crateEmit(e, d), [event, data]).catch(() => {}); },
});

const ROOT = path.join(__dirname, '..', 'src');
const server = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname.startsWith('/audio/')) { const p = api.audioPath(u.pathname.split('/')[2]); if (!p) { res.statusCode = 404; return res.end(); } res.setHeader('Content-Type', 'audio/mpeg'); return fs.createReadStream(p).pipe(res); }
  const f = path.join(ROOT, path.normalize(u.pathname).replace(/^(\.\.[\/\\])+/, ''));
  if (!f.startsWith(ROOT) || !fs.existsSync(f)) { res.statusCode = 404; return res.end(); }
  let body = fs.readFileSync(f);
  if (f.endsWith('index.html')) body = Buffer.from(body.toString().replace("media-src crate-audio:", "media-src 'self'"));
  res.setHeader('Content-Type', { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' }[path.extname(f)] || 'application/octet-stream');
  res.end(body);
});

const shot = (name) => page.screenshot({ path: path.join(OUT, name + '.png') });
const step = async (name, fn) => { process.stdout.write(`- ${name} … `); await fn(); console.log('ok'); };
function assert(c, m) { if (!c) throw new Error('Assertion failed: ' + m); }

(async () => {
  await new Promise(r => server.listen(0, r));
  const browser = await chromium.launch(); page = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  const errors = []; page.on('pageerror', e => errors.push(e.message)); page.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errors.push(m.text()); });
  await page.exposeBinding('__crateCall', async (_s, method, args) => {
    if (method === 'tracks.audioUrl') return `/audio/${args[0]}`;
    try { return { ok: await api.call(method, args) }; } catch (e) { return { err: e.message }; }
  });
  await page.addInitScript(() => {
    const listeners = []; const menu = [];
    window.__crateEmit = (e, d) => listeners.filter(l => l.e === e).forEach(l => l.cb(d));
    window.__crateMenu = (a) => menu.forEach(cb => cb(a));
    window.crate = {
      call: async (m, ...args) => { const r = await window.__crateCall(m, args); if (typeof r === 'string') return r; if (r.err) throw new Error(r.err); return r.ok; },
      on: (e, cb) => { const l = { e, cb }; listeners.push(l); return () => listeners.splice(listeners.indexOf(l), 1); },
      onMenu: (cb) => { menu.push(cb); return () => {}; }, pathForFile: () => null, platform: 'darwin',
    };
  });
  await page.goto(`http://localhost:${server.address().port}/renderer/index.html`);

  await step('empty library state', async () => { await page.waitForSelector('#empty:not([hidden])'); await shot('01-empty'); });
  await step('import a music folder', async () => {
    await page.click('#btn-import'); await page.click('.popmenu button:has-text("Folders or files")');
    await page.waitForFunction(() => document.querySelectorAll('#rows .tr').length >= 30);
    assert((await page.textContent('#view-meta')).startsWith('30 tracks'), 'meta shows 30 tracks');
  });
  await step('search narrows the list', async () => {
    await page.fill('#search', 'prydz'); await page.waitForFunction(() => document.querySelectorAll('#rows .tr').length === 3);
    await page.fill('#search', ''); await page.waitForFunction(() => document.querySelectorAll('#rows .tr').length === 30);
  });
  await step('sort by BPM and select a track', async () => {
    await page.click('.th:has(.th-label:text-is("BPM"))'); await page.click('.th:has(.th-label:text-is("BPM"))');
    await page.click('#rows .tr[data-i="3"] .td.title');
    await shot('02-library');
  });
  await step('edit tags in the inspector and save to the file', async () => {
    const title = await page.textContent('#rows .tr.sel .td.title');
    await page.fill('#f-comment', 'Peak-time weapon'); await page.click('#inspector button[type=submit]');
    await page.waitForSelector('.toast.ok');
    const t = lib.listTracks().find(x => x.title === title.trim());
    assert(readTags(t.path).fields.comment === 'Peak-time weapon', 'comment written into the file');
  });
  await step('multi-select and set rating with a key press', async () => {
    await page.click('#rows .tr[data-i="0"] .td.title'); await page.click('#rows .tr[data-i="2"] .td.title', { modifiers: ['Shift'] });
    await page.keyboard.press('2'); await page.waitForTimeout(300);
    assert(lib.listTracks({ sort: 'bpm', dir: 'asc' }).slice(0, 3).every(t => t.rating === 2), 'three tracks rated 2');
  });
  await step('create a playlist and drag tracks onto it', async () => {
    await page.click('#new-menu'); await page.click('.popmenu button:has-text("Playlist")'); await page.waitForSelector('#tree .node input'); await page.keyboard.type('Warm-up'); await page.keyboard.press('Enter');
    await page.waitForSelector('#tree .node:has-text("Warm-up")');
    await page.click('.lib-list .node'); await page.waitForFunction(() => document.querySelectorAll('#rows .tr').length === 30);
    await page.click('#rows .tr[data-i="5"] .td.title'); await page.click('#rows .tr[data-i="8"] .td.title', { modifiers: ['Shift'] });
    await page.dragAndDrop('#rows .tr[data-i="6"]', '#tree .node:has-text("Warm-up")');
    await page.waitForSelector('#tree .node:has-text("Warm-up") .count:text-is("4")');
    await page.click('#tree .node:has-text("Warm-up")'); await page.waitForFunction(() => document.querySelectorAll('#rows .tr').length === 4);
    await shot('03-playlist');
  });
  await step('build a smartlist with a harmonic key rule', async () => {
    await page.click('#new-menu'); await page.click('.popmenu button:has-text("Smartlist")');
    await page.fill('.modal .field input', 'Mixes with 8A');
    const row = page.locator('.modal .rule').first();
    await row.locator('select').first().selectOption('key'); await row.locator('select').nth(1).selectOption('compatible_with');
    await row.locator('input').fill('8A');
    await page.waitForFunction(() => /\d+ tracks? match/.test(document.querySelector('.modal footer .grow')?.textContent || ''));
    await shot('04-smartlist');
    await page.click('.modal footer .btn.primary');
    await page.waitForSelector('#tree .node.smart:has-text("Mixes with 8A")');
    const n = await page.$$eval('#rows .tr', r => r.length);
    assert(n === lib.listTracks({ rules: { conditions: [{ field: 'key', op: 'compatible_with', value: '8A' }] } }).length && n > 0, 'smartlist rows');
  });
  await step('fix titles & artists: preview then apply', async () => {
    await page.click('.lib-list .node');
    await page.click('[data-menu="cleanup"]'); await page.click('.popmenu button:has-text("Fix titles")');
    await page.check('.modal .checks input[value="titleCase"]');
    await page.click('.modal footer .btn.primary'); await page.waitForSelector('.modal .preview');
    await shot('05-fixes-preview');
    await page.click('.modal footer .btn.primary:has-text("Apply")'); await page.waitForSelector('.toast.ok:has-text("Updated")');
    const ts = lib.listTracks();
    assert(ts.some(t => t.title === 'Innerbloom'), 'number prefix removed and title-cased');
    assert(ts.some(t => t.title === 'Turn Off the Lights'), 'promo text removed');
    assert(ts.some(t => t.artist === 'Calvin Harris' && t.title === 'Feel So Close'), 'url prefix removed');
    assert(ts.some(t => t.remixer === 'Nero'), 'remixer extracted');
  });
  await step('find duplicates', async () => {
    await page.click('[data-menu="cleanup"]'); await page.click('.popmenu button:has-text("duplicates")');
    await page.click('.modal footer .btn.primary'); await page.waitForSelector('.dupe-group');
    await shot('06-duplicates');
    await page.click('.modal footer .btn.primary:has-text("Remove")'); await page.click('.modal.narrow footer .btn.primary');
    await page.waitForSelector('.toast.ok:has-text("Removed")');
    assert(lib.listTracks().filter(t => t.title === 'Strobe').length === 1, 'one Strobe left');
    assert(lib.listTracks().find(t => t.title === 'Strobe').format === 'flac', 'kept the FLAC');
  });
  await step('rename genres', async () => {
    await page.click('[data-menu="cleanup"]'); await page.click('.popmenu button:has-text("genres")');
    await page.waitForFunction(() => document.activeElement?.getAttribute('aria-label') === 'Filter genres'); // dialog has settled
    await page.fill('input[aria-label="New name for progressive house"]', 'Progressive House');
    await page.fill('input[aria-label="New name for trance"]', 'Trance');
    await shot('07-genres');
    await page.click('.modal footer .btn.primary'); await page.click('.modal.narrow footer .btn.primary');
    await page.waitForSelector('.toast.ok:has-text("Updated")');
    assert(lib.distinct('genre').filter(g => g.value.toLowerCase() === 'progressive house').length === 1, 'genres merged');
  });
  await step('switch key notation', async () => {
    await page.selectOption('#key-notation', 'musical');
    assert((await page.$$eval('.key', ks => ks.map(k => k.textContent))).includes('Am'), 'musical keys shown');
    await page.selectOption('#key-notation', 'camelot');
  });
  await step('export rekordbox XML', async () => {
    await page.click('[data-menu="export"]'); await page.click('.popmenu button:has-text("rekordbox XML")');
    await page.click('.modal footer .btn.primary'); await page.waitForSelector('.notice.good');
    await shot('08-rekordbox');
    const xml = fs.readFileSync(path.join(work, 'out', 'rekordbox.xml'), 'utf8');
    assert(/<NODE Name="Warm-up" Type="1" KeyType="0" Entries="4">/.test(xml), 'playlist in XML');
    await page.keyboard.press('Escape');
  });
  const RBDATA = path.join(__dirname, '..', '..', 'crate-testdata', 'rekordbox6');
  if (fs.existsSync(RBDATA)) await step('export to rekordbox library (native)', async () => {
    const { makeRekordbox } = require('./rekordbox-fixture');
    const rbDir = makeRekordbox(path.join(work, 'nowhere'));
    const db = path.join(rbDir, 'master.db'); require('../src/core/import/sqlcipher').encryptFile(db, db + '.e', require('../src/core/export/rekordboxdb').PASSPHRASE, path.join(RBDATA, 'master_locked.db')); fs.renameSync(db + '.e', db);
    await page.evaluate(async (p) => { await window.crate.call('settings.set', 'export.rekordboxDir', p); }, rbDir);
    await page.click('[data-menu="export"]'); await page.click('.popmenu button:has-text("rekordbox library")');
    await page.waitForSelector('.notice.good:has-text("Found your rekordbox library")');
    await shot('09-rekordbox-native');
    await page.click('.modal footer .btn.primary'); await page.waitForSelector('.toast:has-text("rekordbox updated")');
    await shot('09-rekordbox-native-after');
    const src = require('../src/core/import/rekordbox').read({ dir: rbDir });
    assert(!src.tree.some(n => n.name === 'Crate'), 'no wrapper folder in rekordbox');
    const warm = src.tree.find(n => n.name === 'Warm-up'); assert(warm && warm.sourceIds.length === 4, 'Warm-up with its 4 tracks');
    assert(fs.existsSync(path.join(rbDir, 'Crate backups')), 'backup folder made');
  });
  if (fs.existsSync(engineLib)) await step('export to Engine DJ', async () => {
    await page.click('[data-menu="export"]'); await page.click('.popmenu button:has-text("Engine")');
    await page.waitForSelector('.notice.bad:has-text("No Engine Library found")'); // nothing at ~/Music/Engine Library here
    assert(await page.isDisabled('.modal footer .btn.primary'), 'export disabled without a library');
    await shot('09-engine-missing');
    // point the dialog at the demo Engine Library
    await page.evaluate(async (p) => { await window.crate.call('settings.set', 'export.engineDir', p); }, engineLib);
    await page.keyboard.press('Escape');
    await page.click('[data-menu="export"]'); await page.click('.popmenu button:has-text("Engine")');
    await page.waitForSelector('.notice.good:has-text("Engine Library 3.0.1")');
    await page.click('.modal footer .btn.primary'); await page.waitForSelector('.toast.ok:has-text("Engine DJ updated")');
    await shot('09-engine-after');
    const e = new DatabaseSync(path.join(engineLib, 'Database2', 'm.db'), { readOnly: true });
    assert(e.prepare('SELECT COUNT(*) n FROM Track').get().n === 29, 'Engine has 29 tracks');
    assert(e.prepare("SELECT COUNT(*) n FROM Playlist WHERE title = 'Warm-up' AND parentListId = 0").get().n === 1, 'Engine playlist at the top level');
    assert(e.prepare("SELECT COUNT(*) n FROM Playlist WHERE title = 'Crate'").get().n === 0, 'no wrapper folder in Engine');
    assert(e.prepare("SELECT COUNT(*) n FROM Smartlist WHERE title = 'Mixes with 8A' AND parentPlaylistPath = ''").get().n === 1, 'Engine smartlist written natively at the top level');
    e.close(); await page.keyboard.press('Escape');
  });
  if (fs.existsSync(engineLib)) await step('import from Engine DJ (round trip)', async () => {
    await page.evaluate(async (p) => { await window.crate.call('settings.set', 'import.engineDir', p); }, engineLib);
    await page.click('#btn-import'); await page.click('.popmenu button:has-text("From Engine DJ")');
    await page.waitForSelector('.notice.good:has-text("Found 29 tracks")');
    await shot('11-import-engine');
    await page.click('.modal footer .btn.primary'); await page.waitForSelector('.toast.ok:has-text("Engine DJ:")');
    assert(/0 new tracks/.test(await page.textContent('.toast.ok:has-text("Engine DJ:")')), 'round trip adds no duplicates');
    assert(lib.countTracks() === 29, 'still 29 tracks');
    // Imports put playlists straight at the top level (no "From Engine DJ" folder), and a playlist
    // that came back from Engine replaces Crate's one of the same name instead of duplicating it.
    const top = lib.playlistTree().map(n => n.name);
    assert(!top.includes('From Engine DJ') && !top.includes('Crate'), 'no wrapper folders');
    assert(top.filter(n => n === 'Warm-up').length === 1, 'Warm-up once, not duplicated');
  });
  if (rbFixture.available()) await step('import from rekordbox (encrypted-format library, path fix)', async () => {
    const rbMusic = path.join(work, 'RB Music'); fs.mkdirSync(rbMusic);
    fs.copyFileSync(path.join(__dirname, 'fixtures', 't_v23.mp3'), path.join(rbMusic, 'Opus.mp3'));
    fs.copyFileSync(path.join(__dirname, 'fixtures', 't.flac'), path.join(rbMusic, 'OMT.flac'));
    const rbDir = rbFixture.makeRekordbox(rbMusic);
    fs.mkdirSync(path.join(work, 'Moved')); fs.copyFileSync(path.join(__dirname, 'fixtures', 't_v23.mp3'), path.join(work, 'Moved', 'Lost Track.mp3'));
    await page.evaluate(async (p) => { await window.crate.call('settings.set', 'import.rekordboxDir', p); }, rbDir);
    await page.click('#btn-import'); await page.click('.popmenu button:has-text("From rekordbox")');
    await page.waitForSelector('.notice.good:has-text("Found 3 tracks")');
    assert(await page.isVisible('input[aria-label="Path starts with"]'), 'path fix offered for missing files');
    assert((await page.inputValue('input[aria-label="Path starts with"]')) === 'C:/Users/dj/Music/Gone', 'path start suggested');
    await page.fill('input[aria-label="Replace with"]', path.join(work, 'Moved'));
    await shot('12-import-rekordbox');
    await page.click('.modal footer .btn.primary'); await page.waitForSelector('.toast.ok:has-text("rekordbox:")');
    assert(lib.listTracks().some(t => t.path === path.join(work, 'Moved', 'Lost Track.mp3') && !t.missing), 'moved file found via path fix');
    assert(!lib.playlistTree().some(n => n.name === 'From rekordbox'), 'no "From rekordbox" folder');

    await page.click('#tree .node:has-text("Gigs") .twist'); await page.waitForSelector('#tree .node:has-text("Peak")');
    await page.locator('#tree .node:has-text("Warm-up")').last().click(); await page.waitForFunction(() => document.querySelectorAll('#rows .tr').length === 3);
    await shot('13-imported-playlist');
  });
  await step('context menu on a track', async () => {
    await page.click('#rows .tr[data-i="1"] .td.title', { button: 'right' }); await page.waitForSelector('.popmenu');
    await shot('10-context-menu'); await page.keyboard.press('Escape');
  });
  await step('no console errors', async () => { assert(!errors.length, errors.join('\n')); });
  await browser.close(); server.close(); lib.close();
  console.log(`\nScreenshots in ${OUT}`);
})().catch(async (e) => { console.error('\nFAILED:', e.message); try { await shot('zz-failure'); } catch { /* ignore */ } process.exit(1); });
