'use strict';
// "Write tags to file": Crate's tags go into the music files.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { Library } = require('../src/core/library');
const { readTags } = require('../src/core/tags');

test('writes only artist, title, album, genre, year and comment into the files, skipping missing ones', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'crate-wt-'));
  for (const [n, s] of [['a.aiff', 't.aiff'], ['b.flac', 't.flac'], ['c.mp3', 't_v23.mp3'], ['gone.mp3', 't_v23.mp3']]) fs.copyFileSync(path.join(__dirname, 'fixtures', s), path.join(dir, n));
  const lib = new Library(path.join(dir, 'lib.db')); await lib.importPaths([dir]);
  const ids = lib.listTracks().map(t => t.id);
  // Changed in Crate only (as an import from a DJ app does when "save into files" is off)
  const before = Object.fromEntries(['a.aiff', 'b.flac', 'c.mp3'].map(f => [f, readTags(path.join(dir, f)).fields]));
  lib.updateTracks(ids, { artist: 'Crate Artist', title: 'Crate Title', album: 'Crate Album', genre: 'Drum & Bass', year: 1999, comment: 'from Crate',
    bpm: 174, key: '8A', rating: 4, label: 'Not Written', remixer: 'Not Written' }, { writeFiles: false });
  assert.notStrictEqual(readTags(path.join(dir, 'a.aiff')).fields.artist, 'Crate Artist');
  fs.rmSync(path.join(dir, 'gone.mp3')); lib.checkMissing();
  const progress = [];
  const r = await lib.writeTagsToFiles(ids, p => progress.push(p));
  assert.deepStrictEqual([r.written, r.skipped, r.errors.length], [3, 1, 0]);
  for (const f of ['a.aiff', 'b.flac', 'c.mp3']) {
    const t = readTags(path.join(dir, f)).fields;
    assert.deepStrictEqual([t.artist, t.title, t.album, t.genre, t.year, t.comment], ['Crate Artist', 'Crate Title', 'Crate Album', 'Drum & Bass', 1999, 'from Crate'], `${f}: the six fields are written`);
    for (const k of ['bpm', 'key', 'rating', 'label', 'remixer']) assert.strictEqual(t[k], before[f][k], `${f}: ${k} left as it was in the file`);
  }
  assert.deepStrictEqual(progress[progress.length - 1], { done: 4, total: 4 });
  // The library records the new file state, so a re-import sees the files as unchanged.
  const again = await lib.importPaths([dir]);
  assert.deepStrictEqual([again.unchanged, again.updated], [3, 0]);
  lib.close();
});
