'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { DatabaseSync } = require('node:sqlite');
const { Library } = require('../src/core/library');
const cleanup = require('../src/core/cleanup');
const keys = require('../src/core/keys');
const rekordbox = require('../src/core/export/rekordbox');
const m3u = require('../src/core/export/m3u');
const engine = require('../src/core/export/engine');
const { readTags } = require('../src/core/tags');

const FIX = path.join(__dirname, 'fixtures');
function makeMusic() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'crate-lib-'));
  const music = path.join(dir, 'Music', 'House'); fs.mkdirSync(music, { recursive: true });
  const specs = [
    ['01 - strobe.mp3', 't_v23.mp3', { title: '01 - strobe', artist: 'DEADMAU5', genre: 'progressive house', key: 'Am', bpm: 128, comment: 'www.promo-site.com' }],
    ['Strobe (copy).flac', 't.flac', { title: 'Strobe', artist: 'deadmau5', genre: 'Progressive House', key: '8A', bpm: 128 }],
    ['Ghosts.m4a', 't.m4a', { title: 'Ghosts n Stuff (Nero Remix)', artist: 'deadmau5', genre: 'Dubstep', key: 'Fm', bpm: 140 }],
    ['Opus.aiff', 't.aiff', { title: 'Opus', artist: 'Eric Prydz', genre: 'progressive house', key: '9A', bpm: 126, rating: 5 }],
    ['Tour.wav', 't.wav', { title: 'Daft Punk - Around the World', artist: '', genre: 'House', key: 'Gm', bpm: 121 }],
  ];
  const { writeTags } = require('../src/core/tags');
  for (const [name, src, tags] of specs) { const p = path.join(music, name); fs.copyFileSync(path.join(FIX, src), p); writeTags(p, tags); }
  return { dir, music };
}

test('keys: notation conversions', () => {
  assert.strictEqual(keys.format('Am', 'camelot'), '8A');
  assert.strictEqual(keys.format('8B', 'musical'), 'C');
  assert.strictEqual(keys.format('1d', 'camelot'), '8B');
  assert.strictEqual(keys.format('F#m', 'openkey'), '4m');
  assert.strictEqual(keys.format('Dbmaj', 'camelot'), '3B');
  assert.strictEqual(keys.format('Bbm', 'camelot'), '3A');
  assert.deepStrictEqual(keys.compatible('8A'), ['8A', '9A', '7A', '8B']);
  assert.deepStrictEqual(keys.compatible('12B'), ['12B', '1B', '11B', '12A']);
  assert.strictEqual(keys.toEngine('C'), 0); assert.strictEqual(keys.toEngine('Am'), 1); assert.strictEqual(keys.toEngine('G'), 2);
  assert.strictEqual(keys.format('weird', 'camelot'), 'weird');
});

test('library: import, search, playlists, smartlists, edits, clean-up, exports', async (t) => {
  const { dir, music } = makeMusic();
  const lib = new Library(path.join(dir, 'library.db'));
  const r1 = await lib.importPaths([path.join(dir, 'Music')]);
  assert.deepStrictEqual([r1.added, r1.failed.length], [5, 0], JSON.stringify(r1.failed));
  const r2 = await lib.importPaths([path.join(dir, 'Music')]);
  assert.strictEqual(r2.unchanged, 5, 're-import skips unchanged files');

  // search (accent/case-insensitive prefix)
  assert.strictEqual(lib.listTracks({ search: 'dead strob' }).length, 2);
  assert.strictEqual(lib.listTracks({ search: 'pryd' })[0].title, 'Opus');
  assert.deepStrictEqual(lib.listTracks({ sort: 'bpm', dir: 'desc' }).map(x => x.bpm), [140, 128, 128, 126, 121]);

  // playlists + folders
  const folder = lib.createPlaylist({ name: 'Gigs', type: 'folder' });
  const pl = lib.createPlaylist({ name: 'Warmup', parentId: folder });
  const all = lib.listTracks();
  const id = (title) => all.find(x => x.title.includes(title)).id;
  assert.strictEqual(lib.addToPlaylist(pl, [id('Opus'), id('Ghosts'), id('Opus')]), 2);
  lib.reorderPlaylist(pl, [id('Ghosts'), id('Opus')]);
  assert.deepStrictEqual(lib.listTracks({ playlistId: pl }).map(x => x.title), ['Ghosts n Stuff (Nero Remix)', 'Opus']);
  assert.strictEqual(lib.listTracks({ playlistId: folder }).length, 2, 'folder shows contents');
  assert.throws(() => lib.movePlaylist(folder, folder, 0));

  // smartlists
  const s1 = lib.createPlaylist({ name: 'Prog 125-130', type: 'smart', rules: { match: 'all', conditions: [
    { field: 'genre', op: 'contains', value: 'progressive' }, { field: 'bpm', op: 'between', value: 125, value2: 130 }] } });
  assert.strictEqual(lib.listTracks({ playlistId: s1 }).length, 3);
  const s2 = lib.createPlaylist({ name: 'Mixes with 8A', type: 'smart', rules: { conditions: [{ field: 'key', op: 'compatible_with', value: '8A' }] } });
  assert.deepStrictEqual(lib.listTracks({ playlistId: s2 }).map(x => x.key).sort(), ['8A', '9A', 'Am'], 'compatible keys across notations');
  const s3 = lib.createPlaylist({ name: 'Not in warmup', type: 'smart', rules: { conditions: [{ field: 'playlist', op: 'not_in', value: pl }] } });
  assert.strictEqual(lib.listTracks({ playlistId: s3 }).length, 3);
  assert.throws(() => lib.createPlaylist({ name: 'bad', type: 'smart', rules: { conditions: [{ field: 'nope', op: 'is', value: 1 }] } }));
  // injection attempt stays a value
  const s4 = lib.createPlaylist({ name: 'inj', type: 'smart', rules: { conditions: [{ field: 'title', op: 'contains', value: "'); DROP TABLE tracks; --" }] } });
  assert.strictEqual(lib.listTracks({ playlistId: s4 }).length, 0); assert.strictEqual(lib.countTracks(), 5);

  // edits write through to the file
  const opus = id('Opus');
  const up = lib.updateTracks([opus], { comment: 'Closer', rating: 4 });
  assert.strictEqual(up.fileErrors.length, 0);
  assert.strictEqual(readTags(lib.getTracks([opus])[0].path).fields.comment, 'Closer');
  assert.strictEqual(lib.getTracks([opus])[0].rating, 4);
  assert.strictEqual((await lib.importPaths([music])).unchanged, 5, 'own edits do not look like external changes');

  // clean-up
  const dupes = cleanup.findDuplicates(lib.listTracks());
  assert.strictEqual(dupes.length, 0, 'titles differ before clean-up');
  const fixes = cleanup.previewFixes(lib.listTracks(), ['numberPrefix', 'titleCase', 'urls', 'extractRemixer', 'splitArtistTitle']);
  const byId = Object.fromEntries(fixes.map(f => [f.id, f.changes]));
  assert.deepStrictEqual(byId[id('strobe')], { title: 'Strobe', comment: '' }, 'stylised names like DEADMAU5 / mau5trap left alone');
  assert.strictEqual(cleanup.titleCase('the house of god'), 'The House of God');
  assert.strictEqual(cleanup.titleCase('LOVE STORY (DJ SNAKE REMIX)'), 'Love Story (DJ Snake Remix)');
  const tc = cleanup.previewFixes([{ id: 1, title: 'LOSING IT', artist: 'FISHER', label: 'LEVELS' }, { id: 2, title: 'STROBE', artist: 'x' }], ['titleCase']);
  assert.deepStrictEqual(tc.map(e => e.changes), [{ title: 'Losing It' }], 'artists/labels and single all-caps words untouched');
  const rx = cleanup.previewFixes([{ id: 1, title: 'Midnight City (Eric Prydz Private Remix)', remixer: '' }, { id: 2, title: 'Song (Extended Mix)', remixer: '' }, { id: 3, title: 'X (Club Remix)', remixer: '' }], ['extractRemixer']);
  assert.deepStrictEqual(rx.map(e => e.changes), [{ remixer: 'Eric Prydz' }]);
  assert.deepStrictEqual(byId[id('Ghosts')], { remixer: 'Nero' });
  assert.deepStrictEqual(byId[id('Around')], { artist: 'Daft Punk', title: 'Around the World' });
  lib.applyEdits(fixes);
  const d2 = cleanup.findDuplicates(lib.listTracks());
  assert.strictEqual(d2.length, 1); assert.strictEqual(d2[0].tracks.length, 2);
  assert.strictEqual(lib.getTracks([d2[0].keep])[0].format, 'flac', 'lossless copy suggested as keeper');
  const gr = cleanup.previewGenreRename(lib.listTracks(), { 'progressive house': 'Progressive House' });
  assert.strictEqual(gr.length, 2); lib.applyEdits(gr);
  assert.deepStrictEqual(lib.distinct('genre').map(g => [g.value, g.count]), [['Dubstep', 1], ['House', 1], ['Progressive House', 3]]);

  // rekordbox XML
  const tree = lib.playlistTree({ withTracks: true });
  const xmlFile = path.join(dir, 'out', 'rekordbox.xml');
  rekordbox.write(xmlFile, lib.listTracks(), tree);
  const xml = fs.readFileSync(xmlFile, 'utf8');
  assert.match(xml, /<COLLECTION Entries="5">/);
  assert.match(xml, /Location="file:\/\/localhost\/.*\/Music\/House\/Ghosts.m4a"/);
  assert.match(xml, /<NODE Type="0" Name="Gigs" Count="1">/);
  assert.match(xml, /<NODE Name="Warmup" Type="1" KeyType="0" Entries="2">/);
  assert.match(xml, /Tonality="Am"/);
  assert.match(xml, /Rating="204"/);
  if (process.platform !== 'win32') { try { execFileSync('xmllint', ['--noout', xmlFile]); } catch (e) { if (e.code !== 'ENOENT') throw e; } }
  assert.strictEqual(rekordbox.location('/Users/dj/My Music/Ünïcode & co.mp3'), 'file://localhost/Users/dj/My%20Music/%C3%9Cn%C3%AFcode%20%26%20co.mp3');

  // M3U
  const files = m3u.write(path.join(dir, 'out', 'm3u'), tree, ids => lib.getTracks(ids));
  assert.ok(files.some(f => f.endsWith(path.join('Gigs', 'Warmup.m3u8'))));
  assert.match(fs.readFileSync(files.find(f => f.endsWith('Warmup.m3u8')), 'utf8'), /^#EXTM3U\n#EXTINF:6,deadmau5 - Ghosts/);

  // Engine DJ
  const schemaFile = process.env.ENGINE_SCHEMA || path.join(__dirname, '..', '..', 'crate-testdata', 'engine_schema.sql');
  if (!fs.existsSync(schemaFile)) { t.diagnostic('Engine schema not available, skipping Engine test'); lib.close(); return; }
  const engLib = path.join(dir, 'Engine Library'); fs.mkdirSync(path.join(engLib, 'Database2'), { recursive: true });
  const edb = new DatabaseSync(path.join(engLib, 'Database2', 'm.db'));
  edb.exec(fs.readFileSync(schemaFile, 'utf8'));
  edb.prepare("INSERT INTO Information (uuid, schemaVersionMajor, schemaVersionMinor, schemaVersionPatch, currentPlayedIndiciator, lastRekordBoxLibraryImportReadCounter) VALUES ('abc-uuid', 3, 0, 1, 0, 0)").run();
  edb.prepare("INSERT INTO AlbumArt (hash, albumArt) VALUES (NULL, NULL)").run();
  edb.prepare("INSERT INTO Playlist (title, parentListId, isPersisted, nextListId, lastEditTime, isExplicitlyExported) VALUES ('My own list', 0, 1, 0, '2024-01-01 00:00:00', 0)").run();
  edb.close();
  const e1 = engine.exportTo(lib.listTracks(), tree, { libraryDir: engLib });
  assert.deepStrictEqual([e1.added, e1.updated, e1.skipped], [5, 0, 0]);
  assert.ok(fs.existsSync(e1.backup));
  lib.updateTracks([opus], { title: 'Opus (Edit)' }, { writeFiles: false });
  const e2 = engine.exportTo(lib.listTracks(), lib.playlistTree({ withTracks: true }), { libraryDir: engLib });
  assert.deepStrictEqual([e2.added, e2.updated], [0, 5], 'second export updates in place');
  const chk = new DatabaseSync(path.join(engLib, 'Database2', 'm.db'), { readOnly: true });
  // Sibling order is a linked list: nextListId = next sibling's id, 0 = last.
  const siblings = (parentId) => {
    const rows = chk.prepare('SELECT id, title, nextListId FROM Playlist WHERE parentListId = ?').all(parentId);
    const pointed = new Set(rows.map(r => r.nextListId)); let cur = rows.find(r => !pointed.has(r.id)); const out = [];
    while (cur) { out.push(cur.title); cur = rows.find(r => r.id === cur.nextListId); }
    assert.strictEqual(out.length, rows.length, `chain under ${parentId} is complete`); return out;
  };
  assert.deepStrictEqual(siblings(0), ['Gigs', 'Not in warmup'], "Engine's playlists replaced by Crate's at the top level (its own list removed), not duplicated; the playlist-membership rule has no Engine equivalent, so that one is a normal playlist");
  assert.strictEqual(e2.removed, e1.playlists + e1.smartlists, 'the second export removed exactly what the first wrote');
  // the other smartlists are real Engine smartlists, chained by nextListUuid (empty = last)
  const smarts = chk.prepare("SELECT listUuid AS id, title, nextListUuid AS next, rules FROM Smartlist WHERE parentPlaylistPath = ''").all();
  const smartOrder = []; for (let cur = smarts.find(x => !smarts.some(y => y.next === x.id)); cur; cur = smarts.find(x => x.id === cur.next)) smartOrder.push(cur.title);
  assert.deepStrictEqual(smartOrder, ['Prog 125-130', 'Mixes with 8A', 'inj']);
  assert.deepStrictEqual(JSON.parse(smarts.find(x => x.title === 'Prog 125-130').rules).rules.map(r => [r.col, r.con, r.param]),
    [['genre', 'LIKE', "'%progressive%'"], ['ROUND(bpmAnalyzed)', 'BETWEEN', '125 AND 130']]);
  const paths = chk.prepare('SELECT path FROM PlaylistPath').all().map(r => r.path);
  // (the view's segment order depends on SQLite's GROUP_CONCAT behaviour, so compare as a set)
  assert.ok(paths.some(p => p.split(';').filter(Boolean).sort().join() === 'Gigs,Warmup'), "Engine's own path view resolves the nested playlist");
  // Walk the Warmup linked list
  const warm = chk.prepare("SELECT id FROM Playlist WHERE title = 'Warmup'").get().id;
  const ents = chk.prepare('SELECT e.id, e.nextEntityId, t.title FROM PlaylistEntity e JOIN Track t ON t.id = e.trackId WHERE listId = ?').all(warm);
  const nextIds = new Set(ents.map(e => e.nextEntityId));
  let cur = ents.find(e => !nextIds.has(e.id)); const order = [];
  while (cur) { order.push(cur.title); cur = ents.find(e => e.id === cur.nextEntityId); }
  assert.deepStrictEqual(order, ['Ghosts n Stuff (Nero Remix)', 'Opus (Edit)']);
  const row = chk.prepare("SELECT path, key, rating, bpm, length, originDatabaseUuid FROM Track WHERE title = 'Opus (Edit)'").get();
  assert.strictEqual(row.path, '../Music/House/Opus.aiff');
  assert.strictEqual(row.key, keys.toEngine('9A')); assert.strictEqual(row.rating, 80); assert.strictEqual(row.bpm, 126); assert.strictEqual(row.length, 6);
  assert.strictEqual(row.originDatabaseUuid, 'abc-uuid', 'Engine trigger filled origin');
  assert.strictEqual(chk.prepare('SELECT COUNT(*) n FROM PerformanceData').get().n, 5, 'Engine trigger created PerformanceData rows');
  assert.strictEqual(chk.prepare('PRAGMA integrity_check').get().integrity_check, 'ok');
  chk.close();
  lib.close();
});
