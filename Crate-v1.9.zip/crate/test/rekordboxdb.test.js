'use strict';
// Native rekordbox export: master.db (SQLCipher) + masterPlaylists6.xml, read back with Crate's
// own importer. Uses the real rekordbox 6 schema from the pyrekordbox test data (not shipped).
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { Library } = require('../src/core/library');
const { writeTags } = require('../src/core/tags');
const { encryptFile, decryptFile, isPlainSqlite } = require('../src/core/import/sqlcipher');
const rbImport = require('../src/core/import/rekordbox');
const rbExport = require('../src/core/export/rekordboxdb');
const { makeRekordbox } = require('./rekordbox-fixture');

const FIX = path.join(__dirname, 'fixtures');
const DATA = process.env.CRATE_TESTDATA || path.join(__dirname, '..', '..', 'crate-testdata');
const RB = path.join(DATA, 'rekordbox6');
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'crate-rbdb-'));
const K = rbExport.PASSPHRASE;
const skip = !fs.existsSync(RB);

function setup() {
  const work = tmp(); const music = path.join(work, 'Music'); fs.mkdirSync(music);
  // Opus.mp3 (CBR) and OMT.flac exist in rekordbox already (fixture); New.aiff and Vbr.mp3 are new to rekordbox.
  fs.copyFileSync(path.join(FIX, 't_notag_cbr.mp3'), path.join(music, 'Opus.mp3'));
  fs.copyFileSync(path.join(FIX, 't.flac'), path.join(music, 'OMT.flac'));
  fs.copyFileSync(path.join(FIX, 't.aiff'), path.join(music, 'New.aiff'));
  fs.copyFileSync(path.join(FIX, 't_v24_vbr.mp3'), path.join(music, 'Vbr.mp3'));
  writeTags(path.join(music, 'Opus.mp3'), { title: 'Opus', artist: 'Eric Prydz', genre: 'Progressive House', bpm: 126, key: '8A', rating: 5 });
  writeTags(path.join(music, 'OMT.flac'), { title: 'One More Time', artist: 'Daft Punk', genre: 'French House', bpm: 123 });
  writeTags(path.join(music, 'New.aiff'), { title: 'Brand New', artist: 'Newcomer', genre: 'Techno', bpm: 132.5, key: 'F#m', label: 'Fresh Label', year: 2024, rating: 3 });
  writeTags(path.join(music, 'Vbr.mp3'), { title: 'Variable', artist: 'VBR Artist', bpm: 140 });
  const rbDir = makeRekordbox(music);
  // Make it a real encrypted library, keyed like rekordbox's (salt taken from a real encrypted master.db).
  const plain = path.join(rbDir, 'master.db'); encryptFile(plain, plain + '.enc', K, path.join(RB, 'master_locked.db')); fs.renameSync(plain + '.enc', plain);
  return { work, music, rbDir };
}

test('native rekordbox export: tracks, playlists, smartlists, cues, read back', { skip }, async () => {
  const { work, music, rbDir } = setup();
  assert.ok(!isPlainSqlite(path.join(rbDir, 'master.db')));
  const lib = new Library(path.join(work, 'lib.db')); await lib.importPaths([music]);
  const T = Object.fromEntries(lib.listTracks().map(t => [t.title, t]));
  const sets = lib.createPlaylist({ name: 'Sets', type: 'folder' });
  const warm = lib.createPlaylist({ name: 'Warm-up', parentId: sets }); lib.addToPlaylist(warm, [T['Brand New'].id, T.Opus.id, T.Variable.id]);
  lib.createPlaylist({ name: 'Fast prog', type: 'smart', parentId: sets, rules: { match: 'all', conditions: [{ field: 'genre', op: 'contains', value: 'Prog' }, { field: 'bpm', op: 'between', value: 125, value2: 130 }] } });
  lib.createPlaylist({ name: 'Mixes with 8A', type: 'smart', rules: { conditions: [{ field: 'key', op: 'compatible_with', value: '8A' }] } });
  const peak = lib.createPlaylist({ name: 'Peak' }); lib.addToPlaylist(peak, [T['One More Time'].id]);
  lib.setCues(T['Brand New'].id, [{ kind: 'hot', num: 0, start: 1.5, name: 'Intro', color: '#28e214' }, { kind: 'hot', num: 4, start: 3.25, color: '#e62828' },
    { kind: 'hot', num: 2, start: 2, end: 4, name: 'Roll' }, { kind: 'memory', start: 0.25, color: '#ffa000' }, { kind: 'loop', num: 0, start: 4.5, end: 5.5, name: 'Bank' }], 'engine');
  lib.setCues(T['One More Time'].id, [{ kind: 'hot', num: 0, start: 1 }], 'engine'); // FLAC: skipped
  lib.setCues(T.Variable.id, [{ kind: 'hot', num: 0, start: 1 }], 'engine'); // VBR MP3: skipped
  lib.setCues(T.Opus.id, [{ kind: 'memory', start: 2 }], 'engine'); // CBR MP3: written

  const before = (() => { const p = path.join(work, 'before.db'); decryptFile(path.join(rbDir, 'master.db'), p, K); const d = new DatabaseSync(p, { readOnly: true });
    try { return { usn: d.prepare("SELECT int_1 FROM agentRegistry WHERE registry_id = 'localUpdateCount'").get().int_1, content: d.prepare('SELECT COUNT(*) n FROM djmdContent').get().n }; } finally { d.close(); } })();

  const exp = () => rbExport.exportTo(lib.listTracks(), lib.playlistTree({ withTracks: true }), { dir: rbDir, cues: lib.cuesByTrack(lib.listTracks().map(t => t.id)), previousPaths: lib.previousPaths(lib.listTracks().map(t => t.id)) });
  const r = exp();
  assert.deepStrictEqual([r.added, r.updated + r.unchanged, r.playlists, r.smartlists, r.cueTracks], [2, 2, 3, 1, 2]);
  assert.deepStrictEqual(r.smartAsPlaylists.map(x => x.name), ['Mixes with 8A'], 'a key-compatibility smartlist becomes a normal playlist');
  assert.deepStrictEqual(r.cueSkipped.map(x => x.reason).sort(), ['FLAC', 'VBR MP3']);
  assert.ok(fs.existsSync(path.join(r.backup, 'master.db')) && fs.existsSync(path.join(r.backup, 'masterPlaylists6.xml')), 'backup made');
  assert.ok(!isPlainSqlite(path.join(rbDir, 'master.db')), 'still encrypted');

  // Read back with Crate's rekordbox importer (decrypts with the same key).
  const src = rbImport.read({ dir: rbDir });
  assert.deepStrictEqual(src.tree.map(n => [n.name, n.type]), [['Sets', 'folder'], ['Mixes with 8A', 'playlist'], ['Peak', 'playlist']],
    "rekordbox's playlists replaced by Crate's, at the top level, no wrapper folder");
  assert.strictEqual(r.removed, 7, "all 7 of rekordbox's own playlists, folders and smart playlists removed (an already-deleted one isn't counted)");
  const setsNode = src.tree[0];
  assert.deepStrictEqual(setsNode.children.map(n => [n.name, n.type]), [['Warm-up', 'playlist'], ['Fast prog', 'smart']]);
  assert.deepStrictEqual(setsNode.children[1].rules, { match: 'all', conditions: [{ field: 'genre', op: 'contains', value: 'Prog' }, { field: 'bpm', op: 'between', value: 125, value2: 130 }] }, 'smartlist rules survive');
  const byId = new Map(src.tracks.map(t => [t.sourceId, t]));
  assert.deepStrictEqual(setsNode.children[0].sourceIds.map(id => byId.get(id).fields.title), ['Brand New', 'Opus', 'Variable'], 'playlist order kept');
  const nw = src.tracks.find(t => t.path === path.join(music, 'New.aiff'));
  assert.deepStrictEqual([nw.fields.title, nw.fields.artist, nw.fields.genre, nw.fields.bpm, nw.fields.label, nw.fields.year, nw.fields.rating], ['Brand New', 'Newcomer', 'Techno', 132.5, 'Fresh Label', 2024, 3]);
  assert.strictEqual(require('../src/core/keys').format(nw.fields.key, 'camelot'), '11A', 'key stored as a rekordbox key');
  assert.deepStrictEqual(nw.cues.map(c => [c.kind, c.num, c.start, c.end, c.name, c.color]), [
    ['hot', 0, 1.5, null, 'Intro', '#28e214'], ['hot', 2, 2, 4, 'Roll', null], ['hot', 4, 3.25, null, '', '#e62828'],
    ['memory', null, 0.25, null, '', '#ffa000'], ['memory', null, 4.5, 5.5, 'Bank', null]], 'cues: hot (E = Kind 6), hot loop, memory cue, saved loop as memory loop');
  assert.deepStrictEqual(src.tracks.find(t => t.path.endsWith('Opus.mp3')).cues.map(c => [c.kind, c.start]), [['memory', 2]]);
  assert.deepStrictEqual(src.tracks.find(t => t.path.endsWith('OMT.flac')).cues, [], 'no cues written for FLAC');

  // Low-level checks: USNs, contentCue, XML
  const p2 = path.join(work, 'after.db'); decryptFile(path.join(rbDir, 'master.db'), p2, K); const d = new DatabaseSync(p2, { readOnly: true });
  const usn = d.prepare("SELECT int_1 FROM agentRegistry WHERE registry_id = 'localUpdateCount'").get().int_1;
  assert.ok(usn > before.usn, 'update counter advanced');
  for (const t of ['djmdContent', 'djmdPlaylist', 'djmdSongPlaylist', 'djmdArtist', 'contentCue']) assert.ok(d.prepare(`SELECT MAX(rb_local_usn) m FROM ${t}`).get().m <= usn, `${t} USNs never pass the counter`);
  assert.strictEqual(d.prepare('SELECT COUNT(*) n FROM djmdContent').get().n, before.content + 2);
  const newRow = d.prepare('SELECT * FROM djmdContent WHERE FolderPath = ?').get(path.join(music, 'New.aiff'));
  assert.deepStrictEqual([newRow.FileType, newRow.FileNameL, newRow.MasterSongID === newRow.ID, newRow.HotCueAutoLoad, /^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d{3} \+00:00$/.test(newRow.created_at)], [12, 'New.aiff', true, 'on', true]);
  const cc = d.prepare('SELECT Cues, rb_cue_count, ID FROM contentCue WHERE ContentID = ?').get(newRow.ID);
  const entries = JSON.parse(cc.Cues);
  assert.strictEqual(cc.rb_cue_count, 5); assert.strictEqual(cc.ID, newRow.UUID, 'contentCue ID is the track UUID');
  assert.deepStrictEqual(entries.map(e => e.Kind), [1, 3, 6, 0, 0]);
  assert.deepStrictEqual(Object.keys(entries[0]), ['ID', 'ContentID', 'ContentUUID', 'InMsec', 'InFrame', 'InMpegFrame', 'InMpegAbs', 'OutMsec', 'OutFrame', 'OutMpegFrame', 'OutMpegAbs', 'Kind', 'Color', 'ColorTableIndex', 'Comment', 'UUID', 'created_at', 'updated_at']);
  assert.strictEqual(newRow.CueUpdated, '5');
  const ids = d.prepare("SELECT ID FROM djmdPlaylist WHERE IFNULL(rb_local_deleted, 0) = 0 AND ID NOT IN ('100000', '200000') AND Attribute >= 0").all().map(x => x.ID);
  assert.ok(d.prepare("SELECT 1 FROM djmdPlaylist WHERE ID = '100000'").get(), "rekordbox's system list (Cloud Library Sync) kept");
  assert.deepStrictEqual(d.prepare("SELECT Name, Seq FROM djmdPlaylist WHERE ParentID = 'root' AND Attribute >= 0 AND IFNULL(rb_local_deleted, 0) = 0 ORDER BY Seq").all().map(x => x.Name), ['Sets', 'Mixes with 8A', 'Peak']);
  d.close();
  const xml = fs.readFileSync(path.join(rbDir, 'masterPlaylists6.xml'), 'utf8');
  for (const id of ids) assert.ok(xml.includes(`<NODE Id="${BigInt(id).toString(16).toUpperCase()}"`), 'every exported playlist is listed in masterPlaylists6.xml');
  assert.strictEqual(ids.length, 5, 'Sets, Warm-up, Fast prog, Mixes with 8A, Peak');

  // A second export replaces the playlists again; a renamed file moves instead of being added again.
  const newT = lib.listTracks().find(t => t.title === 'Brand New');
  lib.updateTracks([newT.id], { artist: 'Renamed Artist' }); lib.renameFiles([newT.id]);
  const r2 = exp();
  assert.deepStrictEqual([r2.added, r2.moved, r2.removed], [0, 1, 5]);
  const src2 = rbImport.read({ dir: rbDir });
  assert.deepStrictEqual(src2.tree.map(n => n.name), ['Sets', 'Mixes with 8A', 'Peak'], 'replaced, not duplicated');
  assert.strictEqual(src2.tracks.length, src.tracks.length, 'no duplicate track for the renamed file');
  const moved = src2.tracks.find(t => t.fields.artist === 'Renamed Artist');
  assert.strictEqual(path.basename(moved.path), 'Renamed Artist - Brand New.aiff'); assert.strictEqual(moved.cues.length, 5, 'cues stay with it');
  const xml2 = fs.readFileSync(path.join(rbDir, 'masterPlaylists6.xml'), 'utf8');
  for (const id of ids) assert.ok(!xml2.includes(`<NODE Id="${BigInt(id).toString(16).toUpperCase()}"`), 'old playlist nodes removed');
  assert.ok(!xml2.includes('<NODE Id="7D1"'), "rekordbox's own playlists are gone from the XML too");
  assert.ok(xml2.includes('<NODE Id="186A0"'), 'its system list stays in the XML');
  // Crate's importer can leave a top-level folder out (used for exports made by older versions).
  assert.ok(!rbImport.read({ dir: rbDir, skipFolders: ['Sets'] }).tree.some(n => n.name === 'Sets'));
  lib.close();
});

test('native rekordbox export refuses when rekordbox has unsaved changes, and leaves files alone on failure', { skip }, async () => {
  const { work, music, rbDir } = setup();
  const lib = new Library(path.join(work, 'lib.db')); await lib.importPaths([music]);
  const db = path.join(rbDir, 'master.db'); const orig = fs.readFileSync(db); const origXml = fs.readFileSync(path.join(rbDir, 'masterPlaylists6.xml'));
  fs.writeFileSync(db + '-wal', 'pending');
  assert.match(rbExport.inspect(rbDir).reason, /rekordbox is open/);
  assert.throws(() => rbExport.exportTo(lib.listTracks(), [], { dir: rbDir }), /rekordbox is open/);
  fs.rmSync(db + '-wal');
  // A broken tree (bad playlist data) makes the export fail inside the transaction: nothing changes.
  assert.throws(() => rbExport.exportTo(lib.listTracks(), [{ name: 'X', type: 'playlist', get trackIds() { throw new Error('boom'); } }], { dir: rbDir }), /boom/);
  assert.ok(fs.readFileSync(db).equals(orig), 'master.db untouched');
  assert.ok(fs.readFileSync(path.join(rbDir, 'masterPlaylists6.xml')).equals(origXml), 'masterPlaylists6.xml untouched');
  fs.rmSync(path.join(rbDir, 'masterPlaylists6.xml'));
  assert.match(rbExport.inspect(rbDir).reason, /masterPlaylists6\.xml is missing/);
  lib.close();
});
