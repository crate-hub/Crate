'use strict';
// Builds a demo music folder (copies of the short fixtures, tagged like a real DJ library) for UI testing.
const fs = require('fs');
const path = require('path');
const { writeTags } = require('../src/core/tags');

const FIX = path.join(__dirname, 'fixtures');
const SRC = { mp3: 't_v23.mp3', flac: 't.flac', m4a: 't.m4a', aiff: 't.aiff', wav: 't.wav' };
const T = [
  ['Strobe', 'deadmau5', '', 'Progressive House', 128, '8A', 5, 2009, 'mau5trap', 'mp3'],
  ['Strobe', 'deadmau5', '', 'Progressive House', 128, 'Am', 0, 2009, 'mau5trap', 'flac'],
  ['Opus', 'Eric Prydz', '', 'Progressive House', 126, '9A', 5, 2015, 'Virgin', 'aiff'],
  ['Pjanoo', 'Eric Prydz', '', 'House', 126, '10B', 4, 2008, 'Data', 'mp3'],
  ['Ghosts n Stuff (Nero Remix)', 'deadmau5 feat. Rob Swire', '', 'Dubstep', 140, 'Fm', 4, 2009, 'mau5trap', 'm4a'],
  ['01 - innerbloom', 'RÜFÜS DU SOL', '', 'melodic house', 120, '11A', 0, 2015, 'Sweat It Out', 'mp3'],
  ['Cola', 'CamelPhat & Elderbrook', '', 'Tech House', 122, '4A', 4, 2017, 'Defected', 'mp3'],
  ['Losing It', 'FISHER', '', 'Tech House', 125, '7A', 5, 2018, 'Catch & Release', 'flac'],
  ['Turn Off the Lights [FREE DOWNLOAD]', 'Chris Lake', '', 'Tech House', 126, '6A', 3, 2019, 'Black Book', 'mp3'],
  ['Atmosphere', 'Kaskade', '', 'Progressive House', 128, '2B', 3, 2013, 'Ultra', 'm4a'],
  ['Around the World', 'Daft Punk', '', 'House', 121, 'Gm', 5, 1997, 'Virgin', 'wav'],
  ['One More Time', 'Daft Punk', '', 'House', 123, '12B', 5, 2000, 'Virgin', 'mp3'],
  ['Sandstorm', 'Darude', '', 'trance', 136, '11A', 3, 1999, 'Neo', 'mp3'],
  ['Adagio for Strings', 'Tiësto', '', 'Trance', 138, '10A', 4, 2005, 'Black Hole', 'flac'],
  ['Children', 'Robert Miles', '', 'Dream House', 137, '4A', 4, 1995, 'DBX', 'mp3'],
  ['Levels (Avicii Remix)', 'Avicii', '', 'progressive house', 126, 'C#m', 4, 2011, 'LEVELS', 'mp3'],
  ['Strings of Life', 'Rhythim Is Rhythim', '', 'Detroit Techno', 125, 'F', 5, 1987, 'Transmat', 'aiff'],
  ['Spastik', 'Plastikman', '', 'Techno', 131, '', 3, 1993, 'NovaMute', 'mp3'],
  ['Windowlicker', 'Aphex Twin', '', 'IDM', 126, '5A', 4, 1999, 'Warp', 'flac'],
  ['Xtal', 'Aphex Twin', '', 'ambient techno', 118, '9B', 4, 1992, 'Apollo', 'mp3'],
  ['Show Me Love (Original Mix)', 'Robin S', '', 'House', 120, '3A', 4, 1990, 'Champion', 'mp3'],
  ['Finally', 'Kings of Tomorrow', '', 'House', 125, '1A', 4, 2000, 'Defected', 'm4a'],
  ['Midnight City (Eric Prydz Private Remix)', 'M83', '', 'Progressive House', 125, '7B', 5, 2011, 'Mute', 'mp3'],
  ['Kernkraft 400', 'Zombie Nation', '', 'Techno', 142, '6A', 2, 1999, 'Dataviolence', 'mp3'],
  ['Blue Monday', 'New Order', '', 'Synth-pop', 130, '9A', 4, 1983, 'Factory', 'flac'],
  ['Rej', 'Âme', '', 'Deep House', 122, '8A', 5, 2005, 'Sonar Kollektiv', 'mp3'],
  ['Sun Is Shining', 'Axwell Λ Ingrosso', '', 'Progressive House', 124, '8B', 3, 2015, 'Axtone', 'm4a'],
  ['Unfinished Sympathy', 'Massive Attack', '', 'trip hop', 81, '10A', 5, 1991, 'Wild Bunch', 'wav'],
  ['Born Slippy .NUXX', 'Underworld', '', 'Techno', 136, 'Fm', 5, 1996, 'Junior Boy\'s Own', 'mp3'],
  ['www.edm-promo.net - Feel So Close', 'Calvin Harris', '', 'Electro House', 128, '7A', 3, 2011, 'Columbia', 'mp3'],
];

function build(dir) {
  fs.mkdirSync(dir, { recursive: true });
  T.forEach(([title, artist, remixer, genre, bpm, key, rating, year, label, fmt], i) => {
    const name = `${String(i + 1).padStart(2, '0')} ${artist.replace(/[\/:]/g, ' ')} - ${title.replace(/[\/:]/g, ' ')}.${fmt === 'm4a' ? 'm4a' : fmt}`;
    const p = path.join(dir, fmt === 'flac' || fmt === 'aiff' || fmt === 'wav' ? 'Lossless' : 'Digital', name);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.copyFileSync(path.join(FIX, SRC[fmt]), p);
    writeTags(p, { title, artist, remixer, genre, bpm, key, rating, year, label, comment: i === 9 ? 'Get it at www.promo-pool.com' : '', album: '' });
  });
  return dir;
}

if (require.main === module) console.log(build(process.argv[2] || path.join(require('os').tmpdir(), 'crate-demo-music')));
module.exports = { build };
