'use strict';
// The only bridge between the sandboxed window and the app. Exposes `window.crate`.
const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('crate', {
  /** Call an API method, e.g. crate.call('tracks.list', { search: 'house' }) */
  call: (method, ...args) => ipcRenderer.invoke('api', String(method), args),
  /** Subscribe to app events ('import-progress', 'library-changed'). Returns an unsubscribe function. */
  on: (event, cb) => { const h = (_e, name, data) => { if (name === event) cb(data); }; ipcRenderer.on('event', h); return () => ipcRenderer.removeListener('event', h); },
  /** Menu actions from the native menu bar. */
  onMenu: (cb) => { const h = (_e, action) => cb(action); ipcRenderer.on('menu', h); return () => ipcRenderer.removeListener('menu', h); },
  /** Absolute path of a file dropped onto the window (for drag-and-drop import). */
  pathForFile: (file) => webUtils.getPathForFile(file),
  platform: process.platform,
});
