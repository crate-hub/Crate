#!/bin/bash
# Double-click this file in Finder to build Crate and install it in /Applications.
# It opens Terminal, runs the build (installing Node.js with Homebrew if needed), then opens Crate.

cd "$(dirname "$0")" || exit 1
clear
echo "Installing Crate from: $(pwd)"
echo

# Files copied or unzipped from elsewhere can lose their "run" permission; put it back.
chmod +x ./build-mac.sh 2>/dev/null

if ./build-mac.sh --install; then
  echo
  echo "Crate is installed in /Applications. Opening it now…"
  open -a /Applications/Crate.app
  echo
  echo "You can close this window."
else
  echo
  echo "The install didn't finish. The message above says what went wrong."
  echo "Press Return to close this window."
  read -r _
  exit 1
fi
