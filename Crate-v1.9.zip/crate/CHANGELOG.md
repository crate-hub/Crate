# Changelog

Each delivered version of Crate is numbered here, with one decimal place: 0.9, then 1.0, 1.1 and so on. The number also shows in the app (next to the name, and in Crate › About Crate) and in the zip's file name. Earlier versions were renumbered to this format: 0.1 to 0.8 were first called 0.1.0, 0.1.1, 0.1.2, 0.2.0, 0.3.0, 0.3.1, 0.3.2 and 0.4.0.

## 1.9 — remembers the window size

- Crate reopens with the window size and position it had when you closed it, and maximised or full screen if it was. If that spot is no longer on any screen, for example after a monitor is unplugged, it opens at the default size in the middle of the main screen. The state is saved in `window-state.json` next to your library.

## 1.8 — no wrapper folders on import

- Importing from rekordbox or Engine DJ no longer creates a “From rekordbox” or “From Engine DJ” folder. Playlists, folders and smart playlists go straight to the top level of your playlists.
  - Importing from the same app again replaces the playlists the last import made.
  - A playlist you already have in Crate with the same name is replaced by the imported one, so a round trip from Crate to the DJ app and back never shows a playlist twice.
  - An existing “From …” folder from an earlier version is removed on your next import from that app, and its playlists come back at the top level.
- Exports are unchanged from 1.7: no wrapper folder, and Engine DJ's and rekordbox's existing playlists are replaced by Crate's.

## 1.7 — clean-install export (new build)

- New build of 1.6, with no changes to how anything works. It confirms how exports behave: exporting to Engine DJ or rekordbox removes every existing playlist, folder and smart playlist there, then writes only Crate's playlists, at the top level. rekordbox's built-in system lists and Engine's Prepare list are kept, and both apps' libraries are backed up first.

## 1.6 — Save to file also renames

- **Save to file** in the track panel now does two things: it writes your tag edits into the file, then renames the file to “Artist - Title” using the new artist and title. A note under the button says so.
  - The button is also enabled when a file only needs renaming, even if no tags were changed.
  - The message afterwards has **Undo rename**.
  - Tracks without an artist or title keep their file name. If the name is taken, “(2)” is added.
- “Rename file to ‘Artist - Title’” is removed from the track right-click menu. Renaming many files at once is still available in Clean up › Rename files to “Artist - Title”…, with its preview.

## 1.5 — one-click install

- New **Install.command** in the project folder. Double-click it and Terminal opens, builds Crate, installs it in /Applications and opens it. It's the same as running `./build-mac.sh --install`.

## 1.4 — Write tags to file: six fields only

- **Write tags to file** now writes only Artist, Title, Album, Genre, Year and Comment. Every other tag in the file is left exactly as it was: BPM, key, rating, label, remixer, artwork, cue data and so on.

## 1.3 — exports replace all playlists; write tags to file

- Every export now writes your playlists at the top level, with no “Crate” folder around them. The “From rekordbox” and “From Engine DJ” folders that imports create are flattened too, so their playlists and folders sit at the top.
- Exporting to Engine DJ or straight into rekordbox now makes the playlists there match Crate's exactly. Every existing playlist, folder and smart playlist is replaced. rekordbox's built-in lists (Cloud Library Sync, CUE Analysis Playlist) and Engine's Prepare list are kept. The usual backups are still made first.
- rekordbox XML puts your playlists directly under its root. M3U8 files go straight into the folder you choose, with no “Crate Playlists” subfolder.
- New: **Write tags to file** in the track right-click menu. It saves Crate's tags for the selected tracks into their music files, which is useful after importing from a DJ app without saving to the files. Missing files are skipped.

## 1.2 — export straight into rekordbox

- New export option: **rekordbox library (native)**, next to rekordbox XML in the Export menu (also File › Export to rekordbox Library…, ⌥⌘E). It writes straight into rekordbox's own `master.db` and `masterPlaylists6.xml`, so everything appears in rekordbox's Collection and Playlists without importing an XML file. The XML export is unchanged.
  - Tracks: new files are added, and rekordbox analyses them when you load them. Tracks rekordbox already has get Crate's tags (title, artist, album, genre, label, remixer, composer, key, BPM, rating, year, comment, track number, mix). Files Crate renamed are moved instead of added twice.
  - Playlists: recreated inside one top-level folder (default “Crate”), which is replaced on each export. rekordbox's own playlists are left alone. Smartlists become rekordbox smart playlists where the rules convert, and normal playlists otherwise; key, playlist-membership and limit rules don't convert.
  - Cue points: hot cues with their colours and names, hot loops, memory cues and loops. They're written to rekordbox's cue table and to the second copy rekordbox keeps (`contentCue`), and only tracks with cues in Crate are changed. They're skipped for FLAC and VBR MP3 files, which need seek data only rekordbox can create; the export message lists them.
  - Update counters are advanced the way rekordbox does it, so it picks up the changes.
- Safety: the export refuses while rekordbox is open or has unsaved changes. It backs up `master.db` and `masterPlaylists6.xml` into a “Crate backups” folder next to them every time. All changes are made on a decrypted temporary copy and checked. The result is re-encrypted with SQLCipher 4, exactly as rekordbox encrypts it, and confirmed before it replaces the original. If anything fails, the original files are left as they were.
- Importing from rekordbox now skips the folder Crate exports into, so a round trip doesn't duplicate your playlists.

## 1.1 — reorder columns

- Drag a column header sideways to move the column. A line shows where it will land, and the order is remembered between launches. A plain click on a header still sorts, and dragging its edge still resizes.
- Right-click the header and choose Reset column order to go back to the default. The show/hide list in that menu follows your order.

## 1.0 — cue pane on the left

- Cue points moved out of the track panel on the right into their own pane at the bottom of the left sidebar, just above the play button.
- The pane shows the selected track's cue points. When the selected track has none, or several tracks are selected, it shows the cues of the track that's playing, marked "Playing". It's hidden when there's nothing to show.
- Clicking a cue plays from it, as before, and Space still plays and pauses afterwards.

## 0.9 — rename files, version format

- New: rename files to “Artist - Title” from their tags. It's in Clean up › Rename files…, the track right-click menu, and the Clean Up menu, and it works on selected tracks, the current view or the whole library.
  - The preview lists every new name before anything changes.
  - Files stay in their folder and keep their extension.
  - Characters that aren't allowed in file names are replaced: “AC/DC” becomes “AC - DC”, and “Title: Sub” becomes “Title - Sub”.
  - If the new name is taken, “(2)” is added. Tracks without an artist or title are skipped.
  - Undo straight after renaming puts the old names back.
- Crate remembers each file's earlier names. The next Engine DJ export moves Engine's existing track to the new name instead of adding a duplicate, so its cue points, beatgrid and play history stay. In rekordbox, renamed files show as missing until you relocate them.
- Version numbers now have one decimal place.

## 0.8 — cue points

- Cue points are imported from rekordbox (`master.db`): hot cues A–H with their colours and names, hot loops, memory cues and memory loops.
- Cue points are imported from Engine DJ (`m.db`): the 8 hot cues, the 8 saved loops, and the main cue if you moved it.
- Cue points are read from music files' Serato tags, which Serato DJ and Mixed In Key write: hot cues and saved loops. Files already in Crate are checked the next time you import their folder. Cues from rekordbox or Engine are never replaced by the file's Serato cues.
- Exporting rekordbox XML includes cue points as position marks: hot cues with their colours, memory cues and loops.
- Exporting to Engine DJ writes cue points into Engine's own cue storage: hot cues to the 8 cue pads, saved loops to the loop pads (hot loops and memory loops fill free loop pads), and the first memory cue as the main cue. Only tracks that have cue points in Crate are changed. Beatgrids and waveforms are left alone. There's a checkbox to leave cues out.
- The track panel lists a track's cue points; click one to play from there. Cue points also show as marks on the player's progress bar, and clicking a mark jumps to it.
- New optional Cues column (right-click the header) shows how many cue points each track has.
- The Engine backup now also copies Engine's `-journal` file when there is one.

## 0.7 — resizable columns

- Drag the edge of any column header to resize it. Widths are remembered between launches.
- Double-click a column's edge to fit it to its contents.
- When the columns are wider than the window, the track list scrolls sideways and the header moves with it.
- Right-click the header and choose Reset column widths to go back to columns that share the window's width.
- The header now lines up exactly with the rows when a scrollbar is showing.

## 0.6 — player fixes

- AIFF files now play. Chromium, which Crate's window runs on, can't decode AIFF, so the player is sent a WAV version made on the fly while it plays: the same samples, with the file itself left untouched. Seeking works as normal. Uncompressed AIFF and AIFF-C at 8, 16, 24 and 32 bits, plus 32/64-bit float, are supported.
- Double-clicking a track plays it again. The first click redrew the list, so the double-click never reached the row.

## 0.5 — smart playlists between apps

- Smart playlists are imported from rekordbox (`master.db`) as Crate smartlists that keep their rules: all/any matching, text, BPM ranges, key, rating, year, length, and "added in the last…" dates.
- Engine DJ smartlists are imported as Crate smartlists in the same folders.
- Exporting to Engine DJ writes Crate smartlists as native Engine smartlists, so they keep updating in Engine. Ones that use rules Engine can't express (limit/sort, playlist membership, "is empty", remixer and similar fields) are exported as normal playlists, and the export message lists them.
- The import dialog lists any rekordbox smart playlists it couldn't convert (My Tag, colour or play-count rules), with the reason.
- The version number now shows in the window and its title bar, and the build script prints it.
- rekordbox XML and M3U8 exports still write smartlists as normal playlists, since those formats can't hold rules.

## 0.4 — import from rekordbox and Engine DJ

- Import from rekordbox 6/7: reads and decrypts `master.db` in memory (rekordbox is never changed) and uses `masterPlaylists6.xml` to decide which playlists exist.
- Import from Engine DJ: reads `Database2/m.db` from a copy, so Engine can stay open.
- Tracks match by file path. By default Crate keeps its own tags and only fills empty fields; you can choose to take the other app's tags, and optionally save them into the files.
- Missing files are added as missing, and the dialog can rewrite paths, for example from another computer.
- Imported playlists go into a "From rekordbox" or "From Engine DJ" folder that is replaced on each import.

## 0.3 — build fix

- The build script unpacks Electron with macOS's `ditto` and assembles `Crate.app` itself, because the usual zip library stopped silently on recent Node versions and left no app.

## 0.2 — Terminal build with Homebrew

- Added `build-mac.sh`. It installs Node with Homebrew if needed, runs the tests, builds and signs `Crate.app`, and with `--install` copies it to /Applications.

## 0.1 — first version

- Library with tag reading and writing for MP3, FLAC, M4A, AIFF and WAV; batch editing; Camelot / Open Key / musical key display; search; preview player.
- Playlists, folders and rule-based smartlists, including harmonic "mixes with" key rules.
- Clean-up tools: fix titles and artists, find duplicates, rename genres, find and replace, missing files.
- Export to rekordbox XML, Engine DJ and M3U8.
