'use strict';
// Electron main process: window, menu, dialogs, the audio protocol and the API bridge.
const { app, BrowserWindow, ipcMain, dialog, shell, Menu, protocol, screen } = require('electron');
const path = require('path');
const windowState = require('./src/main/windowstate');
const fs = require('fs');
const { Readable } = require('stream');
const { execFile } = require('child_process');
const { Library } = require('./src/core/library');
const { createApi } = require('./src/main/api');
const aiffstream = require('./src/core/aiffstream');

protocol.registerSchemesAsPrivileged([{ scheme: 'crate-audio', privileges: { standard: true, secure: true, stream: true, supportFetchAPI: true } }]);

let win = null, lib = null, api = null;
const MIME = { '.mp3': 'audio/mpeg', '.flac': 'audio/flac', '.m4a': 'audio/mp4', '.mp4': 'audio/mp4', '.aac': 'audio/aac', '.wav': 'audio/wav', '.aif': 'audio/aiff', '.aiff': 'audio/aiff' };

function isEngineRunning() {
  return new Promise(resolve => {
    if (process.platform === 'darwin') execFile('pgrep', ['-x', 'Engine DJ'], err => resolve(!err));
    else if (process.platform === 'win32') execFile('tasklist', ['/FI', 'IMAGENAME eq Engine DJ.exe'], (err, out) => resolve(!err && /Engine DJ\.exe/i.test(out)));
    else resolve(false);
  });
}

// rekordbox 6/7 run as "rekordbox" (macOS) / "rekordbox.exe" (Windows); writing its library while it runs would be overwritten or corrupt it.
function isRekordboxRunning() {
  return new Promise(resolve => {
    if (process.platform === 'darwin') execFile('pgrep', ['-x', 'rekordbox'], err => resolve(!err));
    else if (process.platform === 'win32') execFile('tasklist', ['/FI', 'IMAGENAME eq rekordbox.exe'], (err, out) => resolve(!err && /rekordbox\.exe/i.test(out)));
    else resolve(false);
  });
}

function createWindow() {
  // Reopen at the size and place it had when it was last closed.
  const stateFile = path.join(app.getPath('userData'), 'window-state.json');
  const saved = windowState.load(stateFile);
  const bounds = windowState.fit(saved, screen.getAllDisplays().map(d => d.workArea));
  win = new BrowserWindow({
    ...bounds, minWidth: windowState.MIN.width, minHeight: windowState.MIN.height, title: 'Crate', backgroundColor: '#121214',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  if (saved && saved.maximized) win.maximize();
  if (saved && saved.fullScreen) win.setFullScreen(true);
  windowState.track(win, stateFile);
  win.loadFile(path.join(__dirname, 'src', 'renderer', 'index.html'));
  // Never navigate away or open new windows from the UI; external links open in the browser.
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.webContents.setWindowOpenHandler(({ url }) => { if (/^https:\/\//.test(url)) shell.openExternal(url); return { action: 'deny' }; });
}

function buildMenu() {
  const send = (action) => () => win && win.webContents.send('menu', action);
  const template = [
    ...(process.platform === 'darwin' ? [{ role: 'appMenu' }] : []),
    { label: 'File', submenu: [
      { label: 'Import Music…', accelerator: 'CmdOrCtrl+I', click: send('import') },
      { label: 'Import from rekordbox…', click: send('import-rekordbox') },
      { label: 'Import from Engine DJ…', click: send('import-engine') },
      { label: 'New Playlist', accelerator: 'CmdOrCtrl+N', click: send('new-playlist') },
      { label: 'New Smartlist', accelerator: 'CmdOrCtrl+Shift+N', click: send('new-smartlist') },
      { type: 'separator' },
      { label: 'Export to rekordbox Library…', accelerator: 'CmdOrCtrl+Alt+E', click: send('export-rekordbox-db') },
      { label: 'Export rekordbox XML…', accelerator: 'CmdOrCtrl+E', click: send('export-rekordbox') },
      { label: 'Export to Engine DJ…', accelerator: 'CmdOrCtrl+Shift+E', click: send('export-engine') },
      { label: 'Export M3U Playlists…', click: send('export-m3u') },
      { type: 'separator' },
      { label: 'Check for Missing Files', click: send('check-missing') },
      ...(process.platform === 'darwin' ? [] : [{ type: 'separator' }, { role: 'quit' }]),
    ] },
    { role: 'editMenu' },
    { label: 'Clean Up', submenu: [
      { label: 'Fix Titles & Artists…', click: send('cleanup-fixes') },
      { label: 'Find Duplicates…', click: send('cleanup-duplicates') },
      { label: 'Rename Genres…', click: send('cleanup-genres') },
      { label: 'Find & Replace…', accelerator: 'CmdOrCtrl+Shift+F', click: send('cleanup-replace') },
      { label: 'Rename Files to “Artist - Title”…', click: send('cleanup-rename') },
    ] },
    { label: 'View', submenu: [{ role: 'reload' }, { role: 'toggleDevTools' }, { type: 'separator' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' }] },
    { role: 'windowMenu' },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(() => {
  lib = new Library(path.join(app.getPath('userData'), 'library.db'));
  api = createApi(lib, {
    chooseImport: async () => {
      const r = await dialog.showOpenDialog(win, { title: 'Import music', properties: ['openDirectory', 'openFile', 'multiSelections'],
        filters: [{ name: 'Audio', extensions: ['mp3', 'flac', 'm4a', 'mp4', 'aac', 'wav', 'aif', 'aiff'] }] });
      return r.canceled ? null : r.filePaths;
    },
    chooseSave: async (o) => { const r = await dialog.showSaveDialog(win, o); return r.canceled ? null : r.filePath; },
    chooseFolder: async (o) => { const r = await dialog.showOpenDialog(win, { ...o, properties: ['openDirectory', 'createDirectory'] }); return r.canceled ? null : r.filePaths[0]; },
    chooseFile: async (o) => { const r = await dialog.showOpenDialog(win, { ...o, properties: ['openFile'] }); return r.canceled ? null : r.filePaths[0]; },
    reveal: (p) => shell.showItemInFolder(p),
    trash: (p) => shell.trashItem(p),
    isEngineRunning, isRekordboxRunning,
    send: (event, data) => win && !win.isDestroyed() && win.webContents.send('event', event, data),
  });

  ipcMain.handle('api', async (e, method, args) => {
    // Only the app's own window (top frame) may call the API.
    if (!win || e.sender !== win.webContents || (e.senderFrame && e.senderFrame.parent)) throw new Error('Not allowed');
    return api.call(method, args);
  });

  // crate-audio://track/<id> streams a library track (with HTTP range support for seeking).
  protocol.handle('crate-audio', async (req) => {
    const id = new URL(req.url).pathname.replace(/^\//, '');
    const file = api.audioPath(id);
    if (!file) return new Response('Not found', { status: 404 });
    // Chromium can't decode AIFF, so AIFF files are served as WAV, converted while streaming.
    const aiff = /\.aiff?$/i.test(file) ? aiffstream.probe(file) : null;
    const size = aiff ? aiff.size : fs.statSync(file).size;
    const type = aiff ? 'audio/wav' : MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
    const body = (start, end) => Readable.toWeb(aiff ? aiffstream.wavStream(file, aiff, start, end) : fs.createReadStream(file, { start, end }));
    const m = /bytes=(\d*)-(\d*)/.exec(req.headers.get('range') || '');
    if (!m) return new Response(body(0, size - 1), { status: 200, headers: { 'Content-Type': type, 'Content-Length': String(size), 'Accept-Ranges': 'bytes' } });
    let start = m[1] ? +m[1] : size - +m[2], end = m[1] && m[2] ? +m[2] : size - 1;
    if (!m[1]) end = size - 1; start = Math.max(0, start); end = Math.min(end, size - 1);
    if (start > end) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } });
    return new Response(body(start, end), { status: 206,
      headers: { 'Content-Type': type, 'Content-Length': String(end - start + 1), 'Content-Range': `bytes ${start}-${end}/${size}`, 'Accept-Ranges': 'bytes' } });
  });

  buildMenu();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('will-quit', () => { try { lib && lib.close(); } catch { /* already closed */ } });
